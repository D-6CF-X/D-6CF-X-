/* D-6CF-X的临时小站 - 前端逻辑 */
(function () {
  'use strict';

  var state = {
    settings: {},
    token: localStorage.getItem('d6cf_token') || '',
    userToken: localStorage.getItem('d6cf_user_token') || '',
    me: null,
    posts: [],
    media: [],
    folders: [],          // 媒体文件夹：{ id, name, type: 'image'|'audio' }
    musicFolder: 'all',   // 音乐页当前文件夹：'all' | 'none' | '<文件夹id>'
    galleryFolder: 'all', // 图库页当前文件夹
    mFilterType: 'all',   // 后台媒体库筛选：'all' | 'image' | 'audio'
    mFilterFolder: 'all', // 后台媒体库文件夹筛选：'all' | 'none' | '<id>'
    mediaSel: {},         // 后台媒体库已勾选的文件 id
    playlist: [],
    playIndex: -1,
    adminTab: 'editor',
    editingPost: null,
    view: 'home'
  };

  var $ = function (sel) { return document.querySelector(sel); };
  var viewEl = $('#view');

  /* ---------------- 工具 ---------------- */
  function api(method, url, body, opts) {
    opts = opts || {};
    var h = opts.headers || {};
    return rawApi(method, url, body, h);
  }
  function rawApi(method, url, body, extraHeaders) {
    var opts = { method: method, headers: extraHeaders || {} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    if (state.token) opts.headers['Authorization'] = 'Bearer ' + state.token;
    if (state.userToken) opts.headers['X-User-Token'] = state.userToken;
    return fetch(url, opts).then(function (res) {
      return res.json().then(function (data) {
        if (!res.ok) {
          if (res.status === 401) {
            // 按错误信息的语义判断是成员登录态失效还是站长会话失效，避免互相误清
            var msg = String(data.error || '');
            var memberish = /请先登录账号|请先登录|登录后才能/.test(msg);
            if (memberish && state.userToken) {
              state.userToken = '';
              state.me = null;
              localStorage.removeItem('d6cf_user_token');
            } else if (state.token) {
              state.token = '';
              state.me = null;
              localStorage.removeItem('d6cf_token');
            }
            updateUserChip();
          }
          throw new Error(data.error || ('请求失败 ' + res.status));
        }
        return data;
      });
    });
  }
  function esc(str) {
    return String(str == null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /* ---------------- 全站文案（站长可在「小站管理 → ✍️ 全站文案」里改） ----------------
     每一项：g 分组 / k 存储键 / label 后台字段名 / def 默认文案
     文案里可用的占位符：{n} 数量统计、{title} 站点标题、{link} 「注册 / 登录」链接（自动指向 #/me）
     站点标题 siteTitle、副标题 subtitle、公告 notice、关于页 about 已有各自的设置项，不在这里重复 */
  var SITE_TEXTS = [
    { g: '🧭 导航菜单', k: 'nav_home', label: '侧栏 / 手机菜单「首页」', def: '首页' },
    { g: '🧭 导航菜单', k: 'nav_posts', label: '「文章」', def: '文章' },
    { g: '🧭 导航菜单', k: 'nav_music', label: '「音乐」', def: '音乐' },
    { g: '🧭 导航菜单', k: 'nav_gallery', label: '「图库」', def: '图库' },
    { g: '🧭 导航菜单', k: 'nav_board', label: '「签名板」', def: '签名板' },
    { g: '🧭 导航菜单', k: 'nav_about', label: '「关于」', def: '关于' },
    { g: '🧭 导航菜单', k: 'nav_me', label: '「我的主页」（未登录时显示；登录后显示用户名）', def: '我的主页' },

    { g: '🏠 首页', k: 'hero_welcome', label: '欢迎语（后面自动接站点标题）', def: '欢迎来到' },
    { g: '🏠 首页', k: 'dm_title', label: '弹幕网模块标题', def: '🎐 弹幕网' },
    { g: '🏠 首页', k: 'dm_slogan', label: '弹幕网标语', def: '来留下一句你对天依想说的话吧！' },
    { g: '🏠 首页', k: 'dm_guest_tip', label: '弹幕网未登录提示（{link} = 注册 / 登录链接）', def: '{link}后就能发一条属于自己的弹幕啦～（10 种样式、4 档字号随你挑）' },
    { g: '🏠 首页', k: 'dm_empty', label: '弹幕墙空状态', def: '还没有弹幕，来发第一条吧～' },
    { g: '🏠 首页', k: 'quick_title', label: '快捷入口标题', def: '🔗 快捷入口' },
    { g: '🏠 首页', k: 'posts_empty', label: '首页没有文章时', def: '还没有文章，去「小站管理」发布第一篇吧～' },

    { g: '📄 各页标题', k: 'page_posts_title', label: '文章页标题', def: '📝 全部文章' },
    { g: '📄 各页标题', k: 'page_posts_sub', label: '文章页说明（{n} = 篇数）', def: '共 {n} 篇' },
    { g: '📄 各页标题', k: 'page_music_title', label: '音乐页标题', def: '🎵 音乐' },
    { g: '📄 各页标题', k: 'page_music_sub', label: '音乐页说明（{n} = 首数）', def: '共 {n} 首 · 点击播放，播放器在页面底部' },
    { g: '📄 各页标题', k: 'page_gallery_title', label: '图库页标题', def: '🖼️ 图库' },
    { g: '📄 各页标题', k: 'page_gallery_sub', label: '图库页说明（{n} = 张数）', def: '共 {n} 张 · 点击查看大图' },
    { g: '📄 各页标题', k: 'page_about_title', label: '关于页标题', def: '💬 关于本站' },
    { g: '📄 各页标题', k: 'page_board_title', label: '签名板标题', def: '🫧 赛博签名板' },
    { g: '📄 各页标题', k: 'page_thanks_title', label: '特别感谢名单标题', def: '🌟 特别感谢名单' },
    { g: '📄 各页标题', k: 'page_board_sub', label: '签名板说明', def: '站长的气泡在最中心 · 越早来到小站的伙伴，离中心越近 · 点击气泡查看签名和主页' },
    { g: '📄 各页标题', k: 'page_me_title', label: '我的主页标题', def: '👤 我的主页' },
    { g: '📄 各页标题', k: 'page_me_sub', label: '我的主页 / 注册登录页说明', def: '注册一个账号，就能在签名板留下你的气泡、拥有自己的公开主页' },
    { g: '📄 各页标题', k: 'page_privacy_title', label: '隐私政策页标题', def: '🔒 隐私政策' },
    { g: '📄 各页标题', k: 'page_admin_title', label: '小站管理页标题', def: '🛠️ 小站管理' },
    { g: '📄 各页标题', k: 'page_admin_sub', label: '小站管理页说明', def: '在这里发布文章、上传音乐图片、修改背景和链接' },

    { g: '💬 互动提示', k: 'board_tip_guest', label: '签名板底部提示·访客（{n} = 人数，{link} = 注册 / 登录）', def: '共 {n} 位小伙伴已签名 · {link}后留下你的气泡！' },
    { g: '💬 互动提示', k: 'board_tip_member', label: '签名板底部提示·已登录（{n} = 人数，{link} = 我的主页）', def: '共 {n} 位小伙伴已签名 · 快去{link}打扮自己的气泡吧' },
    { g: '💬 互动提示', k: 'board_zoom_label', label: '签名板·泡泡大小调节条', def: '泡泡大小' },
    { g: '💬 互动提示', k: 'comment_guest_tip', label: '文章评论区未登录提示（{link} = 注册 / 登录）', def: '{link}后就能在这里留言啦～' },

    { g: '📝 文章', k: 'sched_pending', label: '定时发布的文章未到发布时间时，访客打开看到的提示（留空 = 文章不存在）', def: '文章不存在' },

    { g: '🔻 页脚', k: 'footer_beian', label: 'ICP 备案号（侧栏底部 + 全站页脚）', def: '湘ICP备2026044015号-1' },
    { g: '🔻 页脚', k: 'footer_gongan', label: '公安网安备案号（侧栏底部 + 全站页脚，点击跳转备案查询）', def: '湘公网安备43110202000225号' }
  ];
  var TEXT_DEF = {};
  SITE_TEXTS.forEach(function (t) { TEXT_DEF[t.k] = t.def; });
  /* 取原始文案：站长改过且非空 → 用改的；否则回默认 */
  function tRaw(key) {
    var tx = state.settings && state.settings.texts;
    var v = tx ? tx[key] : '';
    v = (typeof v === 'string') ? v.trim() : '';
    return v || TEXT_DEF[key] || '';
  }
  /* 取文案并替换占位符。返回值是纯文本，需要进 HTML 时自行 esc() */
  function T(key, vars) {
    var out = tRaw(key);
    if (vars) {
      Object.keys(vars).forEach(function (k) {
        out = out.split('{' + k + '}').join(vars[k] == null ? '' : String(vars[k]));
      });
    }
    return out;
  }
  /* 「注册 / 登录」或「我的主页」链接标记，供 {link} 占位符使用 */
  function T_LINK(text) {
    return '<a href="#/me">' + esc(text || '注册 / 登录') + '</a>';
  }
  /* 取文案 → 转义 → 把 {link} 换成真链接 → 返回可安全塞进 HTML 的字符串
     linkText 传链接里显示的字（如 '注册 / 登录'、'我的主页'）；其余占位符走 vars */
  function T_HTML(key, linkText, vars) {
    return T(key, vars).split('{link}').map(function (seg) {
      return esc(seg);
    }).join(T_LINK(linkText || '注册 / 登录'));
  }
  /* 把静态骨架（侧栏导航、页脚备案号）套上站长自定义文案；设置更新后自动再跑一次 */
  function applyTexts() {
    var NAV = { home: 'nav_home', posts: 'nav_posts', music: 'nav_music', gallery: 'nav_gallery', board: 'nav_board', about: 'nav_about' };
    document.querySelectorAll('#sidebar .side-nav a[data-route]').forEach(function (a) {
      var key = NAV[a.getAttribute('data-route')];
      if (!key) return;
      var spans = a.querySelectorAll('span');
      if (spans.length) spans[spans.length - 1].textContent = T(key);
    });
    var meLabel = $('#me-nav-label');
    if (meLabel && !state.me) meLabel.textContent = T('nav_me');
    /* 备案号（只出现在隐私政策页底部）：ICP 与公安备案分开套用，互不覆盖 */
    document.querySelectorAll('a.beian-icp').forEach(function (el) {
      el.textContent = T('footer_beian');
    });
    document.querySelectorAll('a.beian-gongan').forEach(function (el) {
      var t = T('footer_gongan');
      var sp = el.querySelector('.beian-text'); // 号码写在 span 里，保住旁边的公安徽标 img
      if (sp) sp.textContent = t; else el.textContent = t;
    });
  }
  function fmtTime(ts) {
    var d = new Date(ts);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function fmtSize(bytes) {
    if (bytes > 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    return Math.round(bytes / 1024) + ' KB';
  }
  function fmtSec(s) {
    s = Math.floor(s || 0);
    return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
  }
  function toast(msg) {
    var t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._timer);
    t._timer = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }
  function md(text) {
    try { return marked.parse(text || ''); } catch (e) { return '<p>' + esc(text).replace(/\n/g, '<br>') + '</p>'; }
  }

  /* ---------------- 设置应用 ---------------- */
  /* 日/夜间壁纸：夜间没单独设就依次回落到日间壁纸 → 默认壁纸；
     视频壁纸优先于图片（图片在视频加载完成前先垫着当海报） */
  function bgAssets() {
    var s = state.settings || {};
    var dark = currentTheme() === 'dark';
    var img = dark
      ? (s.backgroundUrlNight || s.backgroundUrlDay || s.backgroundUrl || '')
      : (s.backgroundUrlDay || s.backgroundUrl || '');
    var vid = dark ? (s.backgroundVideoNight || '') : (s.backgroundVideoDay || '');
    return { img: img, vid: vid };
  }
  /* 壁纸取景（裁剪）：日间 / 夜间各一套，每套再分桌面端 / 窄屏（断点与 CSS 一致：860px）。
     日间和夜间用的是不同壁纸（图片或视频），构图比例都不一样，取景必须能分开调；
     手机竖屏和电脑宽屏同样差得远，所以是「日/夜 × 宽/窄」四套 */
  var BG_MOBILE_MQ = window.matchMedia ? window.matchMedia('(max-width: 860px)') : null;
  var BG_CROP_DEF = { fit: 'cover', x: 50, y: 50, zoom: 100 };
  var BG_FITS = ['cover', 'contain', 'fill'];
  function bgNormCrop(o) {
    o = (o && typeof o === 'object') ? o : {};
    var num = function (v, lo, hi, dft) {
      var n = Number(v);
      return isFinite(n) ? Math.max(lo, Math.min(hi, Math.round(n))) : dft;
    };
    return {
      fit: BG_FITS.indexOf(o.fit) !== -1 ? o.fit : BG_CROP_DEF.fit,
      x: num(o.x, 0, 100, BG_CROP_DEF.x),
      y: num(o.y, 0, 100, BG_CROP_DEF.y),
      zoom: num(o.zoom, 100, 300, BG_CROP_DEF.zoom)
    };
  }
  /* 归一出「日/夜 × 宽/窄」四套；老数据只有 desktop/mobile 两套，读到就同时套给日间和夜间（平滑迁移） */
  function bgCropRaw() {
    var c = (state.settings && state.settings.bgCrop) || {};
    var legacy = ((c.desktop || c.mobile) && !c.day && !c.night) ? c : null;
    var pick = function (mode, view) {
      var m = c[mode];
      if (m && typeof m === 'object' && m[view]) return bgNormCrop(m[view]);
      if (legacy) return bgNormCrop(legacy[view]);
      return bgNormCrop(null);
    };
    return {
      day: { desktop: pick('day', 'desktop'), mobile: pick('day', 'mobile') },
      night: { desktop: pick('night', 'desktop'), mobile: pick('night', 'mobile') }
    };
  }
  /* 当前该用哪一套：主题（日/夜）+ 视口（宽/窄）→ "day-desktop" 这样的键 */
  function bgCropKey() {
    var mode = currentTheme() === 'dark' ? 'night' : 'day';
    var view = (BG_MOBILE_MQ && BG_MOBILE_MQ.matches) ? 'mobile' : 'desktop';
    return mode + '-' + view;
  }
  function bgCropCfg() {
    var p = bgCropKey().split('-');
    return bgCropRaw()[p[0]][p[1]];
  }
  /* 把取景参数换算成 CSS：transform-origin 与 background-position 用同一个焦点，
     缩放时焦点保持不动，所见即所得 */
  /* 取景参数 → CSS。bgCropStyle 只管取景几何，不改背景图地址
     （地址由 bgSetImage 单独写：换主题时「什么时候换图」要由视频就绪情况决定） */
  function bgCropStyle(cfg) {
    return {
      'background-size': cfg.fit === 'cover' ? 'cover' : (cfg.fit === 'contain' ? 'contain' : '100% 100%'),
      'background-position': cfg.x + '% ' + cfg.y + '%',
      'transform-origin': cfg.x + '% ' + cfg.y + '%',
      'transform': cfg.zoom > 100 ? 'scale(' + (cfg.zoom / 100) + ')' : 'none'
    };
  }
  function bgStyleOf(cfg, url) {
    var o = bgCropStyle(cfg);
    o['background-image'] = url ? 'url("' + url + '")' : 'none';
    return o;
  }
  function bgVideoStyleOf(cfg) {
    return {
      'object-fit': cfg.fit === 'fill' ? 'fill' : cfg.fit,
      'object-position': cfg.x + '% ' + cfg.y + '%',
      'transform-origin': cfg.x + '% ' + cfg.y + '%',
      'transform': cfg.zoom > 100 ? 'scale(' + (cfg.zoom / 100) + ')' : 'none'
    };
  }
  function setStyle(el, o) { if (el) Object.keys(o).forEach(function (k) { el.style.setProperty(k, o[k]); }); }
  function applyBgCrop() {
    var cfg = bgCropCfg();
    setStyle(document.getElementById('bg-image'), bgCropStyle(cfg));
    bgVidSlots().forEach(function (v) { setStyle(v, bgVideoStyleOf(cfg)); });
    return cfg;
  }
  /* 窗口跨过断点（手机横竖屏切换 / 缩窗）时按对应那套参数重新取景；
     媒体查询 change 之外再挂一层 resize 兜底，避免个别浏览器不派发 change */
  var bgLastMobile = BG_MOBILE_MQ ? BG_MOBILE_MQ.matches : false;
  function bgResync() {
    var m = BG_MOBILE_MQ ? BG_MOBILE_MQ.matches : false;
    if (m === bgLastMobile) return;
    bgLastMobile = m;
    applyBgCrop();
  }
  if (BG_MOBILE_MQ) {
    if (BG_MOBILE_MQ.addEventListener) BG_MOBILE_MQ.addEventListener('change', bgResync);
    else if (BG_MOBILE_MQ.addListener) BG_MOBILE_MQ.addListener(bgResync);
  }
  var bgRszTimer = 0;
  window.addEventListener('resize', function () {
    clearTimeout(bgRszTimer);
    bgRszTimer = setTimeout(bgResync, 150);
  });
  /* ---------------- 视频壁纸：两块槽轮换 + 启动屏预热 ----------------
     要解决的两件事：
       1) 启动屏期间就把日/夜间两套视频壁纸下载下来，进站即有画面；
       2) 切主题时不再「先闪一下新主题的静态壁纸、再淡入视频」——
          视频没出画之前绝不动静态图，旧画面继续留在屏幕上，出画了再和新图同一时刻换上。 */
  var BG_VID_SOFT = 10000;   // 超过 10s 还没出画面：先用该主题的静态壁纸顶上，视频加载完再放进去
  var BG_VID_HARD = 30000;   // 超过 30s：不管加载完没都直接放进去（没帧时视频是透明的，静态图仍在）
  var bgVidToken = 0, bgVidT1 = 0, bgVidT2 = 0;
  var bgActiveEl = null;     // 当前真正在显示的那块视频槽（.is-active 任何时刻只有一块）
  var bgSettle = null;       // 当前主题背景「定下来」的 Promise：启动屏用它决定何时收起
  function bgVidSlots() { return Array.prototype.slice.call(document.querySelectorAll('#bg-layer .bg-vid-src')); }
  function bgActiveSlot() { return bgActiveEl; }
  function bgSlotReady(s) { return !!(s && !s.error && s.readyState >= 2); }   // HAVE_CURRENT_DATA：已经有画面了
  /* 取 url 对应的槽（没有就占用空闲槽并开始下载）；已持有该 url 的槽保留缓冲，切回来秒开。
     选槽顺序：完全匹配 → 空槽 → 非活跃且不是「另一主题正在用的那块」（尽量保住另一主题的预热） */
  function bgSlotFor(url) {
    var slots = bgVidSlots(), i, s;
    for (i = 0; i < slots.length; i++) if (slots[i].getAttribute('data-url') === url) return slots[i];
    var act = bgActiveSlot(), pick = null;
    for (i = 0; i < slots.length; i++) if (!slots[i].getAttribute('data-url')) { pick = slots[i]; break; }
    if (!pick) {
      var st = state.settings || {};
      var keep = [st.backgroundVideoDay || '', st.backgroundVideoNight || ''];
      for (i = 0; i < slots.length; i++) {
        s = slots[i];
        if (s === act) continue;
        if (keep.indexOf(s.getAttribute('data-url')) !== -1) continue;
        pick = s; break;
      }
    }
    if (!pick) for (i = 0; i < slots.length; i++) if (slots[i] !== act) { pick = slots[i]; break; }
    if (!pick) pick = slots[slots.length - 1];
    pick.setAttribute('data-url', url);
    pick.preload = 'auto';
    pick.setAttribute('src', url);
    try { pick.load(); } catch (e) {}
    return pick;
  }
  /* 启动屏期间预热：日/夜间两套视频都挂上槽开始下载（不阻塞启动屏，各自有 10s 软兜底） */
  function bgWarmVideos() {
    var s = state.settings || {};
    if (s.backgroundVideoDay) bgSlotFor(s.backgroundVideoDay);
    if (s.backgroundVideoNight) bgSlotFor(s.backgroundVideoNight);
  }
  function bgSetImage(url) {
    var el = document.getElementById('bg-image');
    if (el) setStyle(el, bgStyleOf(bgCropCfg(), url));
  }
  /* 镜像画布（.bg-vid-cv）与所属槽的 is-active 保持一致：淡入淡出全靠 CSS transition，与原视频槽表现一致 */
  function bgMirrorSync(slot) {
    var cv = slot && slot.id ? document.getElementById(slot.id + '-cv') : null;
    if (cv) cv.classList.toggle('is-active', slot.classList.contains('is-active'));
  }
  function bgReveal(slot) {
    var prev = bgActiveEl;
    bgActiveEl = slot;
    slot.classList.add('is-active');
    bgMirrorSync(slot);
    $('#bg-layer').classList.add('has-video');
    if (prev && prev !== slot) {
      prev.classList.remove('is-active');   // 立刻开始 0.6s 淡出（新画面在它上面淡入）
      bgMirrorSync(prev);
      setTimeout(function () { if (bgActiveEl !== prev && !prev.paused) prev.pause(); }, 700);
    }
    var pr = slot.play();
    if (pr && pr.catch) pr.catch(function () {});   // 浏览器拦自动播放时不报错，等用户首次交互
  }
  /* 该主题没有视频壁纸：图片顶上，视频淡出 */
  function bgShowImage(img) {
    $('#bg-layer').classList.remove('has-video');
    bgVidSlots().forEach(function (s) {
      s.classList.remove('is-active');
      bgMirrorSync(s);
      if (!s.paused) s.pause();
    });
    bgActiveEl = null;
    bgSetImage(img);
  }
  /* 切到 vid/img：视频没就绪就先保持原画面，出画后再一起换 */
  function bgApply(vid, img) {
    var token = ++bgVidToken;
    clearTimeout(bgVidT1); clearTimeout(bgVidT2);
    var done;
    bgSettle = new Promise(function (r) { done = r; });
    var finish = function () { done(); };
    if (!vid) { bgShowImage(img); finish(); return bgSettle; }
    var slot = bgSlotFor(vid);
    var cleanup = function () {
      slot.removeEventListener('loadeddata', onReady);
      slot.removeEventListener('error', onErr);
    };
    var reveal = function (hard) {
      if (token !== bgVidToken) return;
      clearTimeout(bgVidT1); clearTimeout(bgVidT2);
      cleanup();
      if (!hard) bgSetImage(img);   // 与新画面同一时刻写入（被视频完全盖住，看不到）
      bgReveal(slot);
      finish();
    };
    var onReady = function () { if (slot.getAttribute('data-url') !== vid) return cleanup(); reveal(false); };
    var onErr = function () {
      if (slot.getAttribute('data-url') !== vid) return cleanup();
      if (token === bgVidToken) { clearTimeout(bgVidT1); clearTimeout(bgVidT2); cleanup(); bgSetImage(img); finish(); }
    };
    if (bgSlotReady(slot)) { reveal(false); return bgSettle; }
    slot.addEventListener('loadeddata', onReady);
    slot.addEventListener('error', onErr);
    // 软兜底：10s 还没出画面 → 先上静态壁纸并放行启动屏（视频加载完再放进去）
    bgVidT1 = setTimeout(function () { if (token === bgVidToken) { bgSetImage(img); finish(); } }, BG_VID_SOFT);
    // 硬兜底：30s 直接放进去（视频自己接着缓冲，出帧即显）
    bgVidT2 = setTimeout(function () { reveal(true); }, BG_VID_HARD);
    return bgSettle;
  }
  function applyBg() {
    var a = bgAssets();
    applyBgCrop();
    return bgApply(a.vid, a.img);
  }
  /* ---- canvas 镜像绘制：小米等国产浏览器会把「大而可见的视频」劫持成原生全屏播放器 ----
     真实 video 藏成 2px 隐形槽只负责解码；这里把活动槽的帧按取景参数（fit/焦点/缩放，
     与 bgVideoStyleOf 的 object-fit/object-position/transform 同一套语义）逐帧画到 canvas 上。
     淡出中的旧槽在 pause（700ms）前也要继续画，交叉过渡才不缺帧。 */
  function bgDrawSlot(v, cv) {
    var vw = v.videoWidth, vh = v.videoHeight;
    if (!vw || !vh) return;
    var cw = cv.width, ch = cv.height;
    if (!cw || !ch) return;
    var cfg = bgCropCfg();
    var ctx = cv.getContext('2d');
    var dw, dh;
    if (cfg.fit === 'fill') { dw = cw; dh = ch; }
    else {
      var kx = cw / vw, ky = ch / vh;
      var k = (cfg.fit === 'contain') ? Math.min(kx, ky) : Math.max(kx, ky);
      dw = vw * k; dh = vh * k;
    }
    var ox = (cw - dw) * cfg.x / 100, oy = (ch - dh) * cfg.y / 100;
    var z = cfg.zoom > 100 ? cfg.zoom / 100 : 1;
    ctx.save();
    if (z !== 1) {
      var tx = cw * cfg.x / 100, ty = ch * cfg.y / 100;
      ctx.translate(tx, ty); ctx.scale(z, z); ctx.translate(-tx, -ty);
    }
    try { ctx.drawImage(v, ox, oy, dw, dh); } catch (e) {}
    ctx.restore();
  }
  var bgCvDpr = Math.min(window.devicePixelRatio || 1, 2);
  function bgMirrorStep() {
    var slots = bgVidSlots(), i, v, cv;
    var w = Math.max(2, Math.round(window.innerWidth * bgCvDpr));
    var h = Math.max(2, Math.round(window.innerHeight * bgCvDpr));
    for (i = 0; i < slots.length; i++) {
      v = slots[i];
      cv = v.id ? document.getElementById(v.id + '-cv') : null;
      if (!cv) continue;
      if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
      if ((v.classList.contains('is-active') || !v.paused) && v.readyState >= 2) bgDrawSlot(v, cv);
    }
    requestAnimationFrame(bgMirrorStep);
  }
  requestAnimationFrame(bgMirrorStep);
  /* 切到后台暂停视频壁纸省电，回前台接着播 */
  document.addEventListener('visibilitychange', function () {
    var v = bgActiveSlot();
    if (!v || !$('#bg-layer').classList.contains('has-video')) return;
    if (document.hidden) { if (!v.paused) v.pause(); }
    else { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
  });
  function applySettings() {
    var s = state.settings;
    document.title = s.siteTitle || 'D-6CF-X的临时小站';
    $('#side-title').textContent = s.siteTitle || '';
    $('#side-sub').textContent = s.subtitle || '';
    $('#m-title').textContent = s.siteTitle || '';
    applyBg();
    $('#stat-created').textContent = s.createdAt || '-';
    applyIcons();
    applyTexts();
  }

  /* 用户登录状态显示 */
  function updateUserChip() {
    var chip = $('#user-chip');
    if (state.me) {
      chip.style.display = 'flex';
      $('#uc-name').textContent = state.me.username;
      var dot = $('#uc-dot');
      var meAv = userAvatarUrl(state.me);
      if (meAv) {
        dot.style.background = 'transparent';
        dot.innerHTML = '<img class="uc-dot-img" src="' + esc(meAv) + '" alt="">';
      } else {
        dot.style.background = state.me.color || 'var(--tianyi-blue)';
        dot.innerHTML = '';
      }
      $('#me-nav-label').textContent = state.me.username;
    } else {
      chip.style.display = 'none';
      $('#me-nav-label').textContent = T('nav_me');
    }
    // 「小站管理」入口只对站长显示，其他成员和访客不可见
    $('#admin-entry').style.display = (state.me && state.me.isOwner) ? 'flex' : 'none';
  }
  function loadMe() {
    if (!state.userToken && !state.token) return Promise.resolve();
    return api('GET', '/api/me').then(function (u) { state.me = u; updateUserChip(); }).catch(function () {});
  }
  /* 访问统计：每session只计一次 */
  function loadStats() {
    return api('GET', '/api/stats').then(function (st) {
      window._visits = st.visits;
      $('#stat-created').textContent = st.createdAt || '-';
      $('#stat-visits').textContent = st.visits;
      var hv = $('#hero-visits');
      if (hv) hv.textContent = st.visits;
      return st;
    });
  }
  function countVisit() {
    if (sessionStorage.getItem('d6cf_visited')) return Promise.resolve();
    return api('POST', '/api/visit').then(function (r) {
      sessionStorage.setItem('d6cf_visited', '1');
      $('#stat-visits').textContent = r.visits;
    }).catch(function () {});
  }

  /* 图标替换：设置里的 icons = { 键: 图片URL } */
  var DEFAULT_AVATAR = '🎤', DEFAULT_FAVICON = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎤</text></svg>";
  function applyIcons() {
    var icons = state.settings.icons || {};
    // 侧栏头像
    var avatarEl = $('#side-avatar');
    avatarEl.innerHTML = icons.avatar ? '<img src="' + esc(icons.avatar) + '" alt="avatar">' : DEFAULT_AVATAR;
    // 浏览器标签页图标
    $('#favicon').href = icons.favicon || DEFAULT_FAVICON;
    // 导航 / 外链 / 管理入口图标
    document.querySelectorAll('.nav-ico[data-icon]').forEach(function (el) {
      var key = el.getAttribute('data-icon');
      el.innerHTML = icons[key] ? '<img src="' + esc(icons[key]) + '" alt="">' : (el.getAttribute('data-emoji') || '');
    });
  }
  // 记录每个图标的默认 emoji，方便「恢复默认」
  document.querySelectorAll('.nav-ico[data-icon]').forEach(function (el) {
    el.setAttribute('data-emoji', el.textContent.trim());
  });
  function loadSettings() {
    return api('GET', '/api/settings').then(function (s) { state.settings = s; applySettings(); });
  }

  /* ---------------- 路由 ---------------- */
  function prefersReducedMotion() {
    return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  }
  // 漂浮/磁吸只在有精确指针的设备上启用（触屏设备没有 hover，不做无意义位移）
  var HOVER_FINE = !!(window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches);
  var MOBILE_TOUCH = !HOVER_FINE && !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches);   // 手机/平板触屏（备用：判断设备形态）

  /* --- 切页入场：内容块按顺序错峰从下方飘上来 --- */
  var RISE_STEP = 55;    // 相邻两块的错峰间隔（ms）
  var RISE_MAX = 10;     // 最多叠加的档位，长列表末尾不至于等太久
  var RISE_DUR = 560;    // 与 CSS 里 riseIn 的时长保持一致
  var _riseUntil = 0;    // 入场窗口：只有刚切页这段时间新渲染出来的内容才播动画
  function playRise() {
    if (!fxOn('rise')) return;
    var kids = viewEl.children;
    var n = 0;
    for (var i = 0; i < kids.length; i++) {
      var el = kids[i];
      if (el.classList.contains('rise')) continue;
      var d = Math.min(n, RISE_MAX) * RISE_STEP;
      el.style.setProperty('--rise-d', d + 'ms');
      el.classList.add('rise');
      (function (node, delay) {
        setTimeout(function () {
          node.classList.remove('rise');
          node.style.removeProperty('--rise-d');
        }, RISE_DUR + delay + 120);
      })(el, d);
      n++;
    }
  }
  function initRiseObserver() {
    if (!window.MutationObserver) return;
    new MutationObserver(function () {
      if (performance.now() > _riseUntil) return; // 只对「刚切页」这段时间的渲染播入场
      playRise();
    }).observe(viewEl, { childList: true });
  }

  /* --- 悬停：微微漂浮（每块随机方向）+ 向鼠标方向轻微吸附，移出后缓缓淡回原位 --- */
  var _hfCur = null, _hfRaf = 0;
  var _hfLive = [];   // 正在被 JS 接管位移的元素（悬停中或恢复中）
  /* 悬停流体化：悬停时文字框就轻微液化（不需要拖动），移出后缓缓平复。
     与拖拽共用 #ld-fluid 位移滤镜——拖拽期间参数归 ldShape 管，这里让位。 */
  var _hfFluidK = 0, _hfFluidEl = null;
  function hfFluidStep(now, liveEl) {
    /* 大文本框（cost≥2）不做悬停整框流体：悬停是常态操作，逐帧整框噪声的代价比拖拽还亏
       （拖拽是短暂交互，悬停可能停很久）。其余档位照做，幅度按档衰减。 */
    var want = !!liveEl && fxOn('drip') && HOVER_FINE && !_lq.drag &&
               !(liveEl._shakeUntil && performance.now() < liveEl._shakeUntil) &&
               ldCostOfEl(liveEl) < 2;
    var el = want ? liveEl : _hfFluidEl;
    if (!el) return;
    if (_lq.shake && _lq.shake.el === el) return;   // 点击抖动期间滤镜归抖动管，这里让位
    if (want) {
      if (_hfFluidK < 0.02 && _ldFluidTurb) {      // 新一轮悬停：按档把噪声八度定好
        _ldFluidTurb.setAttribute('numOctaves', ldCostOfEl(el) === 0 ? '2' : '1');
      }
      _hfFluidEl = el; _hfFluidK += (1 - _hfFluidK) * 0.08;
    }
    else {
      _hfFluidK += (0 - _hfFluidK) * 0.028;
      if (_hfFluidK < 0.02) _hfFluidK = 0;
    }
    var dragOnEl = _lq.drag && _lq.drag.el === el;
    if (want && !_ldSvg && !dragOnEl) ldLayer();   // 悬停流体化也要滤镜定义存在（首次可能还没拖过）
    if ((_hfFluidK <= 0 || !_ldSvg) && !dragOnEl) {   // 平复完毕 / 覆盖层已回收：摘滤镜
      if (el.style.filter) el.style.filter = '';
      if (_hfFluidK <= 0) {
        _hfFluidEl = null;
        if (!_lq.drag && !_lq.shake && !_lq.drops.length) lqIdle();   // 没别的事就把覆盖层收掉
      }
      return;
    }
    if (dragOnEl) return;
    if (_ldFluidDisp) {
      var hfk = ldCostOfEl(el) === 1 ? 0.65 : 1;   // 中等框：位移幅度降档
      _ldFluidDisp.setAttribute('scale', (_hfFluidK * (2.4 + Math.sin(now * 0.0011) * 0.9) * hfk).toFixed(2));
      _ldFluidOff.setAttribute('dx', (Math.sin(now * 0.0007) * 18 * hfk).toFixed(1));
      _ldFluidOff.setAttribute('dy', (Math.cos(now * 0.0005 + 1.3) * 14 * hfk).toFixed(1));
      if (el.style.filter !== 'url(#ld-fluid)') el.style.filter = 'url(#ld-fluid)';
    }
  }
  function hfState(el) {
    if (!el._hf) {
      el._hf = {
        ang: Math.random() * Math.PI * 2, // 漂浮方向，每个方块都不同
        w: 0.9 + Math.random() * 0.9,     // 漂浮快慢
        amp: 1.8 + Math.random() * 1.6,   // 漂浮幅度（px）
        ph: Math.random() * Math.PI * 2,  // 随机相位，避免所有方块同频起伏
        nx: 0, ny: 0, x: 0, y: 0, t0: 0
      };
    }
    return el._hf;
  }
  function hfPush(el) { if (_hfLive.indexOf(el) < 0) _hfLive.push(el); }
  function hfPull(el) {
    var i = _hfLive.indexOf(el);
    if (i >= 0) _hfLive.splice(i, 1);
    el.style.transform = '';
    if (!(_lq.drag && _lq.drag.el === el)) el.style.filter = '';   // 悬停流体化滤镜一并摘掉
  }
  function hfFrame(now) {
    _hfRaf = _hfLive.length ? requestAnimationFrame(hfFrame) : 0;
    var kk = fxK(); // 速度条决定跟手快慢；恢复慢一档 → 移出时是慢慢淡回
    hfFluidStep(now, _hfCur);   // 悬停流体化：强度渐入渐出（拖拽期间自动让位）
    for (var i = _hfLive.length - 1; i >= 0; i--) {
      var el = _hfLive[i], st = el._hf, live = (el === _hfCur);
      if (_lq.shake && _lq.shake.el === el) continue;   // 点击抖动接管位移，这里别抢写
      var tx = 0, ty = 0;
      if (live) {
        var wob = Math.sin(((now - st.t0) / 1000) * st.w * Math.PI * 1.7 + st.ph) * st.amp;
        tx = st.nx * 9 + Math.cos(st.ang) * wob;     // 吸附 + 随机方向漂浮
        ty = st.ny * 9 + Math.sin(st.ang) * wob - 3; // 基础上抬 3px，更有「被吸住」的手感
      }
      var k = live ? kk.in : kk.out;
      st.x += (tx - st.x) * k;
      st.y += (ty - st.y) * k;
      var d = Math.sqrt(st.x * st.x + st.y * st.y);
      if (!live && d < 0.12) { hfPull(el); continue; }
      el.style.transform = 'translate3d(' + st.x.toFixed(2) + 'px,' + st.y.toFixed(2) + 'px,0) scale(' +
        (1 + 0.012 * Math.min(1, d / 6)).toFixed(4) + ')';
    }
  }
  function hfTarget(node) {
    if (!node || !node.closest) return null;
    var el = node.closest('#view .glass, #view .quick-grid a');
    if (!el || el.closest('.modal')) return null;
    if (_lq.drag && _lq.drag.el === el) return null;                      // 液泡拖拽接管了这个文字框
    if (el._shakeUntil && performance.now() < el._shakeUntil) return null; // 正在「抖一下」，位移交给抖动
    return el;
  }
  function hfEnter(el) {
    if (_hfCur === el) return;
    if (!fxOn('hover')) return;
    if (_hfCur) _hfCur.classList.remove('hf-on'); // 掠过上一个方块时立即撤掉它的高亮
    _hfCur = el;
    var st = hfState(el);
    st.nx = 0; st.ny = 0; st.t0 = performance.now();
    el.classList.add('hf-on');
    hfPush(el);
    if (!_hfRaf) _hfRaf = requestAnimationFrame(hfFrame);
  }
  function hfLeave(el) {
    if (_hfCur !== el) return;
    _hfCur = null;
    el.classList.remove('hf-on');
    if (!_hfRaf) _hfRaf = requestAnimationFrame(hfFrame);
  }
  /* 拖拽/抖动结束后指针若仍停在框上：立即接回悬停（流体化不用等鼠标再动） */
  function hfReenter(el, x, y) {
    if (!fxOn('hover') || !HOVER_FINE) return;
    if (_lq.drag || (_lq.shake && _lq.shake.el === el)) return;
    var t = document.elementFromPoint(x, y);
    if (!t || !el.contains(t)) return;
    if (_hfCur && _hfCur !== el) _hfCur.classList.remove('hf-on');
    _hfCur = el;
    var st = hfState(el);
    st.t0 = st.t0 || performance.now();
    el.classList.add('hf-on');
    hfPush(el);
    if (!_hfRaf) _hfRaf = requestAnimationFrame(hfFrame);
  }
  function hfAim(el, e) {
    var st = el._hf;
    if (!st) return;
    var r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;
    // 鼠标相对方块中心的比例（-1..1）：就是吸附的方向与力度
    st.nx = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / (r.width / 2 + 40)));
    st.ny = Math.max(-1, Math.min(1, (e.clientY - (r.top + r.height / 2)) / (r.height / 2 + 40)));
  }
  function initHoverFloat() {
    if (!HOVER_FINE) return; // 触屏没有 hover，不做无意义位移（总开关由 applyFx 同步）
    viewEl.addEventListener('pointermove', function (e) {
      if (!fxOn('hover')) { if (_hfCur) hfLeave(_hfCur); return; }
      var el = hfTarget(e.target);
      if (!el) { if (_hfCur) hfLeave(_hfCur); return; }
      if (el !== _hfCur) hfEnter(el);
      hfAim(el, e);
    }, { passive: true });
    viewEl.addEventListener('pointerleave', function () { if (_hfCur) hfLeave(_hfCur); });
    window.addEventListener('blur', function () { if (_hfCur) hfLeave(_hfCur); });
  }

  /* ---------------- 动效偏好（访客可调，只存在本机浏览器） ----------------
     on 是总开关（对应「一键关闭全部高级动效」），speed 只影响悬浮淡入 / 恢复的快慢 */
  var FX_DEF = { on: true, hover: true, rise: true, drip: true, speed: 38 };
  // 手机/平板触屏只默认关「液泡类特效」（轻点抖动 + 振落小水珠，即 drip）：
  // 切页入场动画不变照常播；想开水珠可在 ✨ 动效设置里手动打开。
  var FX = (function () {
    var o = { on: true, hover: true, rise: true, drip: !MOBILE_TOUCH, speed: FX_DEF.speed, userTouched: false };
    try {
      var raw = localStorage.getItem('d6cf_fx');
      if (raw) {
        var s = JSON.parse(raw) || {};
        if (s.userTouched === true) {
          // 只有用户在动效面板里手动设置过的偏好才照单全收；
          // 历史版本会静默自动保存，触屏设备上不能把「默认关」又顶回「开」
          o.userTouched = true;
          ['on', 'hover', 'rise', 'drip'].forEach(function (k) { if (typeof s[k] === 'boolean') o[k] = s[k]; });
          if (typeof s.speed === 'number' && isFinite(s.speed)) o.speed = Math.max(0, Math.min(100, s.speed));
        }
      }
    } catch (e) {}
    return o;
  })();
  var FX_SYS_REDUCED = prefersReducedMotion(); // 系统级「减少动态效果」一票否决
  function fxSave() {
    try { localStorage.setItem('d6cf_fx', JSON.stringify(FX)); } catch (e) {}
  }
  function fxOn(key) {
    if (FX_SYS_REDUCED || !FX.on) return false;
    return key ? FX[key] !== false : true;
  }
  // 速度条（0..100）→ 逐帧插值系数：整体更慢更缓（用户反馈：还是太快）
  function fxK() {
    var s = Math.max(0, Math.min(100, Number(FX.speed) || 0));
    var kIn = 0.018 + (s / 100) * 0.19;
    return { in: kIn, out: kIn * 0.32 };   // 恢复比跟手更缓一截
  }
  function fxSpeedLabel(v) { return v <= 30 ? '很慢' : v <= 55 ? '慢' : v <= 78 ? '标准' : v <= 92 ? '快' : '很快'; }

  function applyFx() {
    var root = document.documentElement;
    var hoverLive = fxOn('hover') && HOVER_FINE;
    root.classList.toggle('fx-off', !fxOn());
    root.classList.toggle('has-hover-float', hoverLive);
    if (!hoverLive) { // 立刻收摊：撤高亮、清位移、停帧
      if (_hfCur) { _hfCur.classList.remove('hf-on'); _hfCur = null; }
      for (var i = _hfLive.length - 1; i >= 0; i--) hfPull(_hfLive[i]);
      if (_hfRaf) { cancelAnimationFrame(_hfRaf); _hfRaf = 0; }
    }
    if (!fxOn('rise')) {
      Array.prototype.forEach.call(viewEl.querySelectorAll('.rise'), function (el) {
        el.classList.remove('rise');
        el.style.removeProperty('--rise-d');
      });
    }
    if (!fxOn('drip')) ldCancel();
    updateFxPanel();
    fxSave();
  }
  function updateFxPanel() {
    var p = $('#fx-panel');
    if (!p) return;
    var on = fxOn();
    var all = $('#fx-all');
    all.textContent = on ? '一键关闭全部高级动效' : '恢复全部高级动效';
    all.classList.toggle('primary', on);
    all.classList.toggle('ghost', !on);
    ['hover', 'rise', 'drip'].forEach(function (k) {
      var box = $('#fx-' + k);
      box.checked = FX[k] !== false;
      box.disabled = !on;
      box.parentNode.classList.toggle('dim', !on);
    });
    var sp = $('#fx-speed');
    sp.value = FX.speed;
    sp.disabled = !on || FX.hover === false;
    $('#fx-speed-val').textContent = fxSpeedLabel(FX.speed);
    $('#fxp-hint').textContent = FX_SYS_REDUCED
      ? '检测到系统开启了「减少动态效果」，本站已自动停用全部动效。'
      : (on
        ? '拖速度条可调悬浮淡入 / 恢复的快慢；按住任意文字框往外拖，会拉出一颗液泡。'
        : '已关闭全部高级动效：切页干脆利落，悬停只剩纯 CSS 的手感，拖拽也不会再冒泡。');
  }
  function initFxPanel() {
    var p = $('#fx-panel');
    if (!p) return;
    function setPanel(open) {
      p.classList.toggle('open', !!open);
      document.querySelectorAll('.fx-toggle').forEach(function (b) { b.classList.toggle('on', !!open); });
    }
    document.querySelectorAll('.fx-toggle').forEach(function (b) {
      b.addEventListener('click', function (e) { e.stopPropagation(); setPanel(!p.classList.contains('open')); });
    });
    $('#fxp-close').addEventListener('click', function () { setPanel(false); });
    $('#fx-all').addEventListener('click', function () {
      FX.on = !FX.on;
      if (FX.on) { FX.hover = true; FX.rise = true; FX.drip = true; }
      FX.userTouched = true;
      applyFx();
      toast(FX.on ? '已恢复全部高级动效 ✨' : '已关闭全部高级动效，切页更干脆');
    });
    ['hover', 'rise', 'drip'].forEach(function (k) {
      $('#fx-' + k).addEventListener('change', function () { FX[k] = this.checked; FX.userTouched = true; applyFx(); });
    });
    var sp = $('#fx-speed');
    sp.addEventListener('input', function () {
      FX.speed = Number(this.value);
      $('#fx-speed-val').textContent = fxSpeedLabel(FX.speed);
    });
    sp.addEventListener('change', function () { FX.speed = Number(this.value); fxSave(); });
    document.addEventListener('click', function (e) {
      if (!p.classList.contains('open') || !e.target.closest) return;
      if (e.target.closest('#fx-panel') || e.target.closest('.fx-toggle')) return;
      setPanel(false);
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setPanel(false); });
    updateFxPanel();
  }

  /* ---------------- 失重液泡（太空水滴） ----------------
     按住文字框把指针拖出框外：
     ① 框的轮廓被 clip-path 真的「咬掉」一块不规则缺口，同时整块框像流体一样
        低频蠕动（不再是方方正正的长条）；
     ② 一颗不规则的液泡跟着鼠标走，它会自己晃、被速度拉长，和框没有连接；
     ③ 拖动轨迹上会掉下小液泡，在失重里慢慢飘、慢慢消散。
     松手：液泡沿弧线缓缓飞回，缺口先朝它「伸手」，接触后被吸回去抹平，
          最后在框上留一圈很快散掉的涟漪（没有机械式的回弹过冲）。
     轻点文字框：框会抖一下，并从四周振落几颗小液泡。

     ⚠️ 历史坑：缺口曾经用多层 mask-image 实现，永远看不到效果 —— 多层 mask 默认是
     「相加」合成（mask-composite: add），几层挖洞叠加会互相填平，等于整块都不透明。
     现在改为 clip-path 多边形，轮廓是真的被剪掉，缺一块肉眼可见。 */
  var SVGNS = 'http://www.w3.org/2000/svg';
  var LD_MIN = 12;        // 指针离框多远才算「拉出来」（px）
  var LD_FULL = 150;      // 到这个距离液泡长到最大
  var LD_TRAIL_GAP = 18;  // 轨迹上每移动这么多 px 掉一颗小液泡
  var LD_DROP_MAX = 30;   // 同时在飘的小液泡上限
  var LD_HEAL_KEEP = 0.5; // 自愈后一直保留的那一小块缺口（相对最大咬痕的比例）
  var _lq = { drag: null, shake: null, drops: [], raf: 0, last: 0 };
  var _ldSvg = null, _ldBlob = null, _ldHi = null, _ldHi2 = null, _ldDrops = null, _ldRim = null;
  var _ldFluidTurb = null, _ldFluidOff = null, _ldFluidDisp = null;   // 流体位移滤镜（文字也跟着变形）
  var _ldOutlines = {};   // 卡片基准轮廓缓存（尺寸 + 圆角 → 采样点与外法线）
  var _ldBlockAt = 0, _ldSel = '';
  var LD_FILL = 'rgba(255,255,255,0.8)';
  /* --- 性能分级（大文本框卡顿的根治点）---
     整框滤镜的开销与「框面积」成正比：feTurbulence 是逐像素 CPU 生成（桌面/手机都不走 GPU），
     feDisplacementMap 与大半径 CSS 投影也要按整框区域重算，帧帧如此。
     文字框一大（写文章/长文页），逐帧重算整框必然掉帧 —— 所以按面积分三档，
     大框自动降档：0 = 全特效；1 = 单八度噪声 + 小位移 + 小投影；2 = 不上整框滤镜（保留咬痕/涟漪）。 */
  var LD_COST_MID = 3.2e5;     // ≤ ~0.32MP（约 700×450）：全特效
  var LD_COST_HIGH = 9e5;      // ≤ ~0.9MP（约 1000×900）：降一档
  function ldCostOf(area) { return area <= LD_COST_MID ? 0 : (area <= LD_COST_HIGH ? 1 : 2); }
  var _ldCostEl = null;
  function ldCostOfEl(el) {    // 同一元素只量一次（读 offset 尺寸会触发布局，别逐帧读）
    if (_ldCostEl !== el) {
      _ldCostEl = el;
      el._ldCost = ldCostOf(el.offsetWidth * el.offsetHeight);
    }
    return el._ldCost || 0;
  }

  function ldLayer() {
    if (_ldSvg && _ldSvg.parentNode) return _ldSvg;
    var svg = document.createElementNS(SVGNS, 'svg');
    svg.setAttribute('class', 'liquid-layer');
    svg.setAttribute('aria-hidden', 'true');
    var defs = document.createElementNS(SVGNS, 'defs');
    var filter = document.createElementNS(SVGNS, 'filter');
    filter.setAttribute('id', 'ld-soft');
    /* 滤镜区域只留必要余量（原 240%）：区域面积直接等于每帧模糊的像素量 */
    filter.setAttribute('x', '-35%'); filter.setAttribute('y', '-35%');
    filter.setAttribute('width', '170%'); filter.setAttribute('height', '170%');
    var ds = document.createElementNS(SVGNS, 'feDropShadow');
    ds.setAttribute('dx', '0'); ds.setAttribute('dy', '5');
    ds.setAttribute('stdDeviation', '5');
    ds.setAttribute('flood-color', '#5a82af'); ds.setAttribute('flood-opacity', '0.28');
    filter.appendChild(ds);
    defs.appendChild(filter);
    /* 小液泡专用的轻投影：区域按自身小尺寸放开百分比（单颗几十 px，开销可忽略），
       不再和主液泡共用一个大滤镜组 —— 散开时那个组的并集包围盒约等于整屏 */
    var dsoft = document.createElementNS(SVGNS, 'filter');
    dsoft.setAttribute('id', 'ld-dsoft');
    dsoft.setAttribute('x', '-250%'); dsoft.setAttribute('y', '-250%');
    dsoft.setAttribute('width', '600%'); dsoft.setAttribute('height', '600%');
    var dds = document.createElementNS(SVGNS, 'feDropShadow');
    dds.setAttribute('dx', '0'); dds.setAttribute('dy', '3');
    dds.setAttribute('stdDeviation', '3');
    dds.setAttribute('flood-color', '#5a82af'); dds.setAttribute('flood-opacity', '0.26');
    dsoft.appendChild(dds);
    defs.appendChild(dsoft);
    // 小水珠自己的渐变：不跟卡片变色，永远是「无色透明的水」
    var grad = document.createElementNS(SVGNS, 'radialGradient');
    grad.setAttribute('id', 'ld-dropg');
    grad.setAttribute('cx', '0.34'); grad.setAttribute('cy', '0.28'); grad.setAttribute('r', '0.85');
    [['0%', '#ffffff', '0.95'], ['45%', '#cfe6fb', '0.9'], ['100%', '#9fc6ee', '0.82']].forEach(function (s) {
      var st = document.createElementNS(SVGNS, 'stop');
      st.setAttribute('offset', s[0]); st.setAttribute('stop-color', s[1]); st.setAttribute('stop-opacity', s[2]);
      grad.appendChild(st);
    });
    defs.appendChild(grad);
    // 流体位移滤镜：拖拽期间整个文字框（含文字）跟着液流一起变形
    var fluid = document.createElementNS(SVGNS, 'filter');
    fluid.setAttribute('id', 'ld-fluid');
    fluid.setAttribute('x', '-30%'); fluid.setAttribute('y', '-30%');
    fluid.setAttribute('width', '160%'); fluid.setAttribute('height', '160%');
    var turb = document.createElementNS(SVGNS, 'feTurbulence');
    turb.setAttribute('type', 'fractalNoise');
    turb.setAttribute('baseFrequency', '0.011 0.019');
    turb.setAttribute('numOctaves', '2');
    turb.setAttribute('seed', String(1 + Math.floor(Math.random() * 900)));
    turb.setAttribute('result', 'n');
    var fo = document.createElementNS(SVGNS, 'feOffset');
    fo.setAttribute('in', 'n'); fo.setAttribute('result', 'n2');
    fo.setAttribute('dx', '0'); fo.setAttribute('dy', '0');
    var disp = document.createElementNS(SVGNS, 'feDisplacementMap');
    disp.setAttribute('in', 'SourceGraphic'); disp.setAttribute('in2', 'n2');
    disp.setAttribute('scale', '0');
    disp.setAttribute('xChannelSelector', 'R'); disp.setAttribute('yChannelSelector', 'G');
    fluid.appendChild(turb); fluid.appendChild(fo); fluid.appendChild(disp);
    defs.appendChild(fluid);
    _ldFluidTurb = turb; _ldFluidOff = fo; _ldFluidDisp = disp;
    var g = document.createElementNS(SVGNS, 'g');
    g.setAttribute('filter', 'url(#ld-soft)');
    _ldDrops = document.createElementNS(SVGNS, 'g');   // 小液泡（轨迹 / 抖动掉落）
    _ldBlob = document.createElementNS(SVGNS, 'path'); // 主液泡：不规则闭合曲线
    _ldBlob.setAttribute('class', 'ld-blob');
    _ldHi = document.createElementNS(SVGNS, 'ellipse');
    _ldHi.setAttribute('class', 'ld-hi');
    _ldHi2 = document.createElementNS(SVGNS, 'circle'); // 小圆点高光（萌）
    _ldHi2.setAttribute('class', 'ld-hi');
    _ldRim = document.createElementNS(SVGNS, 'path');  // 咬痕边缘的液面张力高光（贴着真实缺口轮廓）
    _ldRim.setAttribute('class', 'ld-rim');
    g.appendChild(_ldRim); g.appendChild(_ldBlob); g.appendChild(_ldHi); g.appendChild(_ldHi2);
    /* 小液泡挂在自己那个「无滤镜」组里（每颗自带 ld-dsoft 轻投影）：
       与主液泡分开后，ld-soft 只需覆盖主液泡周围那一小块 */
    var gDrops = document.createElementNS(SVGNS, 'g');
    gDrops.appendChild(_ldDrops);
    svg.appendChild(defs); svg.appendChild(gDrops); svg.appendChild(g);
    document.body.appendChild(svg);
    _ldSvg = svg;
    return svg;
  }
  function ldRemoveLayer() {
    if (_ldSvg && _ldSvg.parentNode) _ldSvg.parentNode.removeChild(_ldSvg);
    _ldSvg = null; _ldBlob = null; _ldHi = null; _ldHi2 = null; _ldDrops = null; _ldRim = null;
    _ldFluidTurb = null; _ldFluidOff = null; _ldFluidDisp = null;
  }
  function ldSetInk(el, prop, val) { if (el) el.style.setProperty(prop, val); }

  /* --- 会话矩形：拖拽期间用开始时量到的「未变形」矩形 + 滚动补偿，
         避免逐帧读到的变换结果反过来影响几何，产生抖动 --- */
  function ldRect() {
    var s = _lq.drag;
    var dx = window.scrollX - s.scroll.x, dy = window.scrollY - s.scroll.y;
    var l = s.base.left - dx, t = s.base.top - dy;
    return { left: l, top: t, right: l + s.base.width, bottom: t + s.base.height,
             width: s.base.width, height: s.base.height };
  }
  // 客户端坐标 → 元素内部坐标（把 translate/rotate/scale 逆变换回去）
  function ldLocal(st, cx, cy) {
    var r = ldRect();
    var ox = r.left + r.width / 2, oy = r.top + r.height / 2;
    var dx = cx - ox - st.tx, dy = cy - oy - st.ty;
    var ct = Math.cos(-st.th), sn = Math.sin(-st.th);
    var ax = dx * ct - dy * sn, ay = dx * sn + dy * ct;   // R(-θ)
    ax /= st.sx; ay /= st.sy;                             // S⁻¹
    var bx = ax * Math.cos(st.th) - ay * Math.sin(st.th);  // R(θ)
    var by = ax * Math.sin(st.th) + ay * Math.cos(st.th);
    return { x: ox + bx - r.left, y: oy + by - r.top };
  }
  // 元素内部坐标 → 客户端坐标（ldLocal 的逆；缺口高光弧要画在卡片变形后的真实边缘上）
  function ldToClient(st, lx, ly) {
    var r = ldRect();
    var ox = r.left + r.width / 2, oy = r.top + r.height / 2;
    var ax = (lx - r.width / 2) * st.sx, ay = (ly - r.height / 2) * st.sy;
    var ct = Math.cos(-st.th), sn = Math.sin(-st.th);
    var bx = ax * ct - ay * sn, by = ax * sn + ay * ct;    // R(-θ)
    var cx = bx * Math.cos(st.th) - by * Math.sin(st.th);  // R(θ)
    var cy = bx * Math.sin(st.th) + by * Math.cos(st.th);
    return { x: ox + cx + st.tx, y: oy + cy + st.ty };
  }

  /* --- 不规则闭合曲线：极坐标半径带谐波抖动（每颗液泡谐波参数随机 → 不重样），
         再按速度方向拉长 --- */
  function lqSmooth(p) {
    var n = p.length, d = 'M' + p[0][0].toFixed(2) + ' ' + p[0][1].toFixed(2);
    for (var i = 0; i < n; i++) {
      var p0 = p[(i - 1 + n) % n], p1 = p[i], p2 = p[(i + 1) % n], p3 = p[(i + 2) % n];
      var c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      var c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += 'C' + c1x.toFixed(2) + ' ' + c1y.toFixed(2) + ' ' +
                  c2x.toFixed(2) + ' ' + c2y.toFixed(2) + ' ' +
                  p2[0].toFixed(2) + ' ' + p2[1].toFixed(2);
    }
    return d + 'Z';
  }
  function lqBlobPath(cx, cy, R, ph, vx, vy, hp, neck, clip) {
    var N = 15;
    var sp = Math.sqrt(vx * vx + vy * vy);
    var beta = sp > 1 ? Math.atan2(vy, vx) : 0;
    var q = Math.min(0.3, sp * 0.006);   // 越快越像被拉长的一滴
    var tail = 0;                        // 拉丝期：朝运动方向那头鼓、尾端收窄 → 从缺口拔出来的水滴
    if (neck > 0.01) {
      q = Math.max(q, 0.1 + neck * 0.2);
      tail = neck * 0.38;
    }
    var pts = [];
    for (var i = 0; i < N; i++) {
      var th = (i / N) * Math.PI * 2;
      var k = 1 + hp.a3 * Math.sin(3 * th + ph * 1.15 + hp.p3) + hp.a5 * Math.sin(5 * th - ph * 0.83 + hp.p5);
      if (q > 0.001 || tail > 0.001) {
        var c2 = Math.cos(th - beta);
        if (q > 0.001) k *= 1 + q * (c2 * c2 - 0.5);
        if (tail > 0.001) k *= 1 + tail * c2;
      }
      var bx2 = cx + Math.cos(th) * R * k, by2 = cy + Math.sin(th) * R * k;
      /* 塞回去的吞入断面：液泡画进卡内的部分被「吸进去」——
         投影回边缘线（消失前沿从贴框端向外端扫），断面再朝卡内微微鼓出弯月面 */
      if (clip && clip.k > 0.01) {
        var din = (bx2 - clip.x) * clip.nx + (by2 - clip.y) * clip.ny;
        if (din > 0) {
          bx2 -= clip.nx * din * clip.k;
          by2 -= clip.ny * din * clip.k;
          var tx2 = -clip.ny, ty2 = clip.nx;
          var tt2 = (bx2 - clip.x) * tx2 + (by2 - clip.y) * ty2;
          var fall = 1 - (tt2 * tt2) / (R * 1.15 * (R * 1.15));
          if (fall > 0) {
            var bump = Math.min(7, R * 0.4) * clip.k * fall;
            bx2 += clip.nx * bump; by2 += clip.ny * bump;
          }
        }
      }
      pts.push([bx2, by2]);
    }
    return lqSmooth(pts);
  }

  /* --- 卡片基准轮廓：圆角矩形的采样点 + 外法线（按尺寸缓存，逐帧只做变形） --- */
  function ldOutline(el, W, H) {
    var rad = parseFloat(getComputedStyle(el).borderTopLeftRadius);
    if (!(rad >= 0)) rad = 20;
    rad = Math.max(0, Math.min(rad, Math.min(W, H) / 2 - 0.5));
    var key = Math.round(W) + 'x' + Math.round(H) + 'r' + rad.toFixed(1);
    if (_ldOutlines[key]) return _ldOutlines[key];
    var pts = [];
    function edge(ax, ay, bx, by, nx, ny) {
      var len = Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay));
      var step = Math.max(14, Math.min(44, len / 12));
      var n = Math.max(1, Math.round(len / step));
      for (var i = 0; i < n; i++) { var t = i / n; pts.push([ax + (bx - ax) * t, ay + (by - ay) * t, nx, ny]); }
    }
    function arc(ccx, ccy, a0, a1) {
      var n = Math.max(2, Math.round(Math.abs(a1 - a0) * rad / 7));
      for (var i = 0; i <= n; i++) {
        var a = a0 + (a1 - a0) * i / n;
        pts.push([ccx + Math.cos(a) * rad, ccy + Math.sin(a) * rad, Math.cos(a), Math.sin(a)]);
      }
    }
    if (rad > 0.6) {
      edge(rad, 0, W - rad, 0, 0, -1);
      arc(W - rad, rad, -Math.PI / 2, 0);
      edge(W, rad, W, H - rad, 1, 0);
      arc(W - rad, H - rad, 0, Math.PI / 2);
      edge(W - rad, H, rad, H, 0, 1);
      arc(rad, H - rad, Math.PI / 2, Math.PI);
      edge(0, H - rad, 0, rad, -1, 0);
      arc(rad, rad, Math.PI, Math.PI * 1.5);
    } else {
      edge(0, 0, W, 0, 0, -1); edge(W, 0, W, H, 1, 0);
      edge(W, H, 0, H, 0, 1); edge(0, H, 0, 0, -1, 0);
    }
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i], q = out[out.length - 1];
      if (q && Math.abs(p[0] - q[0]) < 0.08 && Math.abs(p[1] - q[1]) < 0.08) continue;
      out.push(p);
    }
    _ldOutlines[key] = { W: W, H: H, rad: rad, pts: out };
    return _ldOutlines[key];
  }

  /* --- 框的轮廓 = 基准圆角矩形 + 流体蠕动 + 不规则咬痕 + 融合伸手 + 余波涟漪，
         逐帧写成 clip-path 多边形。这是「框真的缺一块」的关键实现。
         咬痕中心 st.bl、融合参考点 st.reachLocal 都是框内本地坐标。 --- */
  function ldShape(st, now) {
    var el = st.el, o = st.out;
    if (!o) return;
    var W = o.W, H = o.H, cx = W / 2, cy = H / 2;
    var g = st.g, bite = st.bite;
    var R = st.biteR * bite;          // 咬痕影响半径
    var depth = Math.min(R * 1.08, Math.min(W, H) * 0.5);   // 咬进去的深度（明显、但不破坏框体）
    var reach = st.reach, rip = st.rip, rl = st.reachLocal;
    if (g < 0.015 && bite < 0.02 && reach < 0.02 && rip < 0.06) {
      if (st.shaped) {
        st.shaped = false; st.poly = '';
        el.style.clipPath = ''; el.style.webkitClipPath = '';
        el.style.filter = ''; el.style.willChange = '';
        if (_ldRim) _ldRim.setAttribute('d', '');
      }
      return;
    }
    // 咬痕中心：液泡在框上的最近点，再往框内挪一点 → 豁口明确咬进边缘
    var lp = ldLocal(st, st.bx, st.by);
    var exl = Math.max(0, Math.min(lp.x, W)), eyl = Math.max(0, Math.min(lp.y, H));
    var ox = lp.x - exl, oy = lp.y - eyl;
    var od = Math.sqrt(ox * ox + oy * oy);
    var blx = exl, bly = eyl;
    if (od > 0.4 && bite > 0.02) { blx -= ox / od * R * 0.3; bly -= oy / od * R * 0.3; }
    st.bl = { x: blx, y: bly };
    var pts = o.pts, n = pts.length, t = now * 0.0016;
    // 流体滤镜参数：拉得越厉害变形越大，噪声缓慢流动 → 文字和内容跟着液流晃
    // 大框（cost≥2）不上整框流体滤镜：逐帧整框噪声+位移是卡顿主因；cost=1 时幅度收到 0.6
    if (_ldFluidDisp && st.cost < 2) {
      var fk = st.cost === 1 ? 0.6 : 1;
      if (g > 0.04) {
        _ldFluidDisp.setAttribute('scale', ((g * 10 + Math.sin(now * 0.0027 + st.ph) * g * 2.5) * fk).toFixed(2));
        _ldFluidOff.setAttribute('dx', (Math.sin(now * 0.0012 + st.ph) * 24 * fk).toFixed(1));
        _ldFluidOff.setAttribute('dy', (Math.cos(now * 0.0009 + st.ph * 0.7) * 18 * fk).toFixed(1));
      } else if (_ldFluidDisp.getAttribute('scale') !== '0') {
        _ldFluidDisp.setAttribute('scale', '0');
      }
    }
    var poly = '', runs = [], cur = null;
    for (var i = 0; i < n; i++) {
      var a = pts[i], b = pts[(i + 1) % n];
      var segL = Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]));
      var mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
      var k = 1;
      if (bite > 0.02 && R > 1) {
        var qx = mx - st.bl.x, qy = my - st.bl.y;
        if (qx * qx + qy * qy < R * 1.9 * R * 1.9) k = Math.max(k, Math.min(26, Math.ceil(segL / 4.5)));
      }
      if (reach > 0.02 && rl) {
        var ux = mx - rl.x, uy = my - rl.y, uR = st.biteR * 0.9 + 26;
        if (ux * ux + uy * uy < uR * uR) k = Math.max(k, Math.min(26, Math.ceil(segL / 5)));
      }
      for (var j = 0; j < k; j++) {
        var tt = j / k;
        var nx = a[2] + (b[2] - a[2]) * tt, ny = a[3] + (b[3] - a[3]) * tt;
        var nl = Math.sqrt(nx * nx + ny * ny) || 1; nx /= nl; ny /= nl;
        var x = a[0] + (b[0] - a[0]) * tt, y = a[1] + (b[1] - a[1]) * tt;
        var ang = Math.atan2(y - cy, x - cx);
        // ① 整块框像流体：沿法线低频起伏（每张卡片的谐波随机 → 每次不重样）
        var wob = g * (st.wob[0] * Math.sin(3 * ang + st.ph * 1.15 + st.wph[0]) +
                       st.wob[1] * Math.sin(5 * ang - st.ph * 0.82 + st.wph[1]) +
                       st.wob[2] * Math.sin(7 * ang + st.ph * 0.55 + st.wph[2]));
        x += nx * wob; y += ny * wob;
        // ② 咬痕：朝框内挖一块，边缘随时间蠕动 → 不规则
        var f = 0;
        if (bite > 0.02 && R > 1) {
          var dx2 = x - st.bl.x, dy2 = y - st.bl.y;
          var dd = Math.sqrt(dx2 * dx2 + dy2 * dy2);
          var aa = Math.atan2(dy2, dx2);
          // 缺口轮廓要「有机」：三重角度瓣（2/3/5 次）+ 各自慢漂移 + 整体呼吸，
          // 叠起来是一条明显起伏的波浪边，不会读成规则圆弧
          var rw = R * (1 + 0.2 * Math.sin(2 * aa + st.wph[0] + t * 0.9) +
                        0.13 * Math.sin(3 * aa - st.wph[1] - t * 0.55) +
                        0.08 * Math.sin(5 * aa + st.wph[2] + t * 1.3)) *
                   (1 + 0.1 * Math.sin(t * 1.4 + st.wph[0])) * 1.14;
          if (dd < rw) {
            f = 1 - dd / rw; if (f > 1) f = 1;
            f = f * f * (3 - 2 * f);
            var ix = cx - x, iy = cy - y, il = Math.sqrt(ix * ix + iy * iy) || 1;
            var dep = depth * (1 - reach * 0.7);
            x += ix / il * dep * f; y += iy / il * dep * f;
          }
        }
        // ③ 融合：缺口朝飞回来的液泡鼓出去「接住」它
        if (reach > 0.02 && rl) {
          var gxx = x - rl.x, gyy = y - rl.y;
          var gd = Math.sqrt(gxx * gxx + gyy * gyy), gR = st.biteR * 0.9 + 26;
          if (gd < gR) {
            var f2 = 1 - gd / gR; f2 = f2 * f2 * (3 - 2 * f2);
            var push = reach * f2 * (st.biteR * 0.5);   // 伸手鼓出去的幅度（明显接住）
            x += nx * push; y += ny * push;
          }
        }
        // ④ 吸入后的余波：一圈沿轮廓传播、很快散掉的涟漪
        if (rip > 0.06) {
          var rp = rip * Math.sin(ang * 2.6 - (now - st.ripT0) * 0.015);
          x += nx * rp; y += ny * rp;
        }
        poly += (poly ? ',' : '') + x.toFixed(1) + 'px ' + y.toFixed(1) + 'px';
        if (f > 0.08) {
          var i2x = cx - x, i2y = cy - y, i2l = Math.sqrt(i2x * i2x + i2y * i2y) || 1;
          if (!cur) { cur = []; runs.push(cur); }
          cur.push([x + i2x / i2l * 1.6, y + i2y / i2l * 1.6]);
        } else if (cur) cur = null;
      }
    }
    /* 大框降频写 DOM：clip-path 变化会整框重绘，面积越大越贵 —— cost≥1 时隔帧写一次（≈30fps，
       蠕动本身就慢，肉眼几乎看不出），把每帧的最大开销砍一半 */
    var ldSkip = st.cost >= 1 && ((st.fno = (st.fno || 0) + 1) & 1);
    if (poly !== st.poly && !ldSkip) {
      st.poly = poly;
      st.shaped = true;
      el.style.webkitClipPath = 'polygon(' + poly + ')';
      el.style.clipPath = 'polygon(' + poly + ')';
      el.style.willChange = 'clip-path, transform';
      // 流体状态挂位移滤镜（文字跟着变形），有缺口时投影跟着轮廓走
      // 大框不上整框滤镜：url(#ld-fluid)（整框噪声）与大半径投影都按面积计费，cost=2 时全部省掉
      var fstr = '';
      if (g > 0.04 && st.cost < 2) fstr += 'url(#ld-fluid) ';
      if (bite > 0.03) {
        if (st.cost === 0) fstr += 'drop-shadow(0 14px 30px rgba(90, 130, 175, 0.22))';
        else if (st.cost === 1) fstr += 'drop-shadow(0 10px 18px rgba(90, 130, 175, 0.2))';
      }
      el.style.filter = fstr;
      st.shadowed = st.shadowed || bite > 0.03;
    }
    // 缺口边缘的液面张力高光：贴着真实咬痕的轮廓描一圈（不再是框里凭空一条线）
    if (_ldRim && !ldSkip) {
      var run = null;
      for (var r3 = 0; r3 < runs.length; r3++) if (!run || runs[r3].length > run.length) run = runs[r3];
      if (!run || run.length < 3) _ldRim.setAttribute('d', '');
      else {
        var dstr = '';
        for (var s2 = 0; s2 < run.length; s2++) {
          var cp = ldToClient(st, run[s2][0], run[s2][1]);
          dstr += (s2 === 0 ? 'M' : 'L') + cp.x.toFixed(2) + ' ' + cp.y.toFixed(2);
        }
        _ldRim.setAttribute('d', dstr);
      }
    }
  }

  /* --- 小液泡：轨迹掉落 / 抖动振落，失重里慢慢飘、慢慢消散 --- */
  function lqSpawnDrop(x, y, r, vx, vy, life, fill) {
    if (!_ldSvg) ldLayer();
    if (_lq.drops.length >= LD_DROP_MAX) {
      var old = _lq.drops.shift();
      if (old.el && old.el.parentNode) old.el.parentNode.removeChild(old.el);
    }
    var d = { x: x, y: y, vx: vx, vy: vy, r0: r, r: r, t0: performance.now(), life: life,
              ph: Math.random() * 6.283, el: document.createElementNS(SVGNS, 'circle') };
    d.el.setAttribute('class', 'ld-drop');
    d.el.setAttribute('fill', 'url(#ld-dropg)');   // 水珠用固定「透明水」渐变，不跟卡片变色
    d.el.setAttribute('filter', 'url(#ld-dsoft)'); // 轻投影跟着每颗走（小区域，几乎无开销）
    _ldDrops.appendChild(d.el);
    _lq.drops.push(d);
    lqKick();
    return d;
  }
  function lqDropStep(now, dt) {
    for (var i = _lq.drops.length - 1; i >= 0; i--) {
      var d = _lq.drops[i];
      var t = (now - d.t0) / d.life;
      if (t >= 1) {
        if (d.el.parentNode) d.el.parentNode.removeChild(d.el);
        _lq.drops.splice(i, 1);
        continue;
      }
      d.x += d.vx * dt; d.y += d.vy * dt;
      var damp = Math.pow(0.45, dt);   // 失重：几乎不减速，只慢慢停下来
      d.vx *= damp; d.vy *= damp;
      d.r = d.r0 * (1 - 0.5 * t);
      var wob = 1 + 0.18 * Math.sin(now * 0.007 + d.ph);
      d.el.setAttribute('cx', d.x.toFixed(2));
      d.el.setAttribute('cy', d.y.toFixed(2));
      d.el.setAttribute('r', Math.max(0.35, d.r * wob).toFixed(2));
      d.el.setAttribute('opacity', Math.max(0, 1 - t * t).toFixed(3));
    }
  }

  /* --- 轻点文字框：抖一下 + 四周振落小液泡（抖动也走流体滤镜，不硬邦邦） --- */
  function lqShake(el, x, y) {
    el.style.transition = 'none';
    el.style.willChange = 'transform, filter';
    if (!_ldSvg) ldLayer();   // 抖动也要流体滤镜定义（可能还没拖过、覆盖层不存在）
    var shCost = ldCostOfEl(el);
    if (_ldFluidTurb) _ldFluidTurb.setAttribute('numOctaves', shCost === 0 ? '2' : '1');
    _lq.shake = {
      el: el, t0: performance.now(), dur: 760, cost: shCost,
      ang: Math.random() * Math.PI * 2,
      amp: 3.4 + Math.random() * 2.6,
      sAmp: 0.007 + Math.random() * 0.006,  // 刚性挤压减小：液感交给位移滤镜
      x: x, y: y                            // 记下指针位置：抖完接回悬停流体化用
    };
    el._shakeUntil = _lq.shake.t0 + _lq.shake.dur;
    lqKick();
  }
  function lqEndShake(restore) {
    var s = _lq.shake;
    if (!s) return;
    _lq.shake = null;
    s.el._shakeUntil = 0;
    s.el.style.transform = '';
    if (restore) {
      s.el.style.willChange = '';
      // 交给拖拽时不摘滤镜（ldShape 接管参数）；自然结束才摘，悬停流体化会无缝接回
      if (!(_lq.drag && _lq.drag.el === s.el) && s.el.style.filter) s.el.style.filter = '';
      hfReenter(s.el, s.x, s.y);
      (function (el) {
        requestAnimationFrame(function () { requestAnimationFrame(function () { el.style.transition = ''; }); });
      })(s.el);
    }
  }
  function lqShakeStep(now) {
    var s = _lq.shake;
    if (!s) return;
    var t = (now - s.t0) / s.dur;
    if (t >= 1) { lqEndShake(true); return; }
    var k = Math.exp(-5.5 * t) * Math.sin(t * Math.PI * 5);
    s.el.style.transform =
      'translate3d(' + (Math.cos(s.ang) * s.amp * k).toFixed(2) + 'px,' +
                        (Math.sin(s.ang) * s.amp * k).toFixed(2) + 'px,0) ' +
      'scale(' + (1 + s.sAmp * k).toFixed(4) + ',' + (1 - s.sAmp * k * 0.85).toFixed(4) + ')';
    // 抖动也是流体：整块内容跟着液流晃，幅度随抖动包络起伏
    // 大框（cost≥2）不挂整框滤镜：手机上轻点长文页那种大框，760ms 的逐帧整框噪声顿挫肉眼可见
    if (_ldFluidDisp && !(_lq.drag && _lq.drag.el === s.el)) {
      if ((s.cost || 0) >= 2) {
        if (s.el.style.filter) s.el.style.filter = '';
      } else {
        var fk = Math.min(1, 0.35 + Math.abs(k) * 1.6) * (s.cost === 1 ? 0.65 : 1);
        _ldFluidDisp.setAttribute('scale', (fk * (2.6 + Math.sin(now * 0.0021) * 0.8)).toFixed(2));
        _ldFluidOff.setAttribute('dx', (Math.sin(now * 0.0016) * 16).toFixed(1));
        _ldFluidOff.setAttribute('dy', (Math.cos(now * 0.0013 + 1.1) * 13).toFixed(1));
        if (s.el.style.filter !== 'url(#ld-fluid)') s.el.style.filter = 'url(#ld-fluid)';
      }
    }
  }
  function lqSprinkle(el, x, y) {
    var r = el.getBoundingClientRect();
    var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    var n = 7 + Math.floor(Math.random() * 5);
    for (var i = 0; i < n; i++) {
      var px, py;
      if (Math.random() < 0.75) {   // 沿边框取点：像被抖下来的水珠
        var per = r.width * 2 + r.height * 2, t = Math.random() * per;
        if (t < r.width) { px = r.left + t; py = r.top; }
        else if (t < r.width + r.height) { px = r.right; py = r.top + (t - r.width); }
        else if (t < r.width * 2 + r.height) { px = r.left + (t - r.width - r.height); py = r.bottom; }
        else { px = r.left; py = r.bottom - (t - r.width * 2 - r.height); }
      } else {
        px = x + (Math.random() - 0.5) * r.width * 0.6;
        py = y + (Math.random() - 0.5) * r.height * 0.6;
      }
      var a = Math.atan2(py - cy, px - cx) + (Math.random() - 0.5) * 1.1;
      var sp = 24 + Math.random() * 68;
      lqSpawnDrop(px, py, 2 + Math.random() * 4.5, Math.cos(a) * sp, Math.sin(a) * sp,
        950 + Math.random() * 750);
    }
  }

  /* --- 主循环：拖拽 / 抖动 / 小液泡共用一个 rAF --- */
  function lqKick() {
    if (_ldSvg && _ldSvg.classList.contains('ld-out')) _ldSvg.classList.remove('ld-out'); // 复活覆盖层
    if (!_lq.raf) { _lq.last = 0; _lq.raf = requestAnimationFrame(lqFrame); }
  }
  function lqIdle() {
    if (!_ldSvg) return;
    if (_ldBlob) _ldBlob.setAttribute('d', '');
    if (_ldHi) { _ldHi.setAttribute('rx', '0'); _ldHi.setAttribute('ry', '0'); }
    if (_ldHi2) _ldHi2.setAttribute('r', '0');
    if (_ldRim) _ldRim.setAttribute('d', '');
    if (_ldSvg.classList.contains('ld-out')) return;
    _ldSvg.classList.add('ld-out');
    setTimeout(function () {
      if (!_ldSvg) return;
      if (_lq.drag || _lq.shake || _lq.drops.length) { _ldSvg.classList.remove('ld-out'); return; }
      ldRemoveLayer();
    }, 300);
  }
  function lqFrame(now) {
    var dt = _lq.last ? Math.min(0.05, (now - _lq.last) / 1000) : 0.016;
    _lq.last = now;
    var busy = false;
    if (_lq.drag) { lqDragStep(_lq.drag, now, dt); busy = true; }
    if (_lq.shake) { lqShakeStep(now); busy = true; }
    if (_lq.drops.length) { lqDropStep(now, dt); busy = true; }
    if (busy) _lq.raf = requestAnimationFrame(lqFrame);
    else { _lq.raf = 0; _lq.last = 0; lqIdle(); }
  }

  function lqDragStep(st, now, dt) {
    if (!st.el.isConnected) { ldTeardown(st); return; }
    if (st.phase === 'drag') {
      /* 掉帧自适应：整框滤镜在不同机器上的开销差异很大 —— 连续 6 帧偏慢就再降一档兜底
         （中等框在小显卡上也可能吃力；降到 2 档即摘掉整框滤镜） */
      if (dt > 0.030) {
        st.jankN = (st.jankN || 0) + 1;
        if (st.jankN >= 6 && (st.cost || 0) < 2) {
          st.cost = (st.cost || 0) + 1; st.jankN = 0; st.fno = 0;
          if (_ldFluidTurb && st.cost === 1) _ldFluidTurb.setAttribute('numOctaves', '1');
          if (st.cost >= 2 && st.el.style.filter) st.el.style.filter = '';
        }
      } else if (st.jankN) st.jankN = 0;
      var k = Math.min(1, dt * 6);       // 更懒的跟随 → 失重感
      var px0 = st.bx, py0 = st.by;
      st.bx += (st.px - st.bx) * k;      // 液泡滞后一点点跟手
      st.by += (st.py - st.by) * k;
      st.vx = (st.bx - px0) / Math.max(dt, 0.008);
      st.vy = (st.by - py0) / Math.max(dt, 0.008);
      var r = ldRect();
      var ex = Math.max(r.left, Math.min(st.bx, r.right));
      var ey = Math.max(r.top, Math.min(st.by, r.bottom));
      var dEdge = Math.sqrt((st.bx - ex) * (st.bx - ex) + (st.by - ey) * (st.by - ey));
      var g = Math.max(0, Math.min(1, (dEdge - LD_MIN) / (LD_FULL - LD_MIN)));
      st.g = g;
      /* 分离过程：液泡是从缺口里「拔」出来的——
         拔断之前（sep<1）液泡挂在离开点上、被拉成尖尾水滴；超过阈值才算掐断，pop 弹跳这时才开始 */
      var sep = Math.max(0, Math.min(1, g / 0.42));
      var sepe = sep * sep * (3 - 2 * sep);
      var exp2 = Math.max(r.left, Math.min(st.px, r.right));
      var eyp = Math.max(r.top, Math.min(st.py, r.bottom));
      if (sepe >= 1 && !st.bornAt) st.bornAt = now;  // 掐断时刻
      st.neck = 1 - sepe;                            // 拉丝程度（传给形状函数做尖尾）
      // 缺口生命史：拖出来「立刻缺一块」，随后慢慢自愈、但一直留一小块；
      // 往回塞时缺口跟着液泡一起合上——液泡塞回去多少，缺口就填回来多少
      if (g > st.biteMax) st.biteMax = g;            // 越拉越大（即时，不渐变）
      st.heal += (LD_HEAL_KEEP - st.heal) * Math.min(1, dt * 1.15);  // 自愈到残留值
      var closeK = st.biteMax > 0.001 ? Math.min(1, g / st.biteMax) : 1;
      st.bite = st.biteMax * st.heal * closeK;
      /* 塞回去的熔化进度：目标 = 推回程度（1-closeK），限速渐进——贴边后约 0.4s 平滑熔完，
         而不是一到边上就「顿一下」换状态；熔完闩住（防止清零后 closeK 回弹导致液泡复现），
         重新往外拉才解锁 */
      var meltT = st.biteMax > 0.001 ? 1 - closeK : 0;
      if (st.meltDone) meltT = 1;
      if (!st.meltDone && meltT >= 0.995 && st.biteMax > 0.18) {
        st.meltDone = true;
        st.ripT0 = now; st.ripMax = Math.min(9, st.biteMax * 14 + 3);   // 熔完才起余波涟漪
        st.biteMax = 0; st.heal = 1;                                    // 缺口记录清零：下次再拉是崭新的一次
      }
      if (st.meltDone && g > 0.06) st.meltDone = false;                 // 又往外拉了：允许液泡重新探出
      if (st.dMelt === undefined) st.dMelt = 0;
      if (meltT > st.dMelt) st.dMelt = Math.min(meltT, st.dMelt + dt * 2.4);
      else st.dMelt = Math.max(meltT, st.dMelt - dt * 5);
      var dme = st.dMelt; dme = dme * dme * (3 - 2 * dme);
      if (st.ripT0) {
        var rt0 = (now - st.ripT0) / 800;
        st.rip = st.ripMax * Math.exp(-3.4 * rt0);
        if (st.rip < 0.05) { st.rip = 0; st.ripT0 = 0; }
      }
      st.reach = 0;
      // 液泡大小：拉得越远越大；中心贴边/进卡时平滑沉入；推回熔化时随进度不断变小
      var pin2 = Math.min(st.bx - r.left, r.right - st.bx, st.by - r.top, r.bottom - st.by);
      var sdt = pin2 < 0 ? dEdge : -pin2;   // 中心到边的带符号距离（外正内负）
      var vis = Math.max(0, Math.min(1, (sdt + 10) / 20));
      vis = vis * vis * (3 - 2 * vis);
      st.R = (5 + 39 * Math.pow(g, 0.55)) * st.sizeK * st.cardK * vis * (1 - dme);
      st.drawX = exp2 + (st.bx - exp2) * sepe;
      st.drawY = eyp + (st.by - eyp) * sepe;
      st.fph = (st.fph || 0) + dt * 1.4;
      st.drawX += Math.cos(st.fph) * 2.6 * sepe;     // 失重微漂（独立于跟手的慢速漂移）
      st.drawY += Math.sin(st.fph * 1.31 + 1.2) * 2.6 * sepe;
      st.ph += dt * 2.6;
      /* 塞回去的吞入：画进卡内的部分随熔化进度被吸到边缘线上（消失前沿从贴框端
         向外端延展），连续无状态切换——中心在卡外用朝卡心的法线，进卡后用最近边法线 */
      st.clip = null;
      if (dme > 0.01 && st.R > 1) {
        var cpx = Math.max(r.left, Math.min(st.drawX, r.right));
        var cpy = Math.max(r.top, Math.min(st.drawY, r.bottom));
        var ox = st.drawX - cpx, oy = st.drawY - cpy;
        var od = Math.sqrt(ox * ox + oy * oy);
        if (od < 0.5) {
          var dL = st.drawX - r.left, dR2 = r.right - st.drawX;
          var dT = st.drawY - r.top, dB = r.bottom - st.drawY;
          var dmn = Math.min(dL, dR2, dT, dB);
          var mnx = 0, mny = 0;
          if (dmn === dL) mnx = 1; else if (dmn === dR2) mnx = -1;
          else if (dmn === dT) mny = 1; else mny = -1;   // 朝卡内的单位法线
          st.clip = { x: st.drawX + mnx * dmn, y: st.drawY + mny * dmn, nx: mnx, ny: mny, k: dme };
        } else {
          st.clip = { x: cpx, y: cpy, nx: -ox / od, ny: -oy / od, k: dme };   // 朝卡内吸掉前沿
        }
      }
      // 轨迹：走一段就掉一颗小液泡
      var moved = Math.sqrt((st.bx - st.lastX) * (st.bx - st.lastX) + (st.by - st.lastY) * (st.by - st.lastY));
      if (g > 0.22 && moved > LD_TRAIL_GAP) {
        st.lastX = st.bx; st.lastY = st.by;
        var back = Math.atan2(st.vy, st.vx) + Math.PI + (Math.random() - 0.5) * 1.2;
        var sp = 12 + Math.random() * 42;
        lqSpawnDrop(st.bx + Math.cos(back) * st.R * 0.7, st.drawY + Math.sin(back) * st.R * 0.7,
          1.8 + Math.random() * 4, Math.cos(back) * sp, Math.sin(back) * sp,
          900 + Math.random() * 700);
      }
    } else {
      /* 松手：液泡飞回，飞行与融合是同一个动作——
         一旦液泡和卡片开始有交集（边缘碰到缺口），就立刻开始熔：
         重叠越多熔得越多（缺口同步合拢），中心抵达边缘时刚好熔完。
         不再是「先飞回去、到了才开始融合」。 */
      var p = Math.min(1, (now - st.t0) / st.dur);
      var r2 = ldRect();
      var txx = Math.max(r2.left, Math.min(st.hx, r2.right));
      var tyy = Math.max(r2.top, Math.min(st.hy, r2.bottom));
      var fp = Math.min(1, p / 0.62);
      var fly = fp * fp * (3 - 2 * fp);                             // 飞行：先加速后减速、贴边即止
      st.drawX = st.hx + (txx - st.hx) * fly;
      st.drawY = st.hy + (tyy - st.hy) * fly - Math.sin(fp * Math.PI) * 6;
      var dEdge2 = Math.sqrt((st.drawX - txx) * (st.drawX - txx) + (st.drawY - tyy) * (st.drawY - tyy));
      // 融合进度：随重叠加深；限速熔化，贴边松手也不会瞬间消失
      var mT = Math.max(0, Math.min(1, 1 - dEdge2 / (st.hR * 0.95)));
      if (st.mMelt === undefined) st.mMelt = 0;
      st.mMelt = Math.min(mT, st.mMelt + dt * 2.4);
      var mm = st.mMelt; mm = mm * mm * (3 - 2 * mm);
      st.R = st.hR * (1 - mm);
      st.bite = st.bite0 * (1 - mm);
      // 熔化裁切：越过边缘线的部分被吸进缺口；中心进卡后贴边熔（同拖拽分支）
      st.clip = null;
      if (mm > 0.01 && st.R > 1) {
        var cpx = Math.max(r2.left, Math.min(st.drawX, r2.right));
        var cpy = Math.max(r2.top, Math.min(st.drawY, r2.bottom));
        var ox2 = st.drawX - cpx, oy2 = st.drawY - cpy;
        var od2 = Math.sqrt(ox2 * ox2 + oy2 * oy2);
        if (od2 < 0.5) {
          var dL2 = st.drawX - r2.left, dR3 = r2.right - st.drawX;
          var dT2 = st.drawY - r2.top, dB2 = r2.bottom - st.drawY;
          var dpen2 = Math.min(dL2, dR3, dT2, dB2);
          var mnx2 = 0, mny2 = 0;
          if (dpen2 === dL2) mnx2 = 1; else if (dpen2 === dR3) mnx2 = -1;
          else if (dpen2 === dT2) mny2 = 1; else mny2 = -1;
          var hold2 = Math.min(dpen2, 3);
          st.drawX -= mnx2 * (dpen2 - hold2); st.drawY -= mny2 * (dpen2 - hold2);
          st.clip = { x: st.drawX + mnx2 * hold2, y: st.drawY + mny2 * hold2, nx: mnx2, ny: mny2, k: mm };
        } else {
          st.clip = { x: cpx, y: cpy, nx: -ox2 / od2, ny: -oy2 / od2, k: mm };   // 朝卡内方向吃掉前沿
        }
      }
      st.bx += (st.drawX - st.bx) * Math.min(1, dt * 9);   // 缺口中心跟着被吞入的液泡走
      st.by += (st.drawY - st.by) * Math.min(1, dt * 9);
      // 用真实帧间速度做拉伸：飞得快时沿运动方向拉长，减速时缩回圆滴——和水滴一样
      if (st._bpx === undefined) { st._bpx = st.drawX; st._bpy = st.drawY; }
      st.vx = (st.drawX - st._bpx) / Math.max(dt, 0.008);
      st.vy = (st.drawY - st._bpy) / Math.max(dt, 0.008);
      st._bpx = st.drawX; st._bpy = st.drawY;
      st.g += (0 - st.g) * Math.min(1, dt * 2.6);                    // 蠕动跟着平静下来
      st.neck = 0;                                                   // 飞回时是完整的圆滴（不再带尖尾）
      st.ph += dt * 3.4;
      // 缺口朝液泡「张嘴」：靠近时鼓出去接，熔掉时跟着合上
      st.reachLocal = ldLocal(st, st.drawX, st.drawY);
      st.reach = Math.max(0, Math.min(1, (95 - dEdge2) / 75)) * (1 - mm);
      if (!st.ripT0 && mm >= 1) {                                    // 熔完：涟漪起
        st.ripT0 = now;
        st.ripMax = Math.min(12, st.hR * 0.55 + 3);
      }
      if (st.ripT0) {
        var rt = (now - st.ripT0) / 800;
        st.rip = st.ripMax * Math.exp(-3.4 * rt);
      }
      if (p >= 1) { ldTeardown(st); return; }
    }
    lqDrawBlob(st);
    ldShape(st, now);
  }
  /* 融合凸起已移除：改由 ldShape 里的「缺口朝液泡伸手 + 吸入后余波涟漪」实现，
     不再往框外贴一块独立图形（那个看起来太假）。 */
  function lqDrawBlob(st) {
    if (!_ldBlob) return;
    if (st.R < 1.5) {
      _ldBlob.setAttribute('d', '');
      _ldHi.setAttribute('rx', '0'); _ldHi.setAttribute('ry', '0');
      if (_ldHi2) _ldHi2.setAttribute('r', '0');
      return;
    }
    // 出生时「啵」地弹一下：先过冲再回稳，更可爱
    var pop = 1;
    if (st.bornAt) {
      var age = performance.now() - st.bornAt;
      if (age < 620) pop = 1 + 0.2 * Math.exp(-age / 170) * Math.sin(age / 62);
    }
    var RR = st.R * pop;
    _ldBlob.setAttribute('d', lqBlobPath(st.drawX, st.drawY, RR, st.ph, st.vx, st.vy, st.hp, st.neck || 0, st.clip));
    _ldHi.setAttribute('cx', (st.drawX - RR * 0.32).toFixed(2));
    _ldHi.setAttribute('cy', (st.drawY - RR * 0.36).toFixed(2));
    _ldHi.setAttribute('rx', (RR * 0.3).toFixed(2));
    _ldHi.setAttribute('ry', (RR * 0.2).toFixed(2));
    if (_ldHi2) {
      _ldHi2.setAttribute('cx', (st.drawX + RR * 0.42).toFixed(2));
      _ldHi2.setAttribute('cy', (st.drawY + RR * 0.3).toFixed(2));
      _ldHi2.setAttribute('r', Math.max(0.8, RR * 0.08).toFixed(2));
    }
  }

  function ldSelLock(on) {
    if (on) {
      _ldSel = document.body.style.userSelect || '';
      document.body.style.userSelect = 'none';
      document.body.style.webkitUserSelect = 'none';
      document.body.style.webkitTouchCallout = 'none';   // 触屏长按不弹选择/菜单
      document.body.style.cursor = 'grabbing';
    } else {
      document.body.style.userSelect = _ldSel;
      document.body.style.webkitUserSelect = '';
      document.body.style.webkitTouchCallout = '';
      document.body.style.cursor = '';
    }
  }
  function ldTeardown(st) {
    if (_lq.drag === st) _lq.drag = null;
    var el = st.el;
    // 剪影复原：clip-path / drop-shadow / 变形全部撤掉
    el.style.clipPath = ''; el.style.webkitClipPath = '';
    el.style.filter = '';
    st.poly = ''; st.shaped = false; st.shadowed = false;
    el.style.transform = '';
    el.style.willChange = '';
    // 只是「点一下」的话，让抖动自己跑完（它的 transform 还在用，别急着恢复 transition）
    var shaking = _lq.shake && _lq.shake.el === el;
    if (shaking && st.moved) { lqEndShake(false); shaking = false; }
    if (!shaking) {
      (function (node) {
        requestAnimationFrame(function () { requestAnimationFrame(function () { node.style.transition = ''; }); });
      })(el);
    }
    if (_ldRim) _ldRim.setAttribute('d', '');
    ldSelLock(false);
    hfReenter(el, st.px, st.py);   // 指针还停在框上的话，立即接回悬停流体化
    lqIdle();   // 没有别的事情就淡出并清掉覆盖层
  }
  function ldCancel() {
    if (_lq.drag) ldTeardown(_lq.drag);
    if (_lq.shake) lqEndShake(true);
    for (var i = _lq.drops.length - 1; i >= 0; i--) {
      var d = _lq.drops[i];
      if (d.el && d.el.parentNode) d.el.parentNode.removeChild(d.el);
    }
    _lq.drops.length = 0;
    if (_lq.raf) { cancelAnimationFrame(_lq.raf); _lq.raf = 0; }
    _lq.last = 0;
    if (_ldSvg) ldRemoveLayer();   // 动效已全部关停，覆盖层直接清掉
  }

  function ldMove(e) {
    var st = _lq.drag;
    if (!st) return;
    st.px = e.clientX; st.py = e.clientY;
    if (!st.moved && Math.abs(e.clientX - st.startX) + Math.abs(e.clientY - st.startY) > 6) {
      st.moved = true;
      if (_lq.shake && _lq.shake.el === st.el) lqEndShake(false); // 开始拖了，抖动让位给流体
    }
  }
  function ldStart(e) {
    if (!fxOn('drip') || e.button !== 0) return;
    if (!e.target || !e.target.closest) return;
    if (e.target.closest('.modal, input, textarea, select, button, a, label, canvas, audio, video, [contenteditable]')) return;
    var el = e.target.closest('#view .glass');
    if (!el) return;
    if (!HOVER_FINE) {
      // 手机端：不做拖拽液泡（跟滚动抢手势），保留轻点抖动 + 振落小水珠
      lqShake(el, e.clientX, e.clientY);
      lqSprinkle(el, e.clientX, e.clientY);
      lqKick();
      return;
    }
    // 上一次还没收尾：飞回/残留的会话直接强制结束，保证随时都能再拖
    if (_lq.drag) { var old = _lq.drag; ldTeardown(old); }
    // 接管这个元素：撤掉悬浮漂浮留下的位移与高亮，再量取「未变形」的尺寸
    if (_hfCur === el) { _hfCur = null; el.classList.remove('hf-on'); }
    hfPull(el);
    el.style.transition = 'none';
    el.style.willChange = 'transform';
    var rect = el.getBoundingClientRect();
    var color = getComputedStyle(el).backgroundColor || LD_FILL;
    ldLayer();
    ldSetInk(_ldSvg, '--ld-fill', color);
    // 每次都不一样：轮廓的蠕动谐波、咬痕大小都随机；越大的文字框咬痕与液泡都越大
    var area = rect.width * rect.height;
    var wobK = Math.max(3.5, Math.min(12, Math.min(rect.width, rect.height) * 0.05));
    var cost = ldCostOf(area);
    // 降档：feTurbulence 的八度直接决定 CPU 开销（2→1 约省一半），大框不需要那么细的噪声
    if (_ldFluidTurb) _ldFluidTurb.setAttribute('numOctaves', cost === 0 ? '2' : '1');
    _lq.drag = {
      el: el, color: color, cost: cost,
      base: { left: rect.left, top: rect.top, width: rect.width, height: rect.height },
      scroll: { x: window.scrollX, y: window.scrollY },
      out: ldOutline(el, el.offsetWidth, el.offsetHeight),
      bl: { x: rect.width / 2, y: rect.height / 2 },
      px: e.clientX, py: e.clientY, bx: e.clientX, by: e.clientY,
      drawX: e.clientX, drawY: e.clientY, vx: 0, vy: 0,
      lastX: e.clientX, lastY: e.clientY,
      R: 0, g: 0,
      bite: 0, biteMax: 0, heal: 1,
      biteR: Math.max(54, Math.min(150, Math.min(rect.width, rect.height) * 0.42)),
      sizeK: 0.85 + Math.random() * 0.35,
      cardK: Math.max(0.75, Math.min(1.9, Math.sqrt(area) / 280)),
      hp: { a3: 0.08 + Math.random() * 0.09, a5: 0.04 + Math.random() * 0.05,
            p3: Math.random() * 6.283, p5: Math.random() * 6.283 },
      // 轮廓蠕动：三档谐波，幅度与相位都随机 → 每次拖出来的形状都不一样
      wob: [wobK * (0.45 + Math.random() * 0.3), wobK * (0.24 + Math.random() * 0.2),
            wobK * (0.12 + Math.random() * 0.14)],
      wph: [Math.random() * 6.283, Math.random() * 6.283, Math.random() * 6.283],
      reach: 0, reachLocal: null, rip: 0, ripT0: 0, ripMax: 0,
      bornAt: 0, ph: Math.random() * 6.283,
      tx: 0, ty: 0, th: 0, sx: 1, sy: 1,
      poly: '', shaped: false, shadowed: false,
      phase: 'drag', t0: performance.now(),
      startX: e.clientX, startY: e.clientY, moved: false
    };
    ldSelLock(true);
    lqShake(el, e.clientX, e.clientY);   // 按下先抖一下，并振落几颗小水珠
    lqSprinkle(el, e.clientX, e.clientY);
    lqKick();
    window.addEventListener('pointermove', ldMove, { passive: true });
    window.addEventListener('pointerup', ldUp);
    window.addEventListener('pointercancel', ldUp);
  }
  function ldUp() {
    var st = _lq.drag;
    window.removeEventListener('pointermove', ldMove);
    window.removeEventListener('pointerup', ldUp);
    window.removeEventListener('pointercancel', ldUp);
    if (!st) return;
    if (st.moved) _ldBlockAt = performance.now(); // 拖过的这次不当作点击，避免误进文章
    if (!st.moved || st.bite < 0.06) { ldTeardown(st); return; }
    // 松手：液泡缓缓飞回缺口，缺口伸手接住 → 吸回去 → 余波涟漪
    st.phase = 'back';
    st.t0 = performance.now();
    // 飞行时长随距离伸缩——近距离松手不必慢慢爬一秒多
    var rr0 = ldRect();
    var tx0 = Math.max(rr0.left, Math.min(st.drawX, rr0.right));
    var ty0 = Math.max(rr0.top, Math.min(st.drawY, rr0.bottom));
    var d0 = Math.abs(st.drawX - tx0) + Math.abs(st.drawY - ty0);
    st.dur = 600 + Math.min(700, d0 * 1.6);
    st.mMelt = 0;   // 融合进度归零：一有交集就开始熔
    st.hx = st.drawX; st.hy = st.drawY; st.hR = st.R; st.bite0 = st.bite;
    st.reach = 0; st.rip = 0; st.ripT0 = 0;
    st.reachLocal = ldLocal(st, st.drawX, st.drawY);
  }
  function initLiquidDrip() {
    viewEl.addEventListener('pointerdown', ldStart);   // 触屏同样走 Pointer Events
    // 拖过之后吞掉随之而来的那次 click（捕获阶段拦截，卡片上的跳转不会触发）
    document.addEventListener('click', function (e) {
      if (!_ldBlockAt || performance.now() - _ldBlockAt > 320) return;
      _ldBlockAt = 0;
      e.preventDefault();
      e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
    }, true);
  }

  function renderRoute(page, parts) {
    var known = true;
    if (page === 'home') renderHome();
    else if (page === 'posts') renderPosts();
    else if (page === 'post') renderPost(parts[1]);
    else if (page === 'music') renderMusic();
    else if (page === 'gallery') renderGallery();
    else if (page === 'board') renderBoard();
    else if (page === 'about') renderAbout();
    else if (page === 'privacy') renderPrivacy();
    else if (page === 'thanks') renderThanks();
    else if (page === 'me') renderMe();
    else if (page === 'user') renderUserProfile(parts[1]);
    else known = false;
    if (page === 'admin') { renderAdmin(); return; }
    if (!known) renderHome();   // 只有未知路由才兜底回首页（各页渲染函数自己写 DOM，不能被覆盖）
  }
  function route() {
    var hash = location.hash.replace(/^#\/?/, '') || 'home';
    var parts = hash.split('/');
    var page = parts[0];
    state.view = page;
    // 侧边栏高亮
    document.querySelectorAll('.side-nav a').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-route') === page);
    });
    // 移动端收起菜单
    $('#sidebar').classList.remove('open');

    // 切页入场：内容块错峰从下方飘上来（异步页面由 MutationObserver 兜住）
    _riseUntil = performance.now() + 2000;
    if (page !== 'home') dmBgClear(); // 弹幕只在首页加载，离开时收掉背景板层
    var ret = renderRoute(page, parts);
    playRise();
    return ret;
  }

  /* ---------------- 各页面 ---------------- */
  /* 外链/入口小图标：站长在「图标自定义」里传过图就用图，否则用 emoji */
  function iconTag(key, fallback) {
    var icons = (state.settings && state.settings.icons) || {};
    return icons[key]
      ? '<img class="ico-img" src="' + esc(icons[key]) + '" alt="">'
      : '<span class="ico-emoji">' + fallback + '</span>';
  }

  function renderHome() {
    var s = state.settings;
    var recent = state.posts.slice(0, 3);
    var quick = [];
    if (s.bilibiliUrl) quick.push(['bilibili', '📺', 'B站主页', s.bilibiliUrl, true]);
    if (s.douyinUrl) quick.push(['douyin', '🎶', '抖音主页', s.douyinUrl, true]);
    quick.push(['music', '🎵', '听听音乐', '#/music', false]);
    quick.push(['gallery', '🖼️', '看看图库', '#/gallery', false]);
    // 公告：配了跳转文章且文章真实存在时渲染成链接，点击直达
    var nl = s.noticeLink ? String(s.noticeLink) : '';
    var nlOk = nl && (state.posts || []).some(function (p) { return String(p.id) === nl; });
    var noticeHtml = s.notice
      ? (nlOk
        ? '<a class="notice notice-link" href="#/post/' + esc(nl) + '" title="点击查看公告提到的文章">📢 ' + esc(s.notice) + '<span class="notice-go"> →</span></a>'
        : '<div class="notice">📢 ' + esc(s.notice) + '</div>')
      : '';
    viewEl.innerHTML =
      '<div class="hero glass">' +
        '<h2>' + esc(T('hero_welcome')) + ' <span class="blue">' + esc(s.siteTitle || '') + '</span></h2>' +
        '<p>' + esc(s.subtitle || '') + '</p>' +
        noticeHtml +
        '<div class="hero-stats"><span class="hstat">📅 建站于 ' + esc(s.createdAt || '-') + '</span><span class="hstat">👣 第 <b id="hero-visits">' + (window._visits || '…') + '</b> 位访客</span></div>' +
      '</div>' +
      '<div class="dm-mod glass">' +
        '<div class="dm-head"><h2>' + esc(T('dm_title')) + '</h2><p class="dm-slogan">' + esc(T('dm_slogan')) + '</p>' +
          '<button type="button" class="dm-mode-btn" id="dm-mode-btn" title="切换弹幕飘在整页背景板上，还是收回到这个弹幕墙里"></button>' +
        '</div>' +
        '<div class="dm-stage" id="dm-stage" aria-label="弹幕墙"><p class="dm-empty" id="dm-empty" style="display:none">' + esc(T('dm_empty')) + '</p></div>' +
        '<div id="dm-form-box"></div>' +
      '</div>' +
      (recent.length ? recent.map(postCardHtml).join('') : '<div class="empty-tip glass">' + esc(T('posts_empty')) + '</div>') +
      '<div class="page-head glass" style="margin-top:24px"><h2>' + esc(T('quick_title')) + '</h2>' +
        '<div class="quick-grid">' +
          quick.map(function (q) {
            return '<a href="' + esc(q[3]) + '"' + (q[4] ? ' target="_blank" rel="noopener"' : '') + '>' +
              iconTag(q[0], q[1]) + '<span class="ql-txt">' + esc(q[2]) + '</span></a>';
          }).join('') +
        '</div>' +
      '</div>';
    dmInitMode(); // 背景板 / 弹幕墙模式恢复 + 切换按钮文案
    loadDanmaku();
  }

  /* ---------------- 首页弹幕墙 ---------------- */
  var DM_SIZES = [14, 18, 24, 32];
  var DM_SIZE_NAMES = { 14: '小', 18: '中', 24: '大', 32: '特大' };
  var DM_STYLES = ['default', 'blue', 'teal', 'pink', 'gold', 'glow', 'outline', 'rainbow', 'neon', 'bubble'];
  var DM_STYLE_NAMES = {
    default: '默认白', blue: '天依蓝', teal: '青绿', pink: '桃粉', gold: '暖金',
    glow: '荧光', outline: '描边', rainbow: '彩虹渐变', neon: '霓虹（我的主题色）', bubble: '气泡（我的主题色）'
  };
  /* 弹幕显示位置：bg = 背景板模式（默认，弹幕飘在整页壁纸上的玻璃卡片后面）；
     stage = 弹幕墙模式（收回到首页的深色舞台框里）。访客自己的选择存 localStorage */
  var dmMode = (function () {
    try { return localStorage.getItem('d6cf_dm_mode') === 'stage' ? 'stage' : 'bg'; } catch (e) { return 'bg'; }
  })();
  var dmListCache = []; // 最近一次拿到的弹幕列表，切模式时直接用它重绘
  /* 当前模式下弹幕应渲染进的容器 */
  function dmTarget() {
    if (dmMode === 'bg') {
      var bg = document.getElementById('dm-bg');
      if (bg) { bg.classList.add('on'); return bg; }
    }
    var st = document.getElementById('dm-stage');
    if (st) st.style.display = '';
    return st;
  }
  /* 按当前模式初始化两个容器的可见性 + 渲染切换按钮（首页渲染后调用） */
  function dmInitMode() {
    var bg = document.getElementById('dm-bg'), stage = document.getElementById('dm-stage');
    if (bg) bg.classList.toggle('on', dmMode === 'bg');
    if (stage) stage.style.display = dmMode === 'bg' ? 'none' : '';
    var b = document.getElementById('dm-mode-btn');
    if (b) {
      b.textContent = dmMode === 'bg' ? '🎬 显示到弹幕墙' : '🪟 飘到背景板';
      b.onclick = function () { dmSetMode(dmMode === 'bg' ? 'stage' : 'bg'); };
    }
  }
  function dmSetMode(m) {
    dmMode = (m === 'stage') ? 'stage' : 'bg';
    try { localStorage.setItem('d6cf_dm_mode', dmMode); } catch (e) {}
    var bg = document.getElementById('dm-bg');
    if (bg) bg.classList.toggle('on', dmMode === 'bg');
    dmInitMode();
    dmDraftRemove();
    paintDanmaku(dmListCache);
  }
  /* 离开首页时收掉背景板里的弹幕（弹幕只在首页加载） */
  function dmBgClear() {
    var bg = document.getElementById('dm-bg');
    if (!bg) return;
    bg.classList.remove('on');
    bg.querySelectorAll('.dm-item').forEach(function (el) { el.parentNode.removeChild(el); });
  }
  function loadDanmaku() {
    api('GET', '/api/danmaku').then(function (list) {
      dmListCache = list || [];
      paintDanmaku(dmListCache);
      paintDanmakuForm();
    }).catch(function () {});
  }
  /* 弹幕项 HTML：头像点 + 昵称 + 正文（昵称让每条弹幕都有自己的身份，不再是一片白字） */
  function dmItemInner(d) {
    var col = d.color || '#66ccff';
    return '<span class="dm-inner">' +
      '<span class="dm-av" style="background:' + esc(col) + '">' + avatarDotHtml(d, 'dm-av-img') + '</span>' +
      '<span class="dm-name"' + (d.isOwner ? ' style="color:' + esc(col) + '"' : '') + '>' + (d.isOwner ? '👑 ' : '') + esc(d.username || '访客') + '</span>' +
      '<span class="dm-txt">' + esc(d.content) + '</span>' +
    '</span>';
  }
  /* 弹幕在舞台上循环飘过：车道按「最久没占用」分配 + 随机时长/延迟错峰，避免整齐划一；
     部分弹幕带轻微上下浮动；悬停暂停方便看清与删除 */
  function paintDanmaku(list) {
    var stage = dmTarget();
    if (!stage) return;
    dmDraftRemove(); // 清场会连同草稿弹幕一起清掉，末尾再重建
    // 两个容器都清一遍，避免切模式后旧弹幕残留在另一个容器里
    ['dm-stage', 'dm-bg'].forEach(function (id) {
      var c = document.getElementById(id);
      if (c) c.querySelectorAll('.dm-item').forEach(function (el) { el.parentNode.removeChild(el); });
    });
    var empty = $('#dm-empty');
    if (empty) empty.style.display = (dmMode === 'stage' && !list.length) ? '' : 'none';
    if (!list.length) return;
    var canDelAll = state.me && state.me.isOwner;
    var mineId = state.me ? String(state.me.id) : '';
    var w = stage.clientWidth || window.innerWidth || 900;
    stage.style.setProperty('--dmw', w + 'px');
    // 车道高度随最大字号自适应：32px 特大弹幕（还带头像）不能挤进 40px 的车道，否则会叠行
    var maxFont = 18;
    list.forEach(function (d) {
      var f = DM_SIZES.indexOf(Number(d.fontSize)) !== -1 ? Number(d.fontSize) : 18;
      if (f > maxFont) maxFont = f;
    });
    // 车道高必须 ≥ 弹幕实际高度（约 1.75×字号），再留余量防相邻车道 1px 级重叠
    var laneH = Math.max(38, Math.min(80, Math.round(maxFont * 2)));
    var lanes = Math.max(2, Math.floor(stage.clientHeight / laneH));
    var itemH = Math.round(maxFont * 1.75);
    var jitterMax = Math.max(0, laneH - itemH);
    var laneFree = [], laneDur = []; // 每车道「下一条可入场时间」与该车道当前速度（同车道同速防追尾）
    for (var i = 0; i < lanes; i++) { laneFree.push(0); laneDur.push(0); }
    var t0 = Date.now();
    list.forEach(function (d, idx) {
      var el = document.createElement('span');
      var style = DM_STYLES.indexOf(d.style) !== -1 ? d.style : 'default';
      el.className = 'dm-item st-' + style;
      el.style.setProperty('--dmc', d.color || '#66ccff');
      var font = DM_SIZES.indexOf(Number(d.fontSize)) !== -1 ? Number(d.fontSize) : 18;
      el.style.fontSize = font + 'px';
      el.innerHTML = dmItemInner(d);
      el.title = (d.isOwner ? '👑 ' : '') + d.username + ' · ' + fmtTime(d.createdAt);
      el.setAttribute('data-id', d.id);
      var canDel = canDelAll || String(d.userId) === mineId;
      if (canDel) el.classList.add('mine');
      // 选车道：优先挑空闲的（乱序随机），都刚出过就挑最早空出来的那条
      var ready = [];
      laneFree.forEach(function (ft, li) { if (ft <= t0) ready.push(li); });
      var lane = ready.length ? ready[Math.floor(Math.random() * ready.length)]
        : laneFree.indexOf(Math.min.apply(null, laneFree));
      var immediate = laneFree[lane] <= t0;
      var dur, delay;
      if (immediate) {
        // 时长：内容越长走得越慢，再叠随机快慢，让弹幕不再齐步走
        dur = 12 + Math.random() * 7 + Math.min(8, d.content.length / 6);
        // 首轮入场：负延迟把画面铺开，一进来就不是「整队排在右边」
        delay = -Math.random() * 0.55 * dur;
      } else {
        // 同车道排队：沿用前一条的速度（同速保持间距，绝不追尾）
        dur = laneDur[lane] || 15;
        delay = (laneFree[lane] - t0) / 1000;
      }
      // 放行下一条的时机：本条要完全让出右边缘（飞过自身宽度占总航程的比例）才不算重叠，
      // 再加一点随机余量。宽弹幕按比例等更久，杜绝「半截还在屏上就被后条压上」
      var estW = Math.round(font * (d.content.length * 1.15 + 5) + 60); // 估宽：正文+头像+昵称（宁宽勿窄）
      laneFree[lane] = (immediate ? t0 : laneFree[lane]) + (estW / (w + estW)) * dur * 1000 + (immediate ? 0 : Math.random() * 1500);
      laneDur[lane] = dur;
      el.style.top = Math.round(lane * laneH + Math.random() * jitterMax) + 'px';
      el.style.animationDuration = dur.toFixed(1) + 's';
      el.style.animationDelay = delay.toFixed(1) + 's';
      if (style === 'glow' || style === 'neon' || style === 'rainbow' || idx % 3 === 0) el.classList.add('dm-float');
      if (canDel) {
        el.addEventListener('click', function () {
          if (!confirm('删除这条弹幕吗？')) return;
          api('DELETE', '/api/danmaku/' + d.id).then(function () { toast('弹幕已删除'); loadDanmaku(); })
            .catch(function (e) { toast(e.message); });
        });
      }
      stage.appendChild(el);
    });
    paintDmDraft(); // 重绘后把草稿预览弹幕放回舞台
  }
  /* 我的效果预览：两层 —— ① 表单下方静态预览条；② 草稿弹幕直接在舞台上按真实样式循环飘（带「预览」角标）。
     state.me 可能还没加载完（竞态），此时用占位身份渲染，绝不留空白预览 */
  var dmDraft = null, dmDraftKey = '';
  function dmDraftRemove() {
    if (dmDraft && dmDraft.parentNode) dmDraft.parentNode.removeChild(dmDraft);
    dmDraft = null; dmDraftKey = '';
  }
  function paintDmDraft() {
    var stage = dmTarget();
    if (!stage || !state.me) { dmDraftRemove(); return; }
    var sizeEl = $('#dm-size'), styleEl = $('#dm-style'), input = $('#dm-input');
    var size = sizeEl ? (Number(sizeEl.value) || 18) : 18;
    var style = styleEl ? styleEl.value : 'default';
    var txt = (input && input.value.trim()) || '弹幕效果预览';
    var key = style + '|' + size;
    if (!dmDraft || dmDraftKey !== key) {
      // 字号/样式变了才重建（重新起飞）；只改文字就原地换内容，不打断飞行
      dmDraftRemove();
      dmDraft = document.createElement('span');
      dmDraft.className = 'dm-item dm-draft st-' + (DM_STYLES.indexOf(style) !== -1 ? style : 'default');
      dmDraft.style.fontSize = size + 'px';
      var w = stage.clientWidth || window.innerWidth || 900;
      stage.style.setProperty('--dmw', w + 'px');
      dmDraft.style.top = Math.round(stage.clientHeight * 0.42) + 'px';
      dmDraft.style.animationDuration = '14s';
      dmDraft.style.animationDelay = '-2s';
      dmDraft.innerHTML = dmItemInner({ username: state.me.username, color: state.me.color, avatar: state.me.avatar, isOwner: state.me.isOwner, content: txt }) +
        '<span class="dm-tag">预览</span>';
      stage.appendChild(dmDraft);
      dmDraftKey = key;
    } else {
      var t = dmDraft.querySelector('.dm-txt');
      if (t) t.textContent = txt;
    }
  }
  function paintDmPreview() {
    var box = $('#dm-preview-txt');
    if (!box) { dmDraftRemove(); return; }
    var me = state.me || { username: '我', color: '#66ccff' };
    var style = ($('#dm-style') || {}).value || 'default';
    var size = Number(($('#dm-size') || {}).value) || 18;
    var txt = ($('#dm-input') && $('#dm-input').value.trim()) || '弹幕效果预览';
    box.className = 'dm-preview-item dm-item st-' + (DM_STYLES.indexOf(style) !== -1 ? style : 'default');
    box.style.setProperty('--dmc', me.color || '#66ccff');
    box.style.fontSize = size + 'px';
    box.innerHTML = '<span class="dm-inner">' +
      '<span class="dm-av" style="background:' + esc(me.color || '#66ccff') + '">' + avatarDotHtml(me, 'dm-av-img') + '</span>' +
      '<span class="dm-name">' + (me.isOwner ? '👑 ' : '') + esc(me.username) + '</span>' +
      '<span class="dm-txt">' + esc(txt) + '</span>' +
    '</span>';
    paintDmDraft();
  }
  function paintDanmakuForm() {
    var box = $('#dm-form-box');
    if (!box) return;
    if (!state.me) {
      box.innerHTML = '<p class="dm-login-tip">' + T_HTML('dm_guest_tip') + '</p>';
      return;
    }
    box.innerHTML =
      '<div class="dm-form">' +
        '<input id="dm-input" maxlength="70" placeholder="写一句想对天依说的话…（最多 70 字）">' +
        '<select id="dm-size" title="字号">' + DM_SIZES.map(function (s) { return '<option value="' + s + '"' + (s === 18 ? ' selected' : '') + '>' + DM_SIZE_NAMES[s] + '</option>'; }).join('') + '</select>' +
        '<select id="dm-style" title="样式">' + DM_STYLES.map(function (s) { return '<option value="' + s + '">' + DM_STYLE_NAMES[s] + '</option>'; }).join('') + '</select>' +
        '<button class="btn ghost small" id="dm-random" title="随机换一套字号和样式">🎲 随机</button>' +
        '<button class="btn primary" id="dm-send">发射</button>' +
      '</div>' +
      '<div class="dm-preview"><span class="dm-preview-label">效果预览</span><span id="dm-preview-txt"></span></div>' +
      '<p class="dm-mine-tip" id="dm-mine-tip"></p>';
    var input = $('#dm-input'), tip = $('#dm-mine-tip');
    input.addEventListener('input', paintDmPreview);
    $('#dm-size').addEventListener('change', paintDmPreview);
    $('#dm-style').addEventListener('change', paintDmPreview);
    $('#dm-random').addEventListener('click', function () {
      $('#dm-size').value = String(DM_SIZES[Math.floor(Math.random() * DM_SIZES.length)]);
      $('#dm-style').value = DM_STYLES[Math.floor(Math.random() * DM_STYLES.length)];
      paintDmPreview();
    });
    paintDmPreview();
    // 回显自己已有的弹幕：可删除，重发会替换
    api('GET', '/api/danmaku/mine').then(function (r) {
      if (!r || !r.danmaku) return;
      if (!$('#dm-input')) return;
      input.value = r.danmaku.content;
      $('#dm-size').value = String(r.danmaku.fontSize);
      $('#dm-style').value = r.danmaku.style;
      paintDmPreview();
      tip.innerHTML = '你已有一条弹幕，再次「发射」会替换它 · <span class="dm-clear" id="dm-del">删除我的弹幕</span>';
      var del = $('#dm-del');
      if (del) del.addEventListener('click', function () {
        api('DELETE', '/api/danmaku/' + r.danmaku.id).then(function () { toast('弹幕已删除'); loadDanmaku(); })
          .catch(function (e) { toast(e.message); });
      });
    }).catch(function () {});
    $('#dm-send').addEventListener('click', function () {
      var v = input.value.trim();
      if (!v) { toast('先写点什么再发吧～'); return; }
      if (v.length > 70) { toast('弹幕最多 70 字'); return; }
      api('POST', '/api/danmaku', { content: v, fontSize: Number($('#dm-size').value), style: $('#dm-style').value })
        .then(function () { toast('弹幕已发射 🎐'); loadDanmaku(); })
        .catch(function (e) { toast(e.message); });
    });
    input.addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#dm-send').click(); });
  }

  /* 未读文章记忆：按浏览器 localStorage 记「点开过哪些文章」，最多留 500 条防止无限膨胀 */
  function readPostIds() {
    try { var a = JSON.parse(localStorage.getItem('d6cf_read_posts') || '[]'); return Array.isArray(a) ? a : []; }
    catch (e) { return []; }
  }
  function isPostRead(id) {
    return readPostIds().indexOf(String(id)) !== -1;
  }
  function markPostRead(id) {
    try {
      var arr = readPostIds().filter(function (x) { return x !== String(id); });
      arr.push(String(id));
      if (arr.length > 500) arr = arr.slice(arr.length - 500);
      localStorage.setItem('d6cf_read_posts', JSON.stringify(arr));
    } catch (e) {}
  }

  function postCardHtml(p) {
    var plain = String(p.content || '').replace(/[#>*`\-\[\]!()]/g, '').replace(/\s+/g, ' ').trim().slice(0, 120);
    var live = isPostLive(p);
    // 未读呼吸提醒：站长可开关；站长自己看不到（自己的文章不存在引导点击的必要）
    var unread = live && state.settings && state.settings.unreadGlow !== false &&
      !(state.me && state.me.isOwner) && !isPostRead(p.id);
    return '<div class="post-card glass' + (live ? '' : ' is-sched') + (unread ? ' unread' : '') + '" onclick="location.hash=\'#/post/' + p.id + '\'">' +
      (live ? '' : '<div class="sched-flag">⏰ 定时发布 · ' + fmtFullTime(p.publishAt) + ' 之前只有你能看到</div>') +
      '<h3>' + (p.pinned ? '<span class="pin">📌</span>' : '') + esc(p.title) + '</h3>' +
      '<div class="meta">🕒 ' + fmtTime(p.updatedAt) + (p.commentCount ? ' · 💬 ' + p.commentCount + ' 条评论' : '') + '</div>' +
      '<div class="excerpt">' + esc(plain) + (plain.length >= 120 ? '…' : '') + '</div>' +
    '</div>';
  }

  function renderPosts() {
    viewEl.innerHTML = '<div class="page-head glass"><h2>' + esc(T('page_posts_title')) + '</h2><p>' + esc(T('page_posts_sub', { n: state.posts.length })) + '</p></div>' +
      (state.posts.length ? state.posts.map(postCardHtml).join('') : '<div class="empty-tip glass">空空如也～</div>');
  }

  function renderPost(id) {
    api('GET', '/api/posts/' + id).then(function (p) {
      markPostRead(id); // 点开过就记住，回列表页后这张卡不再呼吸
      viewEl.innerHTML =
        '<a class="back-link" href="#/posts">← 返回文章列表</a>' +
        '<div class="article glass">' +
          '<h1>' + (p.pinned ? '📌 ' : '') + esc(p.title) + '</h1>' +
          '<div class="meta">🕒 发布于 ' + fmtTime(p.createdAt) + ' · 更新于 ' + fmtTime(p.updatedAt) + '</div>' +
          (isPostLive(p) ? '' : '<div class="sched-flag">⏰ 定时发布：' + fmtFullTime(p.publishAt) + ' 之后才对外可见（现在只有你能看到）</div>') +
          '<div class="content">' + md(p.content) + '</div>' +
        '</div>' +
        '<div class="comments glass" id="comments-box">' +
          '<h3>💬 评论</h3>' +
          '<div id="comment-list"><p class="c-empty">加载中…</p></div>' +
          '<div id="comment-form-box"></div>' +
        '</div>';
      loadComments(p.id);
    }).catch(function (e) {
      viewEl.innerHTML = '<div class="empty-tip glass">' + esc(e.message) + '</div>';
    });
  }
  /* ---------------- 文章评论 ---------------- */
  function loadComments(postId) {
    api('GET', '/api/posts/' + postId + '/comments').then(function (list) {
      var box = $('#comment-list');
      if (!box) return;
      box.innerHTML = list.length ? list.map(function (c) {
        var canDel = state.me && (state.me.isOwner || String(c.userId) === String(state.me.id));
        var initial = (c.username || '?').charAt(0).toUpperCase();
        return '<div class="comment-item">' +
          '<div class="c-dot" style="background:' + esc(c.color || '#66ccff') + '">' +
            avatarDotHtml(c, 'dot-img') + '</div>' +
          '<div class="c-body">' +
            '<div class="c-head">' +
              '<span class="c-name">' + (c.isOwner ? '👑 ' : '') + esc(c.username) + '</span>' +
              '<span class="c-time">' + fmtTime(c.createdAt) + '</span>' +
              (canDel ? '<span class="c-del" data-del="' + c.id + '">删除</span>' : '') +
            '</div>' +
            '<div class="c-text">' + esc(c.content) + '</div>' +
          '</div>' +
        '</div>';
      }).join('') : '<p class="c-empty">还没有评论，来说点什么吧～</p>';
      box.querySelectorAll('[data-del]').forEach(function (el) {
        el.addEventListener('click', function () {
          if (!confirm('确定删除这条评论吗？')) return;
          api('DELETE', '/api/comments/' + el.getAttribute('data-del')).then(function () {
            toast('评论已删除');
            loadComments(postId);
          }).catch(function (e) { toast(e.message); });
        });
      });
      var cnt = '💬 评论（' + list.length + '）';
      var h = $('#comments-box h3');
      if (h) h.textContent = cnt;
    }).catch(function () {});

    var fbox = $('#comment-form-box');
    if (!fbox) return;
    if (state.me) {
      fbox.innerHTML =
        '<div class="c-form">' +
          '<textarea id="c-input" maxlength="500" placeholder="以 ' + esc(state.me.username) + ' 的身份说点什么…（最多 500 字）"></textarea>' +
          '<button class="btn primary" id="c-send">发表评论</button>' +
        '</div>';
      $('#c-send').addEventListener('click', function () {
        var v = $('#c-input').value.trim();
        if (!v) { toast('先写点什么再发吧～'); return; }
        api('POST', '/api/posts/' + postId + '/comments', { content: v }).then(function () {
          $('#c-input').value = '';
          toast('评论已发布 ✨');
          loadComments(postId);
          refreshPosts();
        }).catch(function (e) { toast(e.message); });
      });
    } else {
      fbox.innerHTML = '<p class="c-login-tip">' + T_HTML('comment_guest_tip') + '</p>';
    }
  }

  function loadMedia() {
    return api('GET', '/api/media').then(function (m) { state.media = m; return m; }).catch(function () { return []; });
  }
  function loadFolders() {
    return api('GET', '/api/folders').then(function (f) { state.folders = f || []; return state.folders; }).catch(function () { return []; });
  }

  /* ---------------- 媒体文件夹工具 ---------------- */
  function foldersOf(type) { return state.folders.filter(function (f) { return f.type === type; }); }
  function folderName(id) {
    var f = state.folders.filter(function (x) { return String(x.id) === String(id); })[0];
    return f ? f.name : '';
  }
  /* 把文件按文件夹分组（只有有内容的分组才返回，未分类排最后） */
  function groupByFolder(items, type) {
    var groups = [];
    foldersOf(type).forEach(function (f) {
      var list = items.filter(function (m) { return String(m.folderId) === String(f.id); });
      if (list.length) groups.push({ id: String(f.id), name: f.name, items: list });
    });
    var none = items.filter(function (m) { return !m.folderId; });
    if (none.length) groups.push({ id: 'none', name: '未分类', items: none });
    return groups;
  }
  /* 文件夹标签栏（公开页：音乐 / 图库） */
  function folderTabsHtml(items, type, cur) {
    var groups = groupByFolder(items, type);
    if (!groups.length) return '';
    return '<div class="f-tabs">' +
      '<span class="f-tab' + (cur === 'all' ? ' active' : '') + '" data-f="all">全部 <b>' + items.length + '</b></span>' +
      groups.map(function (g) {
        return '<span class="f-tab' + (cur === g.id ? ' active' : '') + '" data-f="' + g.id + '">' +
          (g.id === 'none' ? '📄 ' : '📁 ') + esc(g.name) + ' <b>' + g.items.length + '</b></span>';
      }).join('') + '</div>';
  }
  function bindFolderTabs(which) {
    Array.prototype.forEach.call(document.querySelectorAll('.f-tabs .f-tab'), function (el) {
      el.addEventListener('click', function () {
        var v = el.getAttribute('data-f');
        if (which === 'music') { state.musicFolder = v; renderMusic(); }
        else { state.galleryFolder = v; renderGallery(); }
        window.scrollTo(0, 0);
      });
    });
  }
  /* 按当前选中的文件夹整理出「显示列表」和「分组结构」；cur 失效时回落到全部 */
  function pickFolderItems(items, type, cur) {
    var groups = groupByFolder(items, type);
    if (cur !== 'all' && !groups.some(function (g) { return g.id === cur; })) cur = 'all';
    if (cur === 'all') {
      var shown = [];
      groups.forEach(function (g) { g.items.forEach(function (m) { shown.push(m); }); });
      return { cur: 'all', shown: shown, groups: groups, flat: groups.length <= 1 };
    }
    var g = groups.filter(function (x) { return x.id === cur; })[0];
    var list = g ? g.items.slice() : [];
    return { cur: cur, shown: list, groups: list.length ? [{ id: cur, name: g.name, items: list }] : [], flat: true };
  }

  function renderMusic() {
    // 隐藏素材不进公开歌单（站长在媒体库里仍能看到）
    var audios = state.media.filter(function (m) { return m.type === 'audio' && !m.hidden; });
    var picked = pickFolderItems(audios, 'audio', state.musicFolder);
    state.musicFolder = picked.cur;
    state.playlist = picked.shown; // 播放索引必须与页面上显示的顺序一致
    var k = 0;
    var body = picked.groups.map(function (g) {
      var head = picked.flat ? '' : '<div class="f-group-head">' + (g.id === 'none' ? '📄 ' : '📁 ') + esc(g.name) + ' <span>' + g.items.length + ' 首</span></div>';
      return head + g.items.map(function (m) {
        var i = k++;
        return '<div class="audio-item glass" data-idx="' + i + '" onclick="window._playByIndex(' + i + ')">' +
          '<div class="a-icon">🎵</div>' +
          '<div class="a-name">' + esc(m.originalName) + '</div>' +
          '<div class="a-size">' + fmtSize(m.size) + '</div>' +
        '</div>';
      }).join('');
    }).join('');
    viewEl.innerHTML = '<div class="page-head glass"><h2>' + esc(T('page_music_title')) + '</h2><p>' + esc(T('page_music_sub', { n: audios.length })) + '</p>' +
      folderTabsHtml(audios, 'audio', picked.cur) + '</div>' +
      (picked.shown.length ? body : '<div class="empty-tip glass">' +
        (audios.length ? '这个文件夹里还没有音乐～' : '还没有上传音乐，去「小站管理 → 媒体库」上传吧～') + '</div>');
    bindFolderTabs('music');
  }

  function renderGallery() {
    // 隐藏素材不出现在图库（可用于文章配图，但不对外展示）
    var images = state.media.filter(function (m) { return m.type === 'image' && !m.hidden; });
    var picked = pickFolderItems(images, 'image', state.galleryFolder);
    state.galleryFolder = picked.cur;
    var body = picked.groups.map(function (g) {
      var head = picked.flat ? '' : '<div class="f-group-head">' + (g.id === 'none' ? '📄 ' : '📁 ') + esc(g.name) + ' <span>' + g.items.length + ' 张</span></div>';
      return head + '<div class="gallery-grid">' + g.items.map(function (m) {
        return '<div class="gallery-item glass" onclick="window._lightbox(\'' + m.url + '\')"><img src="' + m.url + '" loading="lazy" alt=""></div>';
      }).join('') + '</div>';
    }).join('');
    viewEl.innerHTML = '<div class="page-head glass"><h2>' + esc(T('page_gallery_title')) + '</h2><p>' + esc(T('page_gallery_sub', { n: images.length })) + '</p>' +
      folderTabsHtml(images, 'image', picked.cur) + '</div>' +
      (picked.shown.length ? body : '<div class="empty-tip glass">' +
        (images.length ? '这个文件夹里还没有图片～' : '图库还是空的～') + '</div>');
    bindFolderTabs('gallery');
  }

  /* 本地时间 → datetime-local 输入框的值 */
  function toLocalInput(ts) {
    var d = new Date(ts);
    var p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  /* 文章是否已过发布时间 */
  function isPostLive(p) { return !p.publishAt || Number(p.publishAt) <= Date.now(); }
  function fmtFullTime(ts) {
    var d = new Date(ts);
    var p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function renderAbout() {
    var s = state.settings;
    viewEl.innerHTML = '<div class="page-head glass"><h2>' + esc(T('page_about_title')) + '</h2></div>' +
      '<div class="about-card glass">' + esc(s.about || '') +
      '<div class="about-links">' +
        (s.bilibiliUrl ? '<a href="' + esc(s.bilibiliUrl) + '" target="_blank">' + iconTag('bilibili', '📺') + ' B站主页</a>' : '') +
        (s.douyinUrl ? '<a href="' + esc(s.douyinUrl) + '" target="_blank">' + iconTag('douyin', '🎶') + ' 抖音主页</a>' : '') +
      '</div></div>' +
      thanksEntryHtml(s) +
      (s.privacyEnabled === false ? '' : privacyEntryHtml(s));
  }

  /* 「关于」页的特别感谢名单入口卡片 */
  function thanksEntryHtml(s) {
    return '<a class="policy-entry glass" href="#/thanks">' +
      '<span class="pe-ico">🌟</span>' +
      '<span class="pe-body">' +
        '<span class="pe-title">特别感谢名单</span>' +
        '<span class="pe-desc">感谢每一位帮助过这个小站的人——提建议、报 bug、陪伴签到的你们都在这里</span>' +
      '</span>' +
      '<span class="pe-arrow">→</span>' +
    '</a>';
  }

  /* ---------------- 关于 & 隐私政策 ---------------- */
  // 「关于」页底部的隐私政策入口卡片
  function privacyEntryHtml(s) {
    return '<a class="policy-entry glass" href="#/privacy">' +
      '<span class="pe-ico">🔒</span>' +
      '<span class="pe-body">' +
        '<span class="pe-title">隐私政策</span>' +
        '<span class="pe-desc">了解本站会收集哪些信息、如何使用第三方服务，以及你拥有的权利' +
          (s.privacyUpdatedAt ? '（最后更新：' + esc(s.privacyUpdatedAt) + '）' : '') + '</span>' +
      '</span>' +
      '<span class="pe-arrow">→</span>' +
    '</a>';
  }
  /* 备案信息（工信部 ICP + 公安网安）：只出现在隐私政策页底部，不再全站页脚常驻 */
  function beianBlockHtml() {
    return '<div class="policy-beian">' +
      '<a class="beian-icp" href="https://beian.miit.gov.cn/" target="_blank" rel="noopener">' + esc(T('footer_beian')) + '</a>' +
      '<span class="beian-sep" aria-hidden="true">·</span>' +
      '<a class="beian-gongan" href="https://beian.mps.gov.cn/#/query/webSearch?code=43110202000225" target="_blank" rel="noreferrer">' +
        '<img src="/assets/logo01.png" alt="公安备案徽标" width="14" height="14">' +
        '<span class="beian-text">' + esc(T('footer_gongan')) + '</span>' +
      '</a>' +
    '</div>';
  }
  function renderPrivacy() {
    var s = state.settings;
    var body = String(s.privacy || '').trim();
    var email = String(s.privacyContactEmail || '').trim();
    viewEl.innerHTML =
      '<div class="page-head glass"><h2>' + esc(T('page_privacy_title')) + '</h2>' +
        '<p>最后更新：' + esc(s.privacyUpdatedAt || '-') + '</p>' +
      '</div>' +
      '<div class="article glass policy-card">' +
        '<div class="content policy-content">' +
          (body ? md(body) : '<p>站长还没有填写隐私政策内容～</p>') +
        '</div>' +
        '<div class="about-links policy-links">' +
          '<a href="#/about">💬 回到关于本站</a>' +
          (email ? '<a href="mailto:' + esc(email) + '">✉️ 举报 / 联系：' + esc(email) + '</a>' : '') +
        '</div>' +
        beianBlockHtml() +
      '</div>';
  }

  /* 特别感谢名单页（#/thanks，Markdown 内容由站长在【设置 → 站点设置】维护） */
  function renderThanks() {
    var s = state.settings;
    var body = String(s.thanks || '').trim();
    viewEl.innerHTML =
      '<div class="page-head glass"><h2>' + esc(T('page_thanks_title')) + '</h2></div>' +
      '<div class="article glass policy-card">' +
        '<div class="content policy-content">' +
          (body ? md(body) : '<p>名单整理中，敬请期待～</p>') +
        '</div>' +
        '<div class="about-links policy-links">' +
          '<a href="#/about">💬 回到关于本站</a>' +
        '</div>' +
      '</div>';
  }

  /* ---------------- 赛博签名板 ---------------- */
  function hexToRgba(hex, a) {
    var m = String(hex || '#66ccff').replace('#', '');
    var r = parseInt(m.substr(0, 2), 16), g = parseInt(m.substr(2, 2), 16), b = parseInt(m.substr(4, 2), 16);
    return 'rgba(' + r + ',' + g + ',' + b + ',' + a + ')';
  }
  function userLinkHtml(u) {
    var h = '';
    if (u.bilibiliUrl) h += '<a class="btn ghost small" href="' + esc(u.bilibiliUrl) + '" target="_blank">📺 B站</a>';
    if (u.douyinUrl) h += '<a class="btn ghost small" href="' + esc(u.douyinUrl) + '" target="_blank">🎶 抖音</a>';
    return h;
  }
  /* ---------------- 头像上传（带圆形裁剪） ---------------- */
  // 用户最终展示的头像：自己的优先，没有就用站长设置的默认头像
  function userAvatarUrl(u) {
    return (u && u.avatar) || (state.settings && state.settings.defaultAvatar) || '';
  }
  // 圆形容器里的头像/首字母
  function avatarDotHtml(u, cls) {
    var url = userAvatarUrl(u);
    if (url) return '<img class="' + cls + '" src="' + esc(url) + '" alt="">';
    return esc(((u && u.username) || '?').charAt(0).toUpperCase());
  }
  function uploadAvatarBlob(blob, userId, done, fail) {
    var fd = new FormData();
    fd.append('file', blob, 'avatar.png');
    if (userId) fd.append('userId', userId);
    var headers = {};
    if (state.userToken) headers['X-User-Token'] = 'Bearer ' + state.userToken;
    if (state.token) headers['Authorization'] = 'Bearer ' + state.token;
    fetch('/api/avatar', { method: 'POST', headers: headers, body: fd })
      .then(function (res) {
        return res.json().then(function (d) { return { ok: res.ok, status: res.status, data: d }; });
      })
      .then(function (r) {
        if (!r.ok) throw new Error(r.data.error || ('上传失败 ' + r.status));
        done(r.data);
      })
      .catch(function (e) { if (fail) fail(e); else toast(e.message); });
  }
  // 图片裁剪弹窗：拖动平移 + 滑杆缩放；opts.shape='circle'（头像，默认）或 'square'（图标）
  function openAvatarCropper(opts) {
    opts = opts || {};
    if (opts.file) { loadCropFile(opts.file, opts); return; }
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.style.display = 'none';
    input.addEventListener('change', function () {
      var f = input.files && input.files[0];
      if (f) loadCropFile(f, opts);
    });
    document.body.appendChild(input);
    input.click();
    setTimeout(function () { if (input.parentNode) input.parentNode.removeChild(input); }, 60000);
  }
  function loadCropFile(f, opts) {
    if (!f) return;
    if (f.size > 5 * 1024 * 1024) { toast('图片不能超过 5MB 哦'); if (opts.onReject) opts.onReject(); return; }
    var reader = new FileReader();
    reader.onload = function () {
      var img = new Image();
      img.onload = function () { showAvatarCropper(img, opts); };
      img.onerror = function () { toast('这张图片读取失败，换一张试试'); if (opts.onReject) opts.onReject(); };
      img.src = reader.result;
    };
    reader.readAsDataURL(f);
  }
  function showAvatarCropper(img, opts) {
    opts = opts || {};
    var square = opts.shape === 'square';   // 方形=图标/favicon，圆形=头像
    var okText = opts.okText || '确认上传';
    var old = document.getElementById('avatar-crop-modal');
    if (old) old.parentNode.removeChild(old);
    var wrap = document.createElement('div');
    wrap.id = 'avatar-crop-modal';
    wrap.className = 'modal';
    wrap.innerHTML =
      '<div class="modal-box avatar-crop-box' + (square ? ' square' : '') + '">' +
        '<h2>' + esc(opts.title || (square ? '✂️ 裁剪图标' : '✂️ 裁剪头像')) + '</h2>' +
        '<p class="modal-tip">' + esc(opts.tip || (square
          ? '拖动图片调整位置 · 滑杆缩放 · 取景框内就是最终效果'
          : '拖动图片调整位置 · 滑杆缩放 · 虚线圆内就是最终效果')) + '</p>' +
        '<div class="av-canvas-wrap"><canvas id="av-canvas" width="300" height="300"></canvas></div>' +
        '<input type="range" id="av-zoom" min="10" max="40" step="0.5" value="10" aria-label="缩放">' +
        '<div class="modal-btns">' +
          '<button class="btn ghost" id="av-cancel">取消</button>' +
          '<button class="btn primary" id="av-ok">' + esc(okText) + '</button>' +
        '</div>' +
        '<p class="err" id="av-err"></p>' +
      '</div>';
    document.body.appendChild(wrap);
    var canvas = wrap.querySelector('#av-canvas');
    var ctx = canvas.getContext('2d');
    var D = 300, CX = D / 2, CY = D / 2, R = D / 2;
    var base = Math.max(D / img.width, D / img.height); // 初始正好铺满
    var zoom = 10; // 滑杆值 ÷10 = 相对缩放
    var offX = 0, offY = 0;
    var scale = function () { return base * zoom / 10; };
    function draw() {
      ctx.clearRect(0, 0, D, D);
      ctx.save();
      if (!square) { ctx.beginPath(); ctx.arc(CX, CY, R, 0, Math.PI * 2); ctx.clip(); }
      var s = scale();
      var w = img.width * s, h = img.height * s;
      ctx.drawImage(img, CX + offX - w / 2, CY + offY - h / 2, w, h);
      ctx.restore();
    }
    // 平移边界：保证图片始终盖满圆形取景框，不出现空白
    function clampOffset() {
      var s = scale();
      var maxX = Math.max(0, img.width * s / 2 - CX);
      var maxY = Math.max(0, img.height * s / 2 - CY);
      offX = Math.min(maxX, Math.max(-maxX, offX));
      offY = Math.min(maxY, Math.max(-maxY, offY));
    }
    draw();
    wrap.querySelector('#av-zoom').addEventListener('input', function () {
      zoom = Number(this.value);
      clampOffset();
      draw();
    });
    var dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
    // 画布可能被 CSS 缩小（手机端），换算成画布内坐标，拖动手感才 1:1
    function canvasScale() {
      var rect = canvas.getBoundingClientRect();
      return rect.width ? D / rect.width : 1;
    }
    canvas.addEventListener('pointerdown', function (e) {
      dragging = true; sx = e.clientX; sy = e.clientY; ox = offX; oy = offY;
      canvas.style.cursor = 'grabbing';
      if (canvas.setPointerCapture) canvas.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    canvas.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      var k = canvasScale();
      offX = ox + (e.clientX - sx) * k;
      offY = oy + (e.clientY - sy) * k;
      clampOffset();
      draw();
      e.preventDefault();
    });
    function endDrag() { dragging = false; canvas.style.cursor = 'grab'; }
    canvas.addEventListener('pointerup', endDrag);
    canvas.addEventListener('pointercancel', endDrag);
    canvas.style.cursor = 'grab';
    wrap.querySelector('#av-cancel').addEventListener('click', function () {
      wrap.parentNode.removeChild(wrap);
    });
    wrap.addEventListener('click', function (e) {
      if (e.target === wrap) wrap.parentNode.removeChild(wrap);
    });
    var okBtn = wrap.querySelector('#av-ok');
    okBtn.addEventListener('click', function () {
      var OUT = opts.outSize || (square ? 192 : 256);
      var out = document.createElement('canvas');
      out.width = OUT; out.height = OUT;
      var octx = out.getContext('2d');
      if (!square) { octx.beginPath(); octx.arc(OUT / 2, OUT / 2, OUT / 2, 0, Math.PI * 2); octx.clip(); }
      var s = scale();
      var w = img.width * s, h = img.height * s;
      var left = CX + offX - w / 2, top = CY + offY - h / 2;
      // 画布上可见的方形区域 (0,0,D,D) 对应原图坐标
      var sx0 = (0 - left) / s, sy0 = (0 - top) / s, sw = D / s;
      octx.drawImage(img, sx0, sy0, sw, sw, 0, 0, OUT, OUT);
      okBtn.disabled = true;
      okBtn.textContent = '上传中…';
      out.toBlob(function (blob) {
        if (!blob) {
          okBtn.disabled = false; okBtn.textContent = okText;
          wrap.querySelector('#av-err').textContent = '图片生成失败，换一张试试';
          return;
        }
        opts.onDone(blob, function () { // 回调里负责关弹窗/提示；这里兜底恢复按钮
          okBtn.disabled = false; okBtn.textContent = okText;
        });
      }, 'image/png');
    });
  }

  function boardPopHtml(u, isOwner) {
    var initial = (u.username || '?').charAt(0).toUpperCase();
    return '<div class="bubble-pop glass">' +
      '<div class="bp-head">' +
        '<div class="bp-dot" style="background:' + esc(u.color || '#66ccff') + '">' +
          avatarDotHtml(u, 'dot-img') + '</div>' +
        '<div><div class="bp-name">' + (isOwner ? '👑 ' : '') + esc(u.username) + '</div>' +
        '<div class="bp-date">' + (isOwner ? '站长 · 建站于 ' + esc(state.settings.createdAt || '-') : '🕒 ' + fmtTime(u.createdAt) + ' 来到此站') + '</div></div>' +
      '</div>' +
      '<div class="bp-sign">' + esc(u.signature || 'TA还没有留下签名～') + '</div>' +
      '<div class="bp-links">' +
        (isOwner
          ? '<a class="btn ghost small" href="#/about">🏠 站长主页</a>' + userLinkHtml(state.settings)
          : '<a class="btn ghost small" href="#/user/' + u.id + '">🏠 TA的主页</a>' + userLinkHtml(u)) +
      '</div>' +
    '</div>';
  }
  /* 泡泡整体缩放系数（0.5 ~ 1.3），记忆在 localStorage */
  var BOARD_ZOOM_KEY = 'd6cf_board_zoom';
  function boardZoomGet() {
    try {
      var v = parseFloat(localStorage.getItem(BOARD_ZOOM_KEY));
      if (v >= 0.5 && v <= 1.3) return Math.round(v * 20) / 20;   // 对齐到 5%
    } catch (e) {}
    return 1;
  }
  function boardZoomSave(v) { try { localStorage.setItem(BOARD_ZOOM_KEY, (Math.round(v * 100) / 100).toFixed(2)); } catch (e) {} }

  function renderBoard() {
    Promise.all([api('GET', '/api/users'), loadSettings()]).then(function (results) {
      var users = results[0];
      var s = state.settings;
      // 排序：越早注册越靠中心
      var sorted = users.slice().sort(function (a, b) { return a.createdAt - b.createdAt; });
      var nodes = [{ username: s.ownerName || 'D-6CF-X', color: s.ownerColor || '#66ccff', signature: s.ownerSignature || '', avatar: s.ownerAvatar || '', isOwner: true, user: null }];
      sorted.forEach(function (u) { nodes.push({ username: u.username, color: u.color, signature: u.signature, avatar: u.avatar || '', isOwner: false, user: u }); });

      var GOLDEN = 2.399963;
      var FLOAT_CLS = ['fl-a', 'fl-b', 'fl-c', 'fl-d'];
      var scale = boardZoomGet();
      // 位置（百分比）：站长在 50%,50%；其余黄金角螺旋向外。
      // 半径封顶随泡泡缩小而放宽 —— 泡泡越小越能铺得开，一页容纳更多；
      // 封顶圈上按黄金角错开，只加密不重叠。
      var ptsOf = function (sc) {
        var rMax = Math.min(42.5, 38 / Math.max(0.55, sc));
        return nodes.map(function (n, i) {
          if (i === 0) return { x: 50, y: 50 };
          var angle = i * GOLDEN;
          var r = Math.min(13 + i * 3.4, rMax);
          return { x: 50 + r * Math.cos(angle), y: 50 + r * Math.sin(angle) };
        });
      };
      var pts = ptsOf(scale);

      // 连线层：按注册顺序把气泡串成一串
      var linesSvg = '<svg class="board-lines" viewBox="0 0 100 100" preserveAspectRatio="none">';
      for (var i = 1; i < pts.length; i++) {
        linesSvg += '<line x1="' + pts[i - 1].x + '" y1="' + pts[i - 1].y + '" x2="' + pts[i].x + '" y2="' + pts[i].y + '"></line>';
      }
      linesSvg += '</svg>';

      // 肥皂泡
      var bubblesHtml = nodes.map(function (n, i) {
        var p = pts[i];
        var c = n.color || '#66ccff';
        var av = userAvatarUrl(n); // 自己的头像优先，否则用全站默认头像
        var name = n.username.slice(0, 10);
        var fs = Math.max(8, Math.min(15, Math.round(60 / Math.max(1, name.length))));
        var sizePct = n.isOwner ? 15.5 : 12.5;
        var fl = FLOAT_CLS[i % 4];
        var dur = (6.5 + (i % 4) * 1.4).toFixed(1);
        var delay = (-(i * 0.9) % 9).toFixed(1);
        return '<div class="bub-pos" style="left:' + p.x + '%;top:' + p.y + '%;width:' + sizePct + '%;z-index:' + (n.isOwner ? 5 : 3) + '">' +
          '<div class="bubble-float ' + fl + '" style="animation-duration:' + dur + 's;animation-delay:' + delay + 's">' +
            '<div class="bub' + (n.isOwner ? ' owner' : '') + (av ? ' has-av' : '') + '" data-bi="' + i + '">' +
              '<div class="bub-face" style="' +
                'background:' +
                  'radial-gradient(circle at 30% 24%, rgba(255,255,255,0.92) 0%, rgba(255,255,255,0.34) 14%, rgba(255,255,255,0.05) 44%, transparent 62%),' +
                  'radial-gradient(circle at 72% 80%, rgba(255,255,255,0.4) 0%, transparent 42%),' +
                  'radial-gradient(circle at 50% 50%, ' + hexToRgba(c, 0.24) + ' 52%, ' + hexToRgba(c, 0.72) + ' 100%);' +
                'box-shadow:' +
                  'inset 0 0 0 1.5px rgba(255,255,255,0.65),' +
                  'inset -9px -12px 26px ' + hexToRgba(c, 0.3) + ',' +
                  'inset 8px 10px 24px rgba(255,255,255,0.35),' +
                  '0 12px 32px rgba(90,130,175,0.16),' +
                  '0 0 24px ' + hexToRgba(c, 0.28) + ';' +
              '"></div>' +
              (av ? '<img class="bub-avatar" src="' + esc(av) + '" alt="">' : '') +
              '<div class="bub-sheen"></div>' +
              '<div class="bub-hi"></div>' +
              '<div class="bub-dot"></div>' +
              '<span class="bub-name" style="font-size:' + fs + 'px">' + esc(name) + '</span>' +
            '</div>' +
          '</div>' +
        '</div>';
      }).join('');

      // 环境装饰气泡（缓缓上升）
      var deco = '';
      for (var d = 0; d < 7; d++) {
        var dsz = 10 + (d * 7) % 26;
        deco += '<span class="deco-bub" style="left:' + (6 + d * 13) + '%;width:' + dsz + 'px;height:' + dsz + 'px;animation-duration:' + (9 + d * 2.4) + 's;animation-delay:-' + (d * 2.2) + 's"></span>';
      }

      viewEl.innerHTML =
        '<div class="page-head glass"><h2>' + esc(T('page_board_title')) + '</h2><p>' + esc(T('page_board_sub')) + '</p></div>' +
        '<div class="board-zoom glass">' +
          '<span class="bz-label">🫧 ' + esc(T('board_zoom_label')) + '</span>' +
          '<button class="bz-btn" type="button" data-z="-" aria-label="缩小" title="缩小">−</button>' +
          '<input class="bz-range" id="bz-range" type="range" min="50" max="130" step="5" value="' + Math.round(scale * 100) + '" aria-label="泡泡大小">' +
          '<button class="bz-btn" type="button" data-z="+" aria-label="放大" title="放大">＋</button>' +
          '<span class="bz-val" id="bz-val">' + Math.round(scale * 100) + '%</span>' +
        '</div>' +
        '<div class="board-wrap glass" id="board-wrap">' + deco +
          '<div class="board-stage" id="board-stage">' + linesSvg + bubblesHtml + '</div>' +
        '</div>' +
        '<div class="board-tip">' + T_HTML(state.me ? 'board_tip_member' : 'board_tip_guest', state.me ? '我的主页' : '注册 / 登录', { n: nodes.length - 1 }) + '</div>' +
        '<div id="board-pop"></div>';

      viewEl.querySelectorAll('.bub').forEach(function (g) {
        g.addEventListener('click', function () {
          var n = nodes[Number(g.getAttribute('data-bi'))];
          var pop = $('#board-pop');
          pop.innerHTML = n.isOwner
            ? boardPopHtml({ username: n.username, color: n.color, signature: n.signature, avatar: n.avatar }, true)
            : boardPopHtml(n.user, false);
          pop.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
      });

      /* 泡泡大小调节：滑块 / −＋ 按钮，整体缩放并记忆 */
      var stage = $('#board-stage');
      stage.style.setProperty('--bs', scale.toFixed(3));
      var posEls = viewEl.querySelectorAll('.bub-pos');
      var lineEls = viewEl.querySelectorAll('.board-lines line');
      var rng = $('#bz-range'), valEl = $('#bz-val');
      function setZoom(pct, save) {
        pct = Math.max(50, Math.min(130, Math.round(pct)));
        scale = pct / 100;
        stage.style.setProperty('--bs', scale.toFixed(3));
        var p2 = ptsOf(scale);
        for (var i = 0; i < posEls.length; i++) {
          posEls[i].style.left = p2[i].x.toFixed(2) + '%';
          posEls[i].style.top = p2[i].y.toFixed(2) + '%';
        }
        for (var j = 0; j < lineEls.length; j++) {
          lineEls[j].setAttribute('x1', p2[j].x.toFixed(2));
          lineEls[j].setAttribute('y1', p2[j].y.toFixed(2));
          lineEls[j].setAttribute('x2', p2[j + 1].x.toFixed(2));
          lineEls[j].setAttribute('y2', p2[j + 1].y.toFixed(2));
        }
        rng.value = pct;
        valEl.textContent = pct + '%';
        if (save) boardZoomSave(scale);
      }
      rng.addEventListener('input', function () { setZoom(Number(rng.value), true); });
      viewEl.querySelectorAll('.bz-btn').forEach(function (b) {
        b.addEventListener('click', function () {
          setZoom(Number(rng.value) + (b.getAttribute('data-z') === '+' ? 10 : -10), true);
        });
      });
    }).catch(function (e) {
      viewEl.innerHTML = '<div class="empty-tip glass">' + esc(e.message) + '</div>';
    });
  }

  /* ---------------- 用户公开主页 ---------------- */
  function renderUserProfile(id) {
    api('GET', '/api/users/' + id).then(function (u) {
      var initial = (u.username || '?').charAt(0).toUpperCase();
      viewEl.innerHTML =
        '<a class="back-link" href="#/board">← 返回签名板</a>' +
        '<div class="profile-card glass">' +
          '<div class="profile-avatar" style="background:' + esc(u.color) + ';display:flex;align-items:center;justify-content:center;color:#fff;font-size:36px;font-weight:700">' +
            avatarDotHtml(u, 'dot-img') + '</div>' +
          '<div class="profile-name">' + (u.isOwner ? '👑 ' : '') + esc(u.username) + '</div>' +
          '<div class="profile-date">' + (u.isOwner ? '🏠 站长 · 建站于 ' + esc(state.settings.createdAt || '-') : '🕒 ' + fmtTime(u.createdAt) + ' 来到此站') + '</div>' +
          '<div class="profile-sign">' + esc(u.signature || 'TA还没有留下签名～') + '</div>' +
          '<div class="about-links" style="justify-content:center">' + userLinkHtml(u) + '</div>' +
        '</div>';
    }).catch(function (e) {
      viewEl.innerHTML = '<div class="empty-tip glass">' + esc(e.message) + '</div>';
    });
  }

  /* ---------------- 我的主页（注册/登录/编辑资料） ---------------- */
  var PALETTE = ['#66ccff', '#7fd8c4', '#ffb3c6', '#ffd88a', '#b39ddb', '#90caf9', '#a5d6a7', '#ffab91', '#80deea', '#e6ee9c', '#f48fb1', '#9fa8da'];
  function renderMe() {
    if (!state.me) return renderMeAuth();
    var u = state.me;
    var isOwner = !!u.isOwner;
    var swatches = PALETTE.map(function (c) {
      return '<div class="swatch' + (u.color === c ? ' active' : '') + '" data-c="' + c + '" style="background:' + c + '"></div>';
    }).join('') +
      '<input type="color" class="swatch-custom" id="me-color-custom" value="' + esc(u.color) + '" title="自定义颜色">';
    viewEl.innerHTML =
      '<div class="page-head glass"><h2>' + (isOwner ? '👑 站长主页' : esc(T('page_me_title'))) + '</h2><p>' +
        (isOwner
          ? '你已用站长身份登录，这里编辑的就是签名板正中心的气泡（与「站点设置」里的站长资料同步）'
          : '打扮你的气泡：改名字、写签名、选颜色、挂上你的社交账号') + '</p></div>' +
      '<div class="admin-sec glass">' +
        '<h3>✏️ 编辑资料</h3>' +
        '<div class="me-avatar-row">' +
          (userAvatarUrl(u)
            ? '<img class="me-avatar" src="' + esc(userAvatarUrl(u)) + '" alt="头像">'
            : '<div class="me-avatar" style="background:' + esc(u.color) + '">' + esc((u.username || '?').charAt(0).toUpperCase()) + '</div>') +
          '<div>' +
            '<button class="btn ghost" id="me-avatar-btn">📷 ' + (u.avatar ? '更换头像' : '上传头像') + '</button>' +
            '<p class="admin-tip" style="margin-top:8px">5MB 以内图片 · 可拖动缩放圆形裁剪 · 展示在签名板气泡、评论和主页' + (!u.avatar && userAvatarUrl(u) ? '（当前显示的是站长设置的默认头像，上传后即换成你自己的）' : '') + '</p>' +
          '</div>' +
        '</div>' +
        '<div class="form-row"><label>用户名（2~20 字符，可随时修改）</label><input type="text" id="me-username" value="' + esc(u.username) + '" maxlength="20"></div>' +
        '<div class="form-row"><label>我的签名（展示在签名板气泡里，不超过 100 字）</label>' +
          '<textarea id="me-sign" maxlength="120" placeholder="写点什么留给未来来看签名板的人吧...">' + esc(u.signature || '') + '</textarea>' +
          '<div class="char-count" id="me-sign-count">' + (u.signature || '').length + ' / 100</div>' +
        '</div>' +
        '<div class="form-row"><label>气泡颜色</label><div class="color-swatches" id="me-swatches">' + swatches + '</div></div>' +
        '<div class="form-row"><label>📺 B站主页链接</label><input type="url" id="me-bili" value="' + esc(u.bilibiliUrl || '') + '" placeholder="https://space.bilibili.com/xxxxx"></div>' +
        '<div class="form-row"><label>🎶 抖音主页链接</label><input type="url" id="me-douyin" value="' + esc(u.douyinUrl || '') + '" placeholder="https://www.douyin.com/user/xxxxx"></div>' +
        '<div style="display:flex;gap:12px;flex-wrap:wrap">' +
          '<button class="btn primary" id="me-save">保存资料</button>' +
          '<a class="btn ghost" href="#/user/' + u.id + '" style="text-decoration:none;display:inline-flex;align-items:center">🏠 查看我的公开主页</a>' +
          '<a class="btn ghost" href="#/board" style="text-decoration:none;display:inline-flex;align-items:center">🫧 去签名板看看</a>' +
          (isOwner
            ? '<a class="btn ghost" href="#/admin" style="text-decoration:none;display:inline-flex;align-items:center">🛠️ 前往小站管理</a>' +
              '<button class="btn danger" id="me-logout">退出登录</button>'
            : '<button class="btn danger" id="me-logout">退出登录</button>') +
        '</div>' +
        (isOwner ? '<p style="font-size:12.5px;color:var(--grey-mid);margin-top:14px">💡 站长身份跟随「小站管理」登录自动生效，无需单独注册；改密码请到 小站管理 → 站点设置。</p>' : '') +
      '</div>' +
      (isOwner ? '' :
      '<div class="admin-sec glass">' +
        '<h3>🔑 修改密码</h3>' +
        '<div class="form-row"><label>旧密码</label><input type="password" id="me-oldpw"></div>' +
        '<div class="form-row"><label>新密码（至少 6 位）</label><input type="password" id="me-newpw"></div>' +
        '<button class="btn primary" id="me-pw-save">修改密码</button>' +
      '</div>');

    var color = u.color;
    function markActive(c) {
      viewEl.querySelectorAll('.swatch').forEach(function (el) {
        el.classList.toggle('active', el.getAttribute('data-c') === c);
      });
    }
    viewEl.querySelectorAll('.swatch').forEach(function (el) {
      el.addEventListener('click', function () {
        color = el.getAttribute('data-c');
        markActive(color);
        $('#me-color-custom').value = color;
      });
    });
    $('#me-color-custom').addEventListener('input', function () {
      color = this.value;
      markActive('');
    });
    var signEl = $('#me-sign');
    signEl.addEventListener('input', function () {
      var n = signEl.value.length;
      var c = $('#me-sign-count');
      c.textContent = n + ' / 100' + (n > 100 ? '（超出部分会被裁掉哦）' : '');
      c.classList.toggle('over', n > 100);
    });
    $('#me-avatar-btn').addEventListener('click', function () {
      openAvatarCropper({ onDone: function (blob, restore) {
        uploadAvatarBlob(blob, null, function (r) {
          var m = document.getElementById('avatar-crop-modal');
          if (m) m.parentNode.removeChild(m);
          state.me = r.user;
          updateUserChip();
          toast('头像已更新，签名板气泡同步换上新头像 ✨');
          if (isOwner) loadSettings().then(function () {});
          renderMe();
        }, function (e) {
          if (restore) restore();
          toast(e.message);
        });
      }});
    });
    $('#me-save').addEventListener('click', function () {
      api('PUT', '/api/me', {
        username: $('#me-username').value,
        signature: signEl.value.slice(0, 100),
        color: color,
        bilibiliUrl: $('#me-bili').value.trim(),
        douyinUrl: $('#me-douyin').value.trim()
      }).then(function (r) {
        state.me = r.user;
        updateUserChip();
        if (isOwner) {
          loadSettings().then(function () { applySettings(); });
          toast('站长资料已保存，签名板中心气泡同步更新啦 ✨');
        } else {
          toast('资料已保存，签名板上的气泡更新啦 ✨');
        }
      }).catch(function (e) { toast(e.message); });
    });
    // 退出登录：成员清自己的会话，站长清管理会话
    $('#me-logout').addEventListener('click', function () {
      var done = function () {
        if (isOwner) { state.token = ''; localStorage.removeItem('d6cf_token'); }
        else { state.userToken = ''; localStorage.removeItem('d6cf_user_token'); }
        state.me = null;
        updateUserChip();
        toast('已退出登录');
        renderMe();
      };
      if (isOwner) api('POST', '/api/logout').catch(function () {}).then(done);
      else api('POST', '/api/user-logout').catch(function () {}).then(done);
    });
    if (!isOwner) {
      $('#me-pw-save').addEventListener('click', function () {
        api('PUT', '/api/me', { oldPassword: $('#me-oldpw').value, newPassword: $('#me-newpw').value }).then(function () {
          toast('密码已修改');
          $('#me-oldpw').value = ''; $('#me-newpw').value = '';
        }).catch(function (e) { toast(e.message); });
      });
    }
  }

  function renderMeAuth() {
    var mode = 'login';
    viewEl.innerHTML =
      '<div class="page-head glass"><h2>' + esc(T('page_me_title')) + '</h2><p>' + esc(T('page_me_sub')) + '</p></div>' +
      '<div class="admin-sec glass auth-card" id="auth-card" style="max-width:460px;margin:0 auto">' +
        '<div class="auth-tabs">' +
          '<div class="tab active" data-m="login">👋 登录</div>' +
          '<div class="tab" data-m="register">✨ 注册</div>' +
        '</div>' +
        '<p class="auth-hint" id="au-hint"></p>' +
        '<div class="form-row"><label>用户名</label><input type="text" id="au-name" maxlength="20" placeholder="2~20 个字符"></div>' +
        '<div class="form-row"><label>密码（至少 6 位）</label><input type="password" id="au-pw" autocomplete="new-password"></div>' +
        '<div class="form-row" id="au-pw2-row" style="display:none"><label>确认密码（再输一遍）</label><input type="password" id="au-pw2" autocomplete="new-password"></div>' +
        '<p class="err" id="au-err"></p>' +
        '<button class="btn primary" id="au-go" style="width:100%">登 录</button>' +
      '</div>';

    var HINTS = {
      login: '欢迎回来！老朋友输入用户名和密码就能进入小站啦～',
      register: '创建一个新账号：设好用户名和密码，密码需要输入两遍确认无误。'
    };
    function setMode(m) {
      mode = m;
      viewEl.querySelectorAll('.auth-tabs .tab').forEach(function (t) {
        t.classList.toggle('active', t.getAttribute('data-m') === m);
      });
      $('#auth-card').classList.toggle('auth-mode-register', m === 'register');
      $('#auth-card').classList.toggle('auth-mode-login', m === 'login');
      $('#au-hint').textContent = HINTS[m];
      $('#au-go').textContent = m === 'login' ? '登 录' : '注 册';
      $('#au-pw2-row').style.display = m === 'register' ? '' : 'none';
      $('#au-pw2').value = '';
      $('#au-pw2').classList.remove('mismatch');
      $('#au-err').textContent = '';
    }
    viewEl.querySelectorAll('.auth-tabs .tab').forEach(function (t) {
      t.addEventListener('click', function () { setMode(t.getAttribute('data-m')); });
    });
    function go() {
      var name = $('#au-name').value.trim();
      var pw = $('#au-pw').value;
      var err = $('#au-err');
      err.textContent = '';
      if (mode === 'register') {
        var pw2 = $('#au-pw2').value;
        var bad = $('#au-pw2');
        if (pw2 !== pw) {
          bad.classList.add('mismatch');
          err.textContent = '两次输入的密码不一致，请检查后重试';
          bad.focus();
          return;
        }
        bad.classList.remove('mismatch');
      }
      var url = mode === 'login' ? '/api/user-login' : '/api/register';
      api('POST', url, { username: name, password: pw }).then(function (r) {
        state.userToken = r.token;
        state.me = r.user;
        localStorage.setItem('d6cf_user_token', r.token);
        updateUserChip();
        toast(mode === 'login' ? '欢迎回来，' + r.user.username + '！' : '注册成功！你的气泡已经出现在签名板上 🫧');
        renderMe();
      }).catch(function (e) { err.textContent = e.message; });
    }
    $('#au-go').addEventListener('click', go);
    $('#au-pw').addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
    $('#au-pw2').addEventListener('input', function () { this.classList.remove('mismatch'); $('#au-err').textContent = ''; });
    $('#au-pw2').addEventListener('keydown', function (e) { if (e.key === 'Enter') go(); });
    setMode('login');
  }

  /* ---------------- 音乐播放器 ---------------- */
  var audio = $('#audio');
  window._playByIndex = function (i) {
    var item = state.playlist[i];
    if (!item) return;
    state.playIndex = i;
    // 启动屏期间已预缓冲过这首（src 相同）时不要重设 src，否则缓冲白下、要重新拉流
    if (audio.getAttribute('src') === item.url) { try { audio.currentTime = 0; } catch (e) {} }
    else audio.src = item.url;
    var p = audio.play();
    if (p && p.catch) p.catch(function () {
      // 浏览器拦截了自动播放：播放条进入「等待点击」呼吸态（启动屏结束后依然可见），
      // 访客点/按页面任意位置后自动开始（pointerdown + touchend + keydown 三路手势兜底 iOS）
      state.autoBlocked = true;
      var bar = $('#player-bar');
      bar.classList.add('wait-tap');
      toast('🎵 浏览器拦截了自动播放，点一下页面任意位置就会开始播放');
      var kick = function () {
        document.removeEventListener('pointerdown', kick);
        document.removeEventListener('touchend', kick);
        document.removeEventListener('keydown', kick);
        bar.classList.remove('wait-tap');
        if (state.autoBlocked && state.settings.autoPlay && state.playIndex >= 0) {
          state.autoBlocked = false;
          state._justKicked = Date.now();   // 防抖：点在播放条 ▶ 上时，pointerdown 已替它开播，click 别再当「暂停」
          var cur = state.playlist[state.playIndex];
          if (cur) {
            // 同上：src 还是这首就保留已缓冲的数据，直接继续播
            if (audio.getAttribute('src') !== cur.url) audio.src = cur.url;
            audio.play().catch(function () {});
            $('#player-bar').style.display = 'flex';
            $('#p-name').textContent = cur.originalName;
          }
        }
      };
      document.addEventListener('pointerdown', kick);
      document.addEventListener('touchend', kick);
      document.addEventListener('keydown', kick);
    });
    $('#player-bar').style.display = 'flex';
    $('#p-name').textContent = item.originalName;
    renderMusicPlayingState();
  };
  function renderMusicPlayingState() {
    document.querySelectorAll('.audio-item').forEach(function (el) {
      el.classList.toggle('playing', Number(el.getAttribute('data-idx')) === state.playIndex);
    });
  }
  $('#p-play').addEventListener('click', function () {
    if (Date.now() - (state._justKicked || 0) < 800) return;   // 手势兜底刚替它播过，这次 click 忽略
    if (state.playIndex < 0) { if (state.playlist.length) window._playByIndex(0); return; }
    if (audio.paused) { audio.play(); this.textContent = '⏸'; } else { audio.pause(); this.textContent = '▶'; }
  });
  $('#p-prev').addEventListener('click', function () {
    if (state.playlist.length) window._playByIndex((state.playIndex - 1 + state.playlist.length) % state.playlist.length);
  });
  $('#p-next').addEventListener('click', function () {
    if (state.playlist.length) window._playByIndex((state.playIndex + 1) % state.playlist.length);
  });
  $('#p-close').addEventListener('click', function () {
    audio.pause(); $('#player-bar').style.display = 'none'; $('#player-bar').classList.remove('wait-tap'); state.playIndex = -1; state.autoBlocked = false; renderMusicPlayingState();
    $('#player-bar').style.setProperty('--pp', 0);
  });
  audio.addEventListener('timeupdate', function () {
    $('#p-time').textContent = fmtSec(audio.currentTime) + ' / ' + fmtSec(audio.duration);
    var pct = audio.duration ? (audio.currentTime / audio.duration * 100) : 0;
    $('#p-progress-fill').style.width = pct + '%';
    // 播放进度驱动渐变：进度条色相滑动 + 播放器整体渐晕随百分比点亮
    $('#player-bar').style.setProperty('--pp', pct.toFixed(2));
  });
  audio.addEventListener('play', function () { $('#p-play').textContent = '⏸'; });
  audio.addEventListener('pause', function () { $('#p-play').textContent = '▶'; });
  audio.addEventListener('ended', function () {
    if (state.playlist.length > 1) window._playByIndex((state.playIndex + 1) % state.playlist.length);
  });
  $('#p-progress').addEventListener('click', function (e) {
    if (!audio.duration) return;
    var rect = this.getBoundingClientRect();
    audio.currentTime = (e.clientX - rect.left) / rect.width * audio.duration;
  });

  /* ---------------- 灯箱 ---------------- */
  window._lightbox = function (url) {
    var lb = document.createElement('div');
    lb.id = 'lightbox';
    lb.innerHTML = '<img src="' + url + '" alt="">';
    lb.addEventListener('click', function () { document.body.removeChild(lb); });
    document.body.appendChild(lb);
  };

  /* ---------------- 登录 ---------------- */
  function openLogin() {
    $('#login-modal').style.display = 'flex';
    $('#login-err').textContent = '';
    $('#login-pw').value = '';
    setTimeout(function () { $('#login-pw').focus(); }, 50);
  }
  function closeLogin() { $('#login-modal').style.display = 'none'; }
  $('#admin-entry').addEventListener('click', function () {
    if (state.token) { location.hash = '#/admin'; } else { openLogin(); }
  });
  /* 站长隐藏入口：侧栏底部域名连点 5 次唤出登录框（入口按钮仅站长登录后可见，退出后由此进入） */
  (function () {
    var taps = 0, timer = null;
    $('#side-domain').addEventListener('click', function () {
      if (state.me && state.me.isOwner) { location.hash = '#/admin'; return; }
      taps++;
      if (timer) clearTimeout(timer);
      timer = setTimeout(function () { taps = 0; }, 1500);
      if (taps >= 5) {
        taps = 0;
        openLogin();
      }
    });
  })();
  $('#login-cancel').addEventListener('click', closeLogin);
  $('#login-ok').addEventListener('click', doLogin);
  $('#login-pw').addEventListener('keydown', function (e) { if (e.key === 'Enter') doLogin(); });
  function doLogin() {
    var pw = $('#login-pw').value;
    api('POST', '/api/login', { password: pw }).then(function (r) {
      state.token = r.token;
      localStorage.setItem('d6cf_token', r.token);
      closeLogin();
      toast('登录成功，欢迎回来，站长！');
      return loadMe();
    }).then(function () {
      location.hash = '#/admin';
    }).catch(function (e) {
      $('#login-err').textContent = e.message;
    });
  }

  /* ---------------- 管理后台 ---------------- */
  function renderAdmin() {
    // 只有站长（管理员 token 对应的身份）能进后台；普通用户/访客直接输网址会被拦下
    if (!state.token || !state.me || !state.me.isOwner) {
      if (state.token) { state.token = ''; localStorage.removeItem('d6cf_token'); }
      toast('只有站长登录后才能进入管理后台');
      openLogin();
      location.hash = '#/home';
      return;
    }
    loadMedia().then(renderAdminPanel);
  }
  function renderAdminPanel() {
    var tabs = [
      ['editor', '📝 写文章'],
      ['media', '🗂️ 媒体库'],
      ['icons', '🎨 图标'],
      ['users', '👥 用户'],
      ['texts', '✍️ 全站文案'],
      ['settings', '⚙️ 站点设置']
    ];
    viewEl.innerHTML =
      '<div class="page-head glass"><h2>' + esc(T('page_admin_title')) + '</h2><p>' + esc(T('page_admin_sub')) + '</p></div>' +
      '<div class="admin-tabs">' + tabs.map(function (t) {
        return '<div class="tab' + (state.adminTab === t[0] ? ' active' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</div>';
      }).join('') + '</div>' +
      '<div id="admin-body"></div>';
    document.querySelectorAll('.admin-tabs .tab').forEach(function (el) {
      el.addEventListener('click', function () {
        state.adminTab = el.getAttribute('data-tab');
        renderAdmin();
      });
    });
    var body = $('#admin-body');
    if (state.adminTab === 'editor') renderAdminEditor(body);
    if (state.adminTab === 'media') renderAdminMedia(body);
    if (state.adminTab === 'icons') renderAdminIcons(body);
    if (state.adminTab === 'users') renderAdminUsers(body);
    if (state.adminTab === 'texts') renderAdminTexts(body);
    if (state.adminTab === 'settings') renderAdminSettings(body);
  }

  /* --- 全站文案：按分组罗列所有可改文案，留空即用默认（占位符显示的就是默认值） --- */
  function renderAdminTexts(container) {
    var texts = state.settings.texts || {};
    var groups = [];
    SITE_TEXTS.forEach(function (t) {
      var g = groups.filter(function (x) { return x.name === t.g; })[0];
      if (!g) { g = { name: t.g, items: [] }; groups.push(g); }
      g.items.push(t);
    });
    function rowHtml(t) {
      var val = (typeof texts[t.k] === 'string') ? texts[t.k] : '';
      return '<div class="form-row tx-row">' +
        '<label>' + esc(t.label) + '</label>' +
        '<div class="tx-line">' +
          '<input type="text" class="tx-input" data-k="' + t.k + '" maxlength="200" value="' + esc(val) + '" placeholder="' + esc(t.def) + '">' +
          '<button type="button" class="btn ghost small tx-reset" data-k="' + t.k + '" title="恢复默认文案">恢复默认</button>' +
        '</div>' +
      '</div>';
    }
    container.innerHTML =
      '<div class="admin-sec glass">' +
        '<h3>✍️ 全站文案</h3>' +
        '<p class="admin-tip" style="margin:-6px 0 18px">这里能改小站各处显示的文字（导航菜单、首页弹幕网、各页标题、互动提示、页脚备案号…）。<b>输入框留空 = 用默认文案</b>，灰色的占位文字就是默认值；想改哪条就填哪条，改完点下方「保存文案」。</p>' +
        groups.map(function (g) {
          return '<div class="tx-group">' +
            '<h4 class="tx-group-title">' + esc(g.name) + '</h4>' +
            g.items.map(rowHtml).join('') +
          '</div>';
        }).join('') +
        '<div class="tx-actions">' +
          '<button class="btn primary" id="tx-save">保存文案</button>' +
          '<button class="btn ghost" id="tx-clear-all">全部恢复默认</button>' +
        '</div>' +
        '<p class="admin-tip" style="margin-top:12px">站点标题、副标题、公告、关于页正文、隐私政策这些有专门设置项的，请到「⚙️ 站点设置」里改。</p>' +
      '</div>';

    container.querySelectorAll('.tx-reset').forEach(function (b) {
      b.addEventListener('click', function () {
        var inp = container.querySelector('.tx-input[data-k="' + b.getAttribute('data-k') + '"]');
        if (inp) inp.value = '';
      });
    });
    function payload() {
      var out = {};
      container.querySelectorAll('.tx-input').forEach(function (inp) {
        var v = inp.value.trim();
        if (v && v !== TEXT_DEF[inp.getAttribute('data-k')]) out[inp.getAttribute('data-k')] = v;
      });
      return out;
    }
    $('#tx-clear-all').addEventListener('click', function () {
      if (!confirm('确定把所有文案都恢复成默认吗？（自定义的文字会全部清空）')) return;
      api('PUT', '/api/settings', { texts: {} }).then(function (r) {
        state.settings = r.settings;
        applySettings();
        toast('已全部恢复默认文案');
        renderAdminTexts(document.getElementById('admin-body'));
      }).catch(function (e) { toast(e.message); });
    });
    $('#tx-save').addEventListener('click', function () {
      api('PUT', '/api/settings', { texts: payload() }).then(function (r) {
        state.settings = r.settings;
        applySettings();
        toast('文案已保存 ✨');
        renderAdminTexts(document.getElementById('admin-body'));
      }).catch(function (e) { toast(e.message); });
    });
  }

  /* --- 图标管理 --- */
  var ICON_SLOTS = [
    ['avatar', '侧栏头像', '🎤'],
    ['favicon', '浏览器标签图标', '🎤'],
    ['home', '菜单 · 首页', '🏠'],
    ['posts', '菜单 · 文章', '📝'],
    ['music', '菜单 · 音乐', '🎵'],
    ['gallery', '菜单 · 图库', '🖼️'],
    ['about', '菜单 · 关于', '💬'],
    ['bilibili', 'B站图标（关于页 / 快捷入口）', '📺'],
    ['douyin', '抖音图标（关于页 / 快捷入口）', '🎶'],
    ['admin', '小站管理入口', '⚙️']
  ];
  function renderAdminIcons(container) {
    var icons = state.settings.icons || {};
    container.innerHTML =
      '<div class="admin-sec glass">' +
        '<h3>🎨 图标自定义</h3>' +
        '<p style="font-size:13px;color:var(--grey-mid);margin-bottom:14px">点「上传」选好图片后会先弹出裁剪框：拖动调整位置、滑杆缩放，取景框里就是最终效果（建议整体 64×64 以上，支持透明背景）。替换后立即生效，「恢复默认」可随时换回 emoji。</p>' +
        '<div class="icon-grid">' +
        ICON_SLOTS.map(function (slot) {
          var url = icons[slot[0]];
          var preview = url ? '<img src="' + esc(url) + '" alt="">' : slot[2];
          return '<div class="icon-slot glass">' +
            '<div class="i-preview">' + preview + '</div>' +
            '<div class="i-label">' + slot[1] + '</div>' +
            '<div class="i-acts">' +
              '<label class="btn ghost small" style="margin:0;cursor:pointer">上传<input type="file" accept="image/*" data-icon-upload="' + slot[0] + '" hidden></label>' +
              (url ? '<button class="btn danger small" data-icon-reset="' + slot[0] + '">恢复默认</button>' : '') +
            '</div>' +
          '</div>';
        }).join('') +
        '</div>' +
      '</div>';
    container.querySelectorAll('[data-icon-upload]').forEach(function (input) {
      input.addEventListener('change', function () {
        setIcon(input.getAttribute('data-icon-upload'), this.files[0]);
      });
    });
    container.querySelectorAll('[data-icon-reset]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-icon-reset');
        var patch = {};
        patch[key] = '';
        api('PUT', '/api/settings', { icons: patch }).then(function (r) {
          state.settings = r.settings;
          applySettings();
          toast('已恢复默认图标');
          renderAdmin();
        }).catch(function (e) { toast(e.message); });
      });
    });
  }
  // 选好图标文件后先裁剪（图标＝方形，头像＝圆形），再上传
  function setIcon(key, file) {
    if (!file) return;
    var circle = (key === 'avatar');
    openAvatarCropper({
      file: file,
      shape: circle ? 'circle' : 'square',
      outSize: circle ? 256 : 192,
      title: circle ? '✂️ 裁剪头像' : '✂️ 裁剪图标',
      onDone: function (blob, restore) { uploadIcon(key, blob, restore); }
    });
  }
  function uploadIcon(key, blob, restore) {
    var fd = new FormData();
    fd.append('file', blob, 'icon.png');
    toast('正在上传图标...');
    fetch('/api/upload', { method: 'POST', headers: { 'Authorization': 'Bearer ' + state.token }, body: fd })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (r.error) throw new Error(r.error);
        state.media.push(r.media);
        var patch = {};
        patch[key] = r.media.url;
        return api('PUT', '/api/settings', { icons: patch });
      })
      .then(function (r) {
        state.settings = r.settings;
        applySettings();
        var m = document.getElementById('avatar-crop-modal');
        if (m) m.parentNode.removeChild(m);
        toast('图标已更新 ✨');
        if (state.view === 'admin') renderAdmin();
      })
      .catch(function (e) { if (restore) restore(); toast(e.message || '操作失败'); });
  }

  /* --- 写文章 --- */
  function renderAdminEditor(container) {
    var p = state.editingPost;
    container.innerHTML =
      '<div class="admin-sec glass">' +
        '<h3>' + (p ? '✏️ 编辑文章 #' + p.id : '📝 发布新文章') + '</h3>' +
        '<div class="form-row"><label>标题</label><input type="text" id="ed-title" value="' + esc(p ? p.title : '') + '" placeholder="文章标题"></div>' +
        '<div class="form-row"><label>正文（支持 Markdown，可用工具栏插入图片/音频）</label>' +
          '<div style="display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap">' +
            '<button class="btn ghost small" id="ed-insert-img">🖼️ 插入图片</button>' +
            '<button class="btn ghost small" id="ed-insert-audio">🎵 插入音频</button>' +
            '<label class="btn ghost small" style="margin:0">📤 上传图片<input type="file" id="ed-upload-img" accept="image/*" hidden></label>' +
            '<label class="btn ghost small" style="margin:0" title="上传后只在你的媒体库可见，不进图库，可直接用在文章里">🔒 上传隐藏图片<input type="file" id="ed-upload-hid" accept="image/*" hidden></label>' +
            '<label class="btn ghost small" style="margin:0">📤 上传音频<input type="file" id="ed-upload-audio" accept="audio/*" hidden></label>' +
          '</div>' +
          '<p class="admin-tip" style="margin:-2px 0 8px">🔒 隐藏图片：能在文章里正常显示，但不会出现在「图库」和访客的媒体列表里。</p>' +
          '<div class="editor-wrap">' +
            '<textarea id="ed-content" placeholder="用 Markdown 写点什么吧...&#10;## 二级标题&#10;**加粗** *斜体*&#10;![图片](图片链接)">' + esc(p ? p.content : '') + '</textarea>' +
            '<div class="editor-preview" id="ed-preview"></div>' +
          '</div>' +
        '</div>' +
        '<div class="form-row" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
          '<input type="checkbox" id="ed-pin"' + (p && p.pinned ? ' checked' : '') + '><label for="ed-pin" style="margin:0">📌 置顶</label>' +
          '<span style="color:rgba(102,204,255,0.5)">|</span>' +
          '<input type="checkbox" id="ed-replace-pin"' + (p && (p.replacePinPending || (p.pinned && !p.publishAt)) ? ' checked' : '') + '>' +
          '<label for="ed-replace-pin" style="margin:0" title="勾选后，这篇文章置顶时会自动取消其他文章的置顶">🔁 替换当前置顶</label>' +
        '</div>' +
        '<div class="form-row">' +
          '<label>⏰ 定时发布（留空 = 立即发布，其他人到点前看不到这篇文章）</label>' +
          '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
            '<input type="datetime-local" id="ed-publish-at" value="' + (p && p.publishAt ? toLocalInput(p.publishAt) : '') + '">' +
            '<button class="btn ghost small" id="ed-clear-sched" type="button">清除定时</button>' +
            '<span class="admin-tip" style="margin:0" id="ed-sched-tip"></span>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;gap:12px">' +
          '<button class="btn primary" id="ed-save">' + (p ? '保存修改' : '发布文章') + '</button>' +
          (p ? '<button class="btn ghost" id="ed-cancel">取消编辑</button>' : '') +
        '</div>' +
      '</div>' +
      '<div class="admin-sec glass"><h3>📚 已发布文章</h3><div id="ed-list"></div></div>';

    var contentEl = $('#ed-content');
    function refreshPreview() { $('#ed-preview').innerHTML = md(contentEl.value); }
    contentEl.addEventListener('input', refreshPreview);
    refreshPreview();

    // 插入已上传的图片/音频：打开素材选择器（含隐藏素材，支持搜索、筛选、缩略图点选）
    $('#ed-insert-img').addEventListener('click', function () {
      openMediaPicker({
        type: 'image',
        onPick: function (m) { insertAtCursor(contentEl, '\n![图片](' + m.url + ')\n'); }
      });
    });
    $('#ed-insert-audio').addEventListener('click', function () {
      openMediaPicker({
        type: 'audio',
        onPick: function (m) { insertAtCursor(contentEl, '\n<audio controls src="' + m.url + '"></audio>\n'); }
      });
    });
    $('#ed-upload-img').addEventListener('change', function () { uploadThenInsert(this.files[0], contentEl, 'image'); this.value = ''; });
    $('#ed-upload-audio').addEventListener('change', function () { uploadThenInsert(this.files[0], contentEl, 'audio'); this.value = ''; });
    $('#ed-upload-hid').addEventListener('change', function () { uploadThenInsert(this.files[0], contentEl, 'image', true); this.value = ''; });

    // 定时发布：实时提示当前状态
    var schedEl = $('#ed-publish-at');
    function refreshSchedTip() {
      var tip = $('#ed-sched-tip');
      if (!tip) return;
      if (!schedEl.value) { tip.textContent = '当前：立即发布'; return; }
      var t = new Date(schedEl.value).getTime();
      if (!t || t <= Date.now()) { tip.textContent = '⚠️ 时间已过，保存后按「立即发布」处理'; return; }
      tip.textContent = '⏳ 保存后将在 ' + fmtFullTime(t) + ' 自动对所有人可见';
    }
    schedEl.addEventListener('input', refreshSchedTip);
    refreshSchedTip();
    $('#ed-clear-sched').addEventListener('click', function () { schedEl.value = ''; refreshSchedTip(); toast('已清除定时，保存后立即发布'); });

    $('#ed-save').addEventListener('click', function () {
      var title = $('#ed-title').value.trim();
      var content = contentEl.value;
      var pinned = $('#ed-pin').checked;
      var replacePin = $('#ed-replace-pin').checked;
      var rawAt = $('#ed-publish-at').value;
      var publishAt = rawAt ? new Date(rawAt).getTime() : 0;
      if (publishAt && publishAt <= Date.now()) publishAt = 0;
      if (publishAt && !confirm('这篇文章会定时在 ' + fmtFullTime(publishAt) + ' 发布，在此之前其他人看不到。确定吗？')) return;
      if (!title) return toast('标题不能为空');
      var payload = { title: title, content: content, pinned: pinned, replacePin: replacePin, publishAt: publishAt };
      var req = p ? api('PUT', '/api/posts/' + p.id, payload) : api('POST', '/api/posts', payload);
      req.then(function () {
        if (publishAt) toast('已定时：' + fmtFullTime(publishAt) + ' 自动发布');
        else toast(p ? '已保存' : '发布成功！');
        state.editingPost = null;
        return refreshPosts();
      }).then(function () {
        if (state.view === 'admin') renderAdmin();
      }).catch(function (e) { toast(e.message); });
    });
    if (p) $('#ed-cancel').addEventListener('click', function () {
      state.editingPost = null; renderAdmin();
    });

    renderPostList($('#ed-list'));
  }
  /* --- 素材选择器：写文章时从媒体库挑图片/音频（含隐藏素材） --- */
  function openMediaPicker(opts) {
    opts = opts || {};
    var isImg = opts.type !== 'audio';
    var onPick = opts.onPick || function () {};
    var old = document.getElementById('media-pick-modal');
    if (old && old.parentNode) old.parentNode.removeChild(old);

    var vis = 'all';   // all | hidden | public
    var kw = '';
    var wrap = document.createElement('div');
    wrap.id = 'media-pick-modal';
    wrap.className = 'modal';
    wrap.innerHTML =
      '<div class="modal-box pick-box">' +
        '<h2>' + (isImg ? '🖼️ 插入图片' : '🎵 插入音频') + '</h2>' +
        '<p class="modal-tip" id="pick-tip">正在读取媒体库…</p>' +
        '<div class="pick-bar">' +
          '<input type="text" id="pick-search" placeholder="搜索文件名…" autocomplete="off">' +
          '<div class="pick-chips" id="pick-chips">' +
            '<span class="fd-chip active" data-vis="all">全部</span>' +
            '<span class="fd-chip" data-vis="hidden">🔒 隐藏素材</span>' +
            '<span class="fd-chip" data-vis="public">公开</span>' +
          '</div>' +
        '</div>' +
        '<div class="pick-grid" id="pick-grid"></div>' +
        '<div class="modal-btns"><button class="btn ghost" type="button" id="pick-close">关闭</button></div>' +
      '</div>';
    document.body.appendChild(wrap);

    var grid = wrap.querySelector('#pick-grid');
    var tip = wrap.querySelector('#pick-tip');
    var searchEl = wrap.querySelector('#pick-search');

    function close() {
      document.removeEventListener('keydown', onKey);
      if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
    }
    function onKey(e) { if (e.key === 'Escape') close(); }
    document.addEventListener('keydown', onKey);
    wrap.addEventListener('click', function (e) { if (e.target === wrap) close(); });
    wrap.querySelector('#pick-close').addEventListener('click', close);

    function pool() {
      return state.media.filter(function (m) { return m.type === (isImg ? 'image' : 'audio'); });
    }
    function visibleList() {
      var list = pool().filter(function (m) {
        if (vis === 'hidden') return !!m.hidden;
        if (vis === 'public') return !m.hidden;
        return true;
      });
      if (kw) {
        list = list.filter(function (m) { return String(m.originalName || '').toLowerCase().indexOf(kw) !== -1; });
      }
      // 新传的排前面，刚上传的那张不用翻
      return list.slice().sort(function (a, b) {
        return (b.uploadedAt || b.id || 0) - (a.uploadedAt || a.id || 0);
      });
    }
    function paint() {
      var all = pool();
      var hid = all.filter(function (m) { return m.hidden; }).length;
      var list = visibleList();
      tip.textContent = '媒体库共 ' + all.length + ' 个' + (isImg ? '图片' : '音频') +
        '（🔒 隐藏 ' + hid + ' 个）· 点缩略图即可插入正文' +
        (list.length === all.length ? '' : ' · 当前筛出 ' + list.length + ' 个');
      grid.innerHTML = list.length ? list.map(function (m) {
        return '<div class="pick-item' + (m.hidden ? ' is-hidden' : '') + '" data-pick-id="' + m.id + '" title="' + esc(m.originalName) + '">' +
          (isImg ? '<img src="' + esc(m.url) + '" alt="" loading="lazy">' : '<div class="pick-audio">🎵</div>') +
          (m.hidden ? '<span class="m-badge" title="隐藏素材：不进图库">🔒 隐藏</span>' : '') +
          '<div class="pick-name">' + esc(m.originalName) + '</div>' +
        '</div>';
      }).join('') : '<div class="pick-empty">' + (all.length
        ? '没有匹配的' + (isImg ? '图片' : '音频') + '，换个关键词或切换到「全部」试试'
        : '媒体库还没有' + (isImg ? '图片' : '音频') + '，先用上方的上传按钮传一个') + '</div>';
      grid.querySelectorAll('[data-pick-id]').forEach(function (el) {
        el.addEventListener('click', function () {
          var id = el.getAttribute('data-pick-id');
          var m = state.media.filter(function (x) { return String(x.id) === id; })[0];
          if (!m) return;
          onPick(m);
          close();
          toast(m.hidden ? '已插入隐藏素材（不进图库）' : '已插入正文');
        });
      });
    }
    searchEl.addEventListener('input', function () { kw = this.value.trim().toLowerCase(); paint(); });
    wrap.querySelectorAll('#pick-chips .fd-chip').forEach(function (c) {
      c.addEventListener('click', function () {
        vis = c.getAttribute('data-vis');
        wrap.querySelectorAll('#pick-chips .fd-chip').forEach(function (x) { x.classList.toggle('active', x === c); });
        paint();
      });
    });
    // 每次打开都拉一次最新列表（刚上传、刚改过隐藏状态的素材不会漏）
    paint();
    loadMedia().then(paint).catch(paint);
    setTimeout(function () { if (searchEl && wrap.parentNode) searchEl.focus(); }, 60);
  }
  function insertAtCursor(el, text) {
    var start = el.selectionStart, end = el.selectionEnd;
    el.value = el.value.slice(0, start) + text + el.value.slice(end);
    el.selectionStart = el.selectionEnd = start + text.length;
    el.focus();
    el.dispatchEvent(new Event('input'));
  }
  function uploadThenInsert(file, el, type, hidden) {
    if (!file) return;
    var fd = new FormData();
    fd.append('file', file);
    if (hidden) fd.append('hidden', '1');
    fetch('/api/upload', { method: 'POST', headers: { 'Authorization': 'Bearer ' + state.token }, body: fd })
      .then(function (r) { return r.json(); })
      .then(function (r) {
        if (r.error) return toast(r.error);
        state.media.push(r.media);
        insertAtCursor(el, type === 'image' ? '\n![图片](' + r.media.url + ')\n' : '\n<audio controls src="' + r.media.url + '"></audio>\n');
        toast(hidden ? '隐藏图片已上传并插入（不进图库）' : '上传成功，已插入正文');
      }).catch(function () { toast('上传失败'); });
  }
  function renderPostList(el) {
    api('GET', '/api/posts').then(function (posts) {
      state.posts = posts;
      el.innerHTML = posts.length ? posts.map(function (p) {
        var live = isPostLive(p);
        var tag = live
          ? (p.pinned ? '<span class="p-tag pin">📌 置顶</span>' : '')
          : '<span class="p-tag sched">⏰ 待发布 ' + fmtFullTime(p.publishAt) + '</span>';
        return '<div class="form-row" style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px dashed rgba(102,204,255,0.25)">' +
          '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + (live && p.pinned ? '📌 ' : '') + esc(p.title) + '</span>' +
          tag +
          '<span style="font-size:11px;color:var(--grey-mid)">' + fmtTime(p.updatedAt) + '</span>' +
          (live ? '' : '<button class="btn ghost small" data-now="' + p.id + '">立即发布</button>') +
          '<button class="btn ghost small" data-edit="' + p.id + '">编辑</button>' +
          '<button class="btn danger small" data-del="' + p.id + '">删除</button>' +
        '</div>';
      }).join('') : '<p style="color:var(--grey-mid);font-size:13px">还没有文章</p>';
      el.querySelectorAll('[data-now]').forEach(function (b) {
        b.addEventListener('click', function () {
          api('PUT', '/api/posts/' + b.getAttribute('data-now'), { publishAt: 0 }).then(function () {
            toast('已立即发布');
            return refreshPosts();
          }).then(function () { if (state.view === 'admin') renderAdmin(); }).catch(function (e) { toast(e.message); });
        });
      });
      el.querySelectorAll('[data-edit]').forEach(function (b) {
        b.addEventListener('click', function () {
          api('GET', '/api/posts/' + b.getAttribute('data-edit')).then(function (p) {
            state.editingPost = p;
            state.adminTab = 'editor';
            renderAdmin();
            window.scrollTo(0, 0);
          });
        });
      });
      el.querySelectorAll('[data-del]').forEach(function (b) {
        b.addEventListener('click', function () {
          if (!confirm('确定删除这篇文章吗？删除后无法恢复。')) return;
          api('DELETE', '/api/posts/' + b.getAttribute('data-del')).then(function () {
            toast('已删除');
            return refreshPosts();
          }).then(function () { if (state.view === 'admin') renderAdmin(); }).catch(function (e) { toast(e.message); });
        });
      });
    });
  }

  /* --- 媒体库 --- */
  function renderAdminMedia(container) {
    container.innerHTML =
      '<div class="admin-sec glass">' +
        '<h3>🗂️ 媒体库</h3>' +
        '<p class="admin-tip" style="margin-bottom:10px">🔒 隐藏素材：只在你的媒体库可见，不会出现在「图库」/「音乐」页和访客的列表里；写文章时点「插入图片」，带 🔒 的即可选用（正文里正常显示）。<br>📁 文件夹：音乐页/图库页会按文件夹分标签展示，访客只能看到有内容的文件夹。</p>' +
        '<div class="folder-manage">' +
          '<div class="folder-chips" id="fd-chips"></div>' +
          '<div class="folder-new">' +
            '<input type="text" id="fd-name" placeholder="新文件夹名（如：风景 / 翻唱）" maxlength="30">' +
            '<select id="fd-type"><option value="image">🖼️ 图片文件夹</option><option value="audio">🎵 音频文件夹</option></select>' +
            '<button class="btn ghost small" id="fd-add">＋ 新建文件夹</button>' +
          '</div>' +
        '</div>' +
        '<div class="upload-zone" id="up-zone">📤 点击选择 或 拖拽文件到这里上传<br><span style="font-size:12px">支持图片：jpg/png/gif/webp · 音频：mp3/flac/wav/ogg/m4a · 视频：mp4/webm/mov（可设为日/夜间壁纸）· 单文件 ≤ 100MB</span>' +
          '<input type="file" id="up-input" multiple accept="image/*,audio/*,video/*">' +
        '</div>' +
        '<div class="folder-bulk" id="m-bulk" style="display:none"></div>' +
        '<div class="media-grid" id="media-grid"></div>' +
      '</div>';
    var zone = $('#up-zone'), input = $('#up-input');
    zone.addEventListener('click', function () { input.click(); });
    zone.addEventListener('dragover', function (e) { e.preventDefault(); zone.classList.add('drag'); });
    zone.addEventListener('dragleave', function () { zone.classList.remove('drag'); });
    zone.addEventListener('drop', function (e) {
      e.preventDefault(); zone.classList.remove('drag');
      uploadFiles(e.dataTransfer.files);
    });
    input.addEventListener('change', function () { uploadFiles(this.files); this.value = ''; });
    // 新建文件夹
    $('#fd-add').addEventListener('click', function () {
      var name = $('#fd-name').value.trim();
      var type = $('#fd-type').value;
      if (!name) return toast('先给文件夹起个名字～');
      api('POST', '/api/folders', { name: name, type: type }).then(function () {
        $('#fd-name').value = '';
        toast('文件夹已创建 ✨');
        return loadFolders();
      }).then(function () { refreshMediaAdmin(); }).catch(function (e) { toast(e.message); });
    });
    $('#fd-name').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); $('#fd-add').click(); }
    });
    renderFolderChips();
    renderMediaGrid($('#media-grid'));
    renderBulkBar();
  }
  /* 文件夹标签（可筛选、可重命名、可删除） */
  function renderFolderChips() {
    var box = $('#fd-chips');
    if (!box) return;
    var imgs = state.media.filter(function (m) { return m.type === 'image'; });
    var auds = state.media.filter(function (m) { return m.type === 'audio'; });
    var cnt = function (f) { return state.media.filter(function (m) { return String(m.folderId) === String(f.id); }).length; };
    var chip = function (val, label, extra) {
      return '<span class="fd-chip' + (state.mFilterFolder === val ? ' active' : '') + '" data-fd="' + val + '">' + label + (extra || '') + '</span>';
    };
    var html = '<span class="fd-label">显示：</span>' +
      ['all', 'image', 'audio', 'video'].map(function (t) {
        var label = t === 'all' ? '全部类型' : (t === 'image' ? '🖼️ 图片' : (t === 'audio' ? '🎵 音频' : '🎬 视频'));
        return '<span class="fd-chip' + (state.mFilterType === t ? ' active' : '') + '" data-fdt="' + t + '">' + label + '</span>';
      }).join('') +
      '<span class="fd-sep">|</span>' + chip('all', '全部 <b>' + state.media.length + '</b>');
    var noneCount = state.media.filter(function (m) { return !m.folderId; }).length;
    html += chip('none', '📄 未分类 <b>' + noneCount + '</b>');
    ['image', 'audio'].forEach(function (type) {
      var list = foldersOf(type);
      if (!list.length) return;
      html += '<span class="fd-sep">' + (type === 'image' ? '🖼️ 图片' : '🎵 音频') + '</span>';
      list.forEach(function (f) {
        html += '<span class="fd-group"><span class="fd-chip' + (String(state.mFilterFolder) === String(f.id) ? ' active' : '') + '" data-fd="' + f.id + '">📁 ' +
          esc(f.name) + ' <b>' + cnt(f) + '</b></span>' +
          '<button class="fd-ico" data-rename="' + f.id + '" title="重命名">✏️</button>' +
          '<button class="fd-ico" data-rmfd="' + f.id + '" title="删除文件夹（文件回到未分类）">✕</button></span>';
      });
    });
    box.innerHTML = html;
    box.querySelectorAll('[data-fdt]').forEach(function (el) {
      el.addEventListener('click', function () {
        state.mFilterType = el.getAttribute('data-fdt');
        renderFolderChips(); renderMediaGrid($('#media-grid'));
      });
    });
    box.querySelectorAll('[data-fd]').forEach(function (el) {
      el.addEventListener('click', function () {
        state.mFilterFolder = el.getAttribute('data-fd');
        renderFolderChips(); renderMediaGrid($('#media-grid'));
      });
    });
    box.querySelectorAll('[data-rename]').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = b.getAttribute('data-rename');
        var name = prompt('新的文件夹名：', folderName(id));
        if (name === null) return;
        api('PUT', '/api/folders/' + id, { name: name }).then(function () {
          toast('已重命名');
          return loadFolders();
        }).then(function () { refreshMediaAdmin(); }).catch(function (err) { toast(err.message); });
      });
    });
    box.querySelectorAll('[data-rmfd]').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.stopPropagation();
        var id = b.getAttribute('data-rmfd');
        if (!confirm('删除文件夹「' + folderName(id) + '」？\n里面的文件不会被删除，会回到「未分类」。')) return;
        api('DELETE', '/api/folders/' + id).then(function (r) {
          if (String(state.mFilterFolder) === String(id)) state.mFilterFolder = 'all';
          toast('文件夹已删除' + (r.movedToUnsorted ? '，' + r.movedToUnsorted + ' 个文件回到未分类' : ''));
          return loadFolders();
        }).then(function () { return loadMedia(); }).then(function () { refreshMediaAdmin(); })
          .catch(function (err) { toast(err.message); });
      });
    });
  }
  /* 批量归类栏 */
  function renderBulkBar() {
    var bar = $('#m-bulk');
    if (!bar) return;
    var ids = Object.keys(state.mediaSel).filter(function (k) { return state.mediaSel[k]; });
    if (!ids.length) { bar.style.display = 'none'; return; }
    var opts = '<option value="0">📄 未分类</option>' +
      'image,audio'.split(',').map(function (type) {
        return foldersOf(type).map(function (f) {
          return '<option value="' + f.id + '">' + (f.type === 'image' ? '🖼️ ' : '🎵 ') + esc(f.name) + '</option>';
        }).join('');
      }).join('');
    bar.style.display = 'flex';
    bar.innerHTML = '<span>已选 <b>' + ids.length + '</b> 个文件</span>' +
      '<span>移动到</span><select id="bulk-fd">' + opts + '</select>' +
      '<button class="btn ghost small" id="bulk-go">归类</button>' +
      '<button class="btn ghost small" id="bulk-clear">取消选择</button>';
    $('#bulk-go').addEventListener('click', function () {
      var fid = $('#bulk-fd').value;
      api('POST', '/api/media/folder', { ids: ids, folderId: Number(fid) }).then(function (r) {
        toast('已归类 ' + r.moved + ' 个文件' + (r.skipped ? '（' + r.skipped + ' 个类型不匹配已跳过）' : ''));
        state.mediaSel = {};
        return loadMedia();
      }).then(function () { refreshMediaAdmin(); }).catch(function (e) { toast(e.message); });
    });
    $('#bulk-clear').addEventListener('click', function () {
      state.mediaSel = {};
      renderBulkBar(); renderMediaGrid($('#media-grid'));
    });
  }
  /* 只刷新媒体库里的三块（不重建整个后台） */
  function refreshMediaAdmin() {
    renderFolderChips();
    renderMediaGrid($('#media-grid'));
    renderBulkBar();
  }
  function uploadFiles(files) {
    var arr = Array.prototype.slice.call(files);
    if (!arr.length) return;
    var done = 0, fail = 0;
    (function next(i) {
      if (i >= arr.length) {
        toast('上传完成：成功 ' + (done) + ' 个' + (fail ? '，失败 ' + fail + ' 个' : ''));
        Promise.all([loadMedia(), loadFolders()]).then(function () {
          if (state.view === 'admin' && state.adminTab === 'media') refreshMediaAdmin();
        });
        return;
      }
      var fd = new FormData();
      fd.append('file', arr[i]);
      // 当前正在看某个文件夹时，上传直接归到该文件夹（类型不匹配由服务端自动落到未分类）
      if (state.mFilterFolder !== 'all' && state.mFilterFolder !== 'none') fd.append('folderId', state.mFilterFolder);
      if (arr[i].size > 100 * 1024 * 1024) {
        fail++;
        toast('「' + arr[i].name + '」超过 100MB 上限，请先压缩再传');
        next(i + 1);
        return;
      }
      fetch('/api/upload', { method: 'POST', headers: { 'Authorization': 'Bearer ' + state.token }, body: fd })
        .then(function (r) {
          // nginx 等网关在体积超限时直接回 413（HTML），r.json() 会抛错，这里先给出明确提示
          if (r.status === 413) {
            fail++;
            toast('「' + arr[i].name + '」被服务器拒绝（413 太大）：请压缩后上传，或调大 nginx 的 client_max_body_size');
            return next(i + 1);
          }
          return r.json().then(function (j) {
            if (j.error) fail++; else { done++; state.media.push(j.media); }
            next(i + 1);
          }).catch(function () { fail++; toast('「' + arr[i].name + '」上传失败（响应异常）'); next(i + 1); });
        })
        .catch(function () { fail++; toast('「' + arr[i].name + '」上传失败（网络错误）'); next(i + 1); });
    })(0);
  }
  function renderMediaGrid(grid) {
    // 先按「类型 + 文件夹」筛选出要显示的文件
    var ms = state.media.filter(function (m) {
      if (state.mFilterType !== 'all' && m.type !== state.mFilterType) return false;
      if (state.mFilterFolder === 'none') return !m.folderId;
      if (state.mFilterFolder !== 'all') return String(m.folderId) === String(state.mFilterFolder);
      return true;
    });
    grid.innerHTML = ms.length ? ms.map(function (m) {
      var thumb = m.type === 'image'
        ? '<img src="' + m.url + '" alt="">'
        : '<div class="audio-thumb">' + (m.type === 'video' ? '🎬' : '🎵') + '</div>';
      var bgBtns = '';
      if (m.type === 'image') {
        bgBtns = '<button class="btn ghost small" data-bg="' + m.id + '">设为背景</button>' +
                 '<button class="btn ghost small" data-bgday="' + m.id + '" title="日间模式显示这张">设为日间</button>' +
                 '<button class="btn ghost small" data-bgnight="' + m.id + '" title="夜间模式显示这张">设为夜间</button>';
      } else if (m.type === 'video') {
        bgBtns = '<button class="btn ghost small" data-bgvidday="' + m.id + '" title="日间模式播放这个视频">设为日间视频</button>' +
                 '<button class="btn ghost small" data-bgvidnight="' + m.id + '" title="夜间模式播放这个视频">设为夜间视频</button>';
      }
      var hideBtn = '<button class="btn ghost small" data-hide="' + m.id + '">' + (m.hidden ? '🔓 公开' : '🔒 隐藏') + '</button>';
      // 同类内是否有上/下邻居（决定按钮是否可用）
      var same = state.media.filter(function (x) { return x.type === m.type; });
      var si = same.indexOf(m);
      var upDis = si <= 0 ? ' disabled' : '';
      var downDis = si >= same.length - 1 ? ' disabled' : '';
      // 归类下拉：未分类 + 同类型的所有文件夹
      var opts = '<option value="0">📄 未分类</option>' + foldersOf(m.type).map(function (f) {
        return '<option value="' + f.id + '"' + (String(m.folderId) === String(f.id) ? ' selected' : '') + '>📁 ' + esc(f.name) + '</option>';
      }).join('');
      return '<div class="media-item glass' + (m.hidden ? ' is-hidden' : '') + '">' + thumb +
        (m.hidden ? '<span class="m-badge" title="隐藏素材：不进图库">🔒 隐藏</span>' : '') +
        '<label class="m-pick" title="勾选后可批量归类"><input type="checkbox" data-pick="' + m.id + '"' + (state.mediaSel[String(m.id)] ? ' checked' : '') + '></label>' +
        '<div class="m-name" title="' + esc(m.originalName) + '">' + esc(m.originalName) + '</div>' +
        '<select class="m-folder" data-folder="' + m.id + '" title="移动到文件夹">' + opts + '</select>' +
        '<div class="m-acts">' +
          '<button class="btn ghost small" data-up="' + m.id + '"' + upDis + ' title="上移">↑</button>' +
          '<button class="btn ghost small" data-down="' + m.id + '"' + downDis + ' title="下移">↓</button>' +
          bgBtns + hideBtn + '<button class="btn danger small" data-del="' + m.id + '">删除</button>' +
        '</div>' +
      '</div>';
    }).join('') : '<p style="color:var(--grey-mid);font-size:13px;grid-column:1/-1">' +
      (state.media.length ? '这个筛选条件下没有文件' : '还没有上传任何文件') + '</p>';
    grid.querySelectorAll('[data-pick]').forEach(function (c) {
      c.addEventListener('change', function () {
        var id = c.getAttribute('data-pick');
        if (c.checked) state.mediaSel[id] = true; else delete state.mediaSel[id];
        renderBulkBar();
      });
    });
    grid.querySelectorAll('[data-folder]').forEach(function (s) {
      s.addEventListener('change', function () {
        var id = s.getAttribute('data-folder');
        api('POST', '/api/media/folder', { ids: [Number(id)], folderId: Number(s.value) }).then(function () {
          var m = state.media.filter(function (x) { return String(x.id) === String(id); })[0];
          if (m) m.folderId = Number(s.value);
          toast(s.value === '0' ? '已移回未分类' : '已归入「' + folderName(s.value) + '」');
          return loadMedia();
        }).then(function () { refreshMediaAdmin(); }).catch(function (e) { toast(e.message); });
      });
    });
    grid.querySelectorAll('[data-up]').forEach(function (b) {
      b.addEventListener('click', function () {
        var m = state.media.filter(function (x) { return String(x.id) === b.getAttribute('data-up'); })[0];
        if (m) moveMedia(m, -1);
      });
    });
    grid.querySelectorAll('[data-down]').forEach(function (b) {
      b.addEventListener('click', function () {
        var m = state.media.filter(function (x) { return String(x.id) === b.getAttribute('data-down'); })[0];
        if (m) moveMedia(m, 1);
      });
    });
    grid.querySelectorAll('[data-bg]').forEach(function (b) {
      b.addEventListener('click', function () {
        var m = state.media.filter(function (x) { return String(x.id) === b.getAttribute('data-bg'); })[0];
        if (!m) return;
        api('PUT', '/api/settings', { backgroundUrl: m.url }).then(function () {
          state.settings.backgroundUrl = m.url;
          applySettings();
          toast('背景已更新 ✨');
        }).catch(function (e) { toast(e.message); });
      });
    });
    /* 日/夜间专属壁纸：图片设 image 位，视频设 video 位（视频优先播放） */
    [['data-bgday', 'backgroundUrlDay', '已设为日间壁纸 ☀️'],
     ['data-bgnight', 'backgroundUrlNight', '已设为夜间壁纸 🌙'],
     ['data-bgvidday', 'backgroundVideoDay', '已设为日间视频壁纸 ☀️▶'],
     ['data-bgvidnight', 'backgroundVideoNight', '已设为夜间视频壁纸 🌙▶']].forEach(function (pair) {
      grid.querySelectorAll('[' + pair[0] + ']').forEach(function (b) {
        b.addEventListener('click', function () {
          var m = state.media.filter(function (x) { return String(x.id) === b.getAttribute(pair[0]); })[0];
          if (!m) return;
          var patch = {}; patch[pair[1]] = m.url;
          api('PUT', '/api/settings', patch).then(function () {
            state.settings[pair[1]] = m.url;
            applyBg();
            toast(pair[2]);
          }).catch(function (e) { toast(e.message); });
        });
      });
    });
    grid.querySelectorAll('[data-hide]').forEach(function (b) {
      b.addEventListener('click', function () {
        var m = state.media.filter(function (x) { return String(x.id) === b.getAttribute('data-hide'); })[0];
        if (!m) return;
        var next = !m.hidden;
        api('POST', '/api/media/' + m.id + '/hidden', { hidden: next }).then(function () {
          m.hidden = next;
          toast(next ? '已隐藏：访客在图库/音乐页看不到它了' : '已公开：图库中可见');
          return loadMedia();
        }).then(function () { refreshMediaAdmin(); }).catch(function (e) { toast(e.message); });
      });
    });
    grid.querySelectorAll('[data-del]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (!confirm('确定删除该文件吗？')) return;
        var id = b.getAttribute('data-del');
        api('DELETE', '/api/media/' + id).then(function () {
          delete state.mediaSel[String(id)];
          toast('已删除');
          return loadMedia();
        }).then(function () { refreshMediaAdmin(); }).catch(function (e) { toast(e.message); });
      });
    });
  }
  /* 媒体排序：在同类文件中上移/下移，保存到服务器 */
  function moveMedia(m, dir) {
    var list = state.media.slice();
    var idx = -1;
    for (var i = 0; i < list.length; i++) if (String(list[i].id) === String(m.id)) { idx = i; break; }
    if (idx < 0) return;
    var step = dir < 0 ? -1 : 1;
    var j = idx + step;
    while (j >= 0 && j < list.length && list[j].type !== m.type) j += step;
    if (j < 0 || j >= list.length) return;
    var tmp = list[idx]; list[idx] = list[j]; list[j] = tmp;
    api('POST', '/api/media/reorder', { ids: list.map(function (x) { return x.id; }) }).then(function () {
      return loadMedia();
    }).then(function () {
      toast('顺序已保存 ✨');
      refreshMediaAdmin();
    }).catch(function (e) { toast(e.message); });
  }

  /* --- 用户管理 --- */
  function renderAdminUsers(container) {
    container.innerHTML =
      '<div class="admin-sec glass">' +
        '<h3>👥 用户管理</h3>' +
        '<p class="admin-tip" id="u-tip">加载中…</p>' +
        '<div id="user-list"></div>' +
      '</div>';
    loadAdminUsers();
  }
  function loadAdminUsers() {
    api('GET', '/api/admin/users').then(function (list) {
      var box = $('#user-list');
      if (!box) return;
      var members = list.filter(function (u) { return !u.isOwner; });
      $('#u-tip').innerHTML = '共 <b>' + list.length + '</b> 位（含站长）· 注册成员 ' + members.length + ' 位<br>' +
        '删除用户会同时清掉 TA 的所有评论和登录状态，不留残留数据，操作不可撤销。';
      box.innerHTML = list.map(function (u) {
        var initial = String(u.username || '?').charAt(0).toUpperCase();
        var links = '';
        if (u.bilibiliUrl) links += '<a href="' + esc(u.bilibiliUrl) + '" target="_blank" rel="noopener">📺</a>';
        if (u.douyinUrl) links += '<a href="' + esc(u.douyinUrl) + '" target="_blank" rel="noopener">🎶</a>';
        return '<div class="user-row">' +
          '<div class="u-dot" style="background:' + esc(u.color || '#66ccff') + '">' +
            avatarDotHtml(u, 'dot-img') + '</div>' +
          '<div class="u-body">' +
            '<div class="u-name">' + (u.isOwner ? '👑 ' : '') + esc(u.username) + ' ' + links + '</div>' +
            '<div class="u-sub">🕒 ' + fmtTime(u.createdAt) + ' · 💬 ' + (u.commentCount || 0) + ' 条评论' +
              (u.signature ? ' · ' + esc(u.signature) : '') + '</div>' +
          '</div>' +
          '<button class="btn ghost small" data-avuser="' + u.id + '" data-avname="' + esc(u.username) + '">改头像</button>' +
          (u.isOwner
            ? '<span class="u-owner-tag">站长</span>'
            : '<button class="btn danger small" data-deluser="' + u.id + '" data-uname="' + esc(u.username) + '">删除</button>') +
        '</div>';
      }).join('');
      box.querySelectorAll('[data-avuser]').forEach(function (b) {
        b.addEventListener('click', function () {
          var uid = b.getAttribute('data-avuser');
          var uname = b.getAttribute('data-avname');
          openAvatarCropper({ onDone: function (blob, restore) {
            uploadAvatarBlob(blob, uid, function () {
              var m = document.getElementById('avatar-crop-modal');
              if (m) m.parentNode.removeChild(m);
              toast('已更新「' + uname + '」的头像 ✨');
              loadAdminUsers();
            }, function (e) {
              if (restore) restore();
              toast(e.message);
            });
          }});
        });
      });
      box.querySelectorAll('[data-deluser]').forEach(function (b) {
        b.addEventListener('click', function () {
          var uname = b.getAttribute('data-uname');
          if (!confirm('确定删除用户「' + uname + '」吗？\nTA 的所有评论和登录状态会一并清除，操作不可撤销。')) return;
          api('DELETE', '/api/users/' + b.getAttribute('data-deluser')).then(function (r) {
            toast('已删除「' + uname + '」' + (r.removedComments ? '，连带清除 ' + r.removedComments + ' 条评论' : ''));
            loadAdminUsers();
            refreshPosts();
          }).catch(function (e) { toast(e.message); });
        });
      });
    }).catch(function (e) {
      var t = $('#u-tip');
      if (t) t.textContent = '加载失败：' + e.message;
    });
  }

  /* --- 设置 --- */
  /* --- 站点设置里的「壁纸取景」控件：日间 / 夜间各一组，组内电脑端 / 手机端各一块，预览框可直接拖动。
     键名 which = "day|night" + "-" + "desktop|mobile"，四块各自独立 --- */
  function bgcropBlockHTML(mode, view, title, frameCls) {
    var which = mode + '-' + view;
    var cfg = bgCropRaw()[mode][view];
    var cells = '';
    [0, 50, 100].forEach(function (y) {
      [0, 50, 100].forEach(function (x) {
        cells += '<button type="button" class="bgc-cell' + (cfg.x === x && cfg.y === y ? ' active' : '') +
          '" data-bgc-cell="' + which + '" data-x="' + x + '" data-y="' + y + '" title="焦点 ' + x + '% / ' + y + '%"></button>';
      });
    });
    return '<div class="bgcrop-card" data-bgc-card="' + which + '">' +
      '<div class="bgcrop-head">' + title + '</div>' +
      '<div class="bgcrop-frame ' + frameCls + '" data-bgc-drag="' + which + '">' +
        '<div class="bgcrop-img"></div>' +
        '<span class="bgcrop-hint">拖动画面调焦点</span>' +
      '</div>' +
      '<div class="bgcrop-ctl">' +
        '<div class="bgc-row"><span class="bgc-label">显示</span>' +
          '<select data-bgc-fit="' + which + '">' +
            '<option value="cover"' + (cfg.fit === 'cover' ? ' selected' : '') + '>铺满裁切</option>' +
            '<option value="contain"' + (cfg.fit === 'contain' ? ' selected' : '') + '>完整显示（留边）</option>' +
            '<option value="fill"' + (cfg.fit === 'fill' ? ' selected' : '') + '>拉伸铺满</option>' +
          '</select>' +
        '</div>' +
        '<div class="bgc-row"><span class="bgc-label">焦点</span><div class="bgc-pad">' + cells + '</div></div>' +
        '<div class="bgc-row"><span class="bgc-label">缩放 <b data-bgc-zoomval="' + which + '">' + cfg.zoom + '%</b></span>' +
          '<input type="range" min="100" max="300" step="5" value="' + cfg.zoom + '" data-bgc-zoom="' + which + '">' +
        '</div>' +
        '<button type="button" class="btn ghost small" data-bgc-reset="' + which + '">恢复默认取景</button>' +
      '</div>' +
    '</div>';
  }
  function bgcropModeHTML(mode, title, tip) {
    return '<div class="bgcrop-mode" data-bgc-mode="' + mode + '">' +
      '<div class="bgcrop-mode-head">' + title + '<span>' + tip + '</span></div>' +
      '<div class="bgcrop-grid">' +
        bgcropBlockHTML(mode, 'desktop', '💻 电脑端（宽屏）', 'bgcrop-frame-wide') +
        bgcropBlockHTML(mode, 'mobile', '📱 手机端（窄屏 ≤860px）', 'bgcrop-frame-tall') +
      '</div>' +
    '</div>';
  }
  /* 取景控件交互：拖动预览、九宫格、显示方式、缩放；改动先存在本地，点「保存设置」才落盘。
     键名形如 "day-desktop" / "night-mobile"，四块互不干扰 */
  function bindBgCrop() {
    var work = bgCropRaw();
    function entry(which) {
      var p = String(which).split('-');
      return (work[p[0]] || work.day)[p[1] || 'desktop'];
    }
    /* 预览素材按「这一组对应的模式」取，优先级与前台真实显示完全一致：
       该模式的视频壁纸优先于图片（图片只是海报），没设视频才走图片回落链。
       own 标记该模式自己有没有配过壁纸，没有的话预览的是兜底图，提示里要说明 */
    function previewAssets(mode) {
      var s = state.settings || {};
      var isNight = mode === 'night';
      var vid = isNight ? (s.backgroundVideoNight || '') : (s.backgroundVideoDay || '');
      var img = isNight
        ? (s.backgroundUrlNight || s.backgroundUrlDay || s.backgroundUrl || '')
        : (s.backgroundUrlDay || s.backgroundUrl || s.backgroundUrlNight || '');
      var own = isNight ? !!(s.backgroundUrlNight || s.backgroundVideoNight)
                        : !!(s.backgroundUrlDay || s.backgroundVideoDay);
      return { img: img, vid: vid, own: own };
    }
    /* 拖动/调整时，若这一套正好是「当前主题 + 当前设备形态」，顺手把真实背景也实时取景，
       这样拖的时候页面上就能看到效果（不落盘，点「保存设置」才写服务器） */
    function applyLive(which) {
      if (which !== bgCropKey()) return;
      var cfg = entry(which);
      setStyle(document.getElementById('bg-image'), bgCropStyle(cfg));
      bgVidSlots().forEach(function (v) { setStyle(v, bgVideoStyleOf(cfg)); });
    }
    function paint(which) {
      var cfg = entry(which);
      // 预览框和它下面的控件在同一个 .bgcrop-card 里，统一按卡片作用域查，避免串到另一块
      var card = document.querySelector('[data-bgc-card="' + which + '"]') || document;
      var frame = card.querySelector('[data-bgc-drag="' + which + '"]');
      if (frame) {
        var box = frame.querySelector('.bgcrop-img');
        var hint = frame.querySelector('.bgcrop-hint');
        var a = previewAssets(String(which).split('-')[0]);
        var oldVid = box.querySelector('video');
        if (a.vid) {
          // 视频壁纸优先（与前台一致，图片只是海报）：直接在预览框里播视频，取景样式与真实背景层同一套
          setStyle(box, bgStyleOf(cfg, ''));
          var v = oldVid;
          if (!v) {
            v = document.createElement('video');
            v.muted = true; v.loop = true; v.autoplay = true;
            v.setAttribute('muted', ''); v.setAttribute('playsinline', '');
            // pointer-events:none：视频层绝不抢指针事件，否则触摸端会拖不动取景框
            v.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;pointer-events:none;';
            // 视频加载失败（地址失效等）时退回图片预览，不留黑框
            v.addEventListener('error', function () {
              if (v.parentNode) v.parentNode.removeChild(v);
              var cur = entry(which), ps = previewAssets(String(which).split('-')[0]);
              if (ps.img) {
                setStyle(box, bgStyleOf(cur, ps.img));
                if (hint) hint.textContent = '视频加载失败，先用图片预览 · 拖动画面调焦点';
              }
            });
            box.appendChild(v);
            var pp = v.play(); if (pp && pp.catch) pp.catch(function () {});
          }
          if (v.getAttribute('src') !== a.vid) v.setAttribute('src', a.vid);
          setStyle(v, bgVideoStyleOf(cfg));
          // 首次创建时 play() 在 src 就位前被调过会被拒，这里补一次确保播起来
          if (v.paused) { var pv = v.play(); if (pv && pv.catch) pv.catch(function () {}); }
          if (hint) hint.textContent = '视频壁纸预览 · 拖动画面调焦点';
        } else if (a.img) {
          if (oldVid) oldVid.parentNode.removeChild(oldVid);
          setStyle(box, bgStyleOf(cfg, a.img));
          if (hint) hint.textContent = a.own ? '拖动画面调焦点' : '该模式还没设壁纸，预览的是默认兜底图 · 拖动调焦点';
        } else {
          if (oldVid) oldVid.parentNode.removeChild(oldVid);
          setStyle(box, bgStyleOf(cfg, ''));
          if (hint) hint.textContent = '还没有设置壁纸，先在上方填图片或视频地址';
        }
      }
      card.querySelectorAll('[data-bgc-cell="' + which + '"]').forEach(function (c) {
        c.classList.toggle('active', Number(c.getAttribute('data-x')) === cfg.x && Number(c.getAttribute('data-y')) === cfg.y);
      });
      var sel = card.querySelector('[data-bgc-fit="' + which + '"]');
      if (sel) sel.value = cfg.fit;
      var zr = card.querySelector('[data-bgc-zoom="' + which + '"]');
      if (zr) zr.value = cfg.zoom;
      var zv = card.querySelector('[data-bgc-zoomval="' + which + '"]');
      if (zv) zv.textContent = cfg.zoom + '%';
      applyLive(which);
    }
    ['day-desktop', 'day-mobile', 'night-desktop', 'night-mobile'].forEach(function (w) { paint(w); });
    // 拖动预览调整焦点（把画面往左拖 = 看右边，和 background-position 的语义一致）
    document.querySelectorAll('[data-bgc-drag]').forEach(function (frame) {
      var which = frame.getAttribute('data-bgc-drag');
      var drag = null;
      var move = function (e) {
        if (!drag) return;
        var r = frame.getBoundingClientRect();
        if (!r.width || !r.height) return;
        var nx = drag.x - (e.clientX - drag.px) / r.width * 100;
        var ny = drag.y - (e.clientY - drag.py) / r.height * 100;
        var cur = entry(which);
        cur.x = Math.max(0, Math.min(100, Math.round(nx)));
        cur.y = Math.max(0, Math.min(100, Math.round(ny)));
        paint(which);
        if (e.cancelable) e.preventDefault();
      };
      var up = function () {
        if (!drag) return;
        drag = null;
        frame.classList.remove('dragging');
        window.removeEventListener('pointermove', move);
        window.removeEventListener('pointerup', up);
        window.removeEventListener('pointercancel', up);
      };
      frame.addEventListener('pointerdown', function (e) {
        var c0 = entry(which);
        drag = { px: e.clientX, py: e.clientY, x: c0.x, y: c0.y };
        frame.classList.add('dragging');
        window.addEventListener('pointermove', move);
        window.addEventListener('pointerup', up);
        window.addEventListener('pointercancel', up);
      });
    });
    document.querySelectorAll('[data-bgc-cell]').forEach(function (c) {
      c.addEventListener('click', function () {
        var which = c.getAttribute('data-bgc-cell');
        var cur = entry(which);
        cur.x = Number(c.getAttribute('data-x'));
        cur.y = Number(c.getAttribute('data-y'));
        paint(which);
      });
    });
    document.querySelectorAll('[data-bgc-fit]').forEach(function (sel) {
      sel.addEventListener('change', function () {
        var which = sel.getAttribute('data-bgc-fit');
        entry(which).fit = BG_FITS.indexOf(sel.value) !== -1 ? sel.value : 'cover';
        paint(which);
      });
    });
    document.querySelectorAll('[data-bgc-zoom]').forEach(function (r) {
      r.addEventListener('input', function () {
        var which = r.getAttribute('data-bgc-zoom');
        entry(which).zoom = Math.max(100, Math.min(300, Number(r.value) || 100));
        paint(which);
      });
    });
    document.querySelectorAll('[data-bgc-reset]').forEach(function (b) {
      b.addEventListener('click', function () {
        var which = b.getAttribute('data-bgc-reset');
        var p = which.split('-');
        work[p[0]][p[1]] = { fit: BG_CROP_DEF.fit, x: BG_CROP_DEF.x, y: BG_CROP_DEF.y, zoom: BG_CROP_DEF.zoom };
        paint(which);
      });
    });
    return work;
  }

  function renderAdminSettings(container) {
    var s = state.settings;
    container.innerHTML =
      '<div class="admin-sec glass">' +
        '<h3>⚙️ 站点设置</h3>' +
        '<div class="form-row"><label>站点标题</label><input type="text" id="st-title" value="' + esc(s.siteTitle) + '"></div>' +
        '<div class="form-row"><label>副标题</label><input type="text" id="st-sub" value="' + esc(s.subtitle) + '"></div>' +
        '<div class="form-row"><label>📢 公告（显示在首页）</label><input type="text" id="st-notice" value="' + esc(s.notice || '') + '"></div>' +
        '<div class="form-row"><label>🔗 公告点击跳转文章</label>' +
          '<select id="st-noticelink"><option value="">不跳转（公告仅展示）</option></select>' +
          '<p class="admin-tip">选一篇文章后，首页公告会变成可点击的链接，访客点一下直达这篇文章；换公告内容后记得重新检查跳转是否还对得上。</p>' +
        '</div>' +
        '<div class="form-row"><label>📺 B站主页链接</label><input type="url" id="st-bili" value="' + esc(s.bilibiliUrl) + '" placeholder="https://space.bilibili.com/xxxxx"></div>' +
        '<div class="form-row"><label>🎶 抖音主页链接</label><input type="url" id="st-douyin" value="' + esc(s.douyinUrl) + '" placeholder="https://www.douyin.com/user/xxxxx"></div>' +
        '<div class="form-row"><label>💬 关于页内容</label><textarea id="st-about">' + esc(s.about || '') + '</textarea></div>' +
        '<div class="form-row"><label>🌟 特别感谢名单（Markdown，对应 #/thanks 页面，关于页入口自动显示）</label>' +
          '<textarea id="st-thanks" style="min-height:220px">' + esc(s.thanks || '') + '</textarea>' +
          '<p class="admin-tip" style="margin-top:8px">支持 Markdown：<code>## 小标题</code>、<code>- 列表</code>、<code>**加粗**</code>。留空时页面显示「名单整理中」。</p>' +
        '</div>' +
        '<div class="form-row"><label>🔒 隐私政策内容（Markdown，对应 #/privacy 页面）</label>' +
          '<textarea id="st-privacy" style="min-height:300px">' + esc(s.privacy || '') + '</textarea>' +
          '<p class="admin-tip" style="margin-top:8px">支持 Markdown：<code>## 小标题</code>、<code>- 列表</code>、<code>**加粗**</code>。改完点下方「保存设置」，关于页的隐私政策入口会同步更新。</p>' +
        '</div>' +
        '<div class="form-row"><label>🕒 隐私政策「最后更新」</label><input type="text" id="st-privacy-at" value="' + esc(s.privacyUpdatedAt || '') + '" placeholder="如 2025年11月"></div>' +
        '<div class="form-row"><label>✉️ 举报 / 联系邮箱（显示在隐私政策页底部）</label><input type="text" id="st-privacy-mail" value="' + esc(s.privacyContactEmail || '') + '" placeholder="如 moeku@foxmail.com"></div>' +
        '<div class="form-row"><label>👀 隐私政策入口</label>' +
          '<label class="check-line"><input type="checkbox" id="st-privacy-on"' + (s.privacyEnabled === false ? '' : ' checked') + '> 在「关于」页底部显示隐私政策入口卡片</label>' +
        '</div>' +
        '<div class="form-row"><label>🌌 默认背景图片地址（日/夜间没单独设置时的兜底，可在媒体库中点「设为背景」快速设置）</label>' +
          '<input type="text" id="st-bg" value="' + esc(s.backgroundUrl) + '">' +
        '</div>' +
        '<div class="form-row"><label>☀️ 日间模式壁纸地址（图片，空 = 用上面的默认背景）</label>' +
          '<input type="text" id="st-bg-day" value="' + esc(s.backgroundUrlDay || '') + '" placeholder="留空则日间使用默认背景">' +
        '</div>' +
        '<div class="form-row"><label>🌙 夜间模式壁纸地址（图片，空 = 用日间壁纸 → 默认背景）</label>' +
          '<input type="text" id="st-bg-night" value="' + esc(s.backgroundUrlNight || '') + '" placeholder="留空则夜间跟随日间壁纸">' +
        '</div>' +
        '<div class="form-row"><label>☀️▶ 日间模式壁纸视频地址（设置后日间改为播放视频，图片作加载兜底；可在媒体库对视频点「设为日间视频」）</label>' +
          '<input type="text" id="st-bgvid-day" value="' + esc(s.backgroundVideoDay || '') + '" placeholder="留空则日间显示静态壁纸">' +
        '</div>' +
        '<div class="form-row"><label>🌙▶ 夜间模式壁纸视频地址（设置后夜间改为播放视频；可在媒体库对视频点「设为夜间视频」）</label>' +
          '<input type="text" id="st-bgvid-night" value="' + esc(s.backgroundVideoNight || '') + '" placeholder="留空则夜间显示静态壁纸">' +
          '<p class="admin-tip" style="margin-top:8px">视频壁纸会静音循环自动播放，切到后台自动暂停省电。建议用 720p 左右的短视频（mp4/webm），太大会拖慢首屏。</p>' +
        '</div>' +
        '<div class="form-row"><label>🖼️ 壁纸取景 / 裁剪（图片和视频壁纸通用，日间 / 夜间分开）</label>' +
          '<p class="admin-tip" style="margin:-2px 0 10px">日间和夜间用的是两套壁纸（图片或视频），构图不一样，所以取景分开设置；每套里再分电脑宽屏和手机竖屏——手机竖屏常常只剩中间一条，必须单独调。<b>直接拖动预览画面</b>移动焦点（拖的时候页面上就是这个效果），或点九宫格快速定位；还能改显示方式（铺满裁切 / 完整显示 / 拉伸）和缩放。改完点下方「保存设置」落盘，手机端参数只在屏宽 ≤860px 时用。</p>' +
          '<div class="bgcrop-modes">' +
            bgcropModeHTML('day', '☀️ 日间模式壁纸取景', '日间模式的图片 / 视频壁纸都按这套取景') +
            bgcropModeHTML('night', '🌙 夜间模式壁纸取景', '夜间模式的图片 / 视频壁纸都按这套取景') +
          '</div>' +
        '</div>' +
        '<div class="form-row"><label>📅 建站时间（公示在侧栏和首页，格式如 2026-09-22）</label><input type="text" id="st-created" value="' + esc(s.createdAt || '') + '"></div>' +
        '<div class="form-row"><label>🎵 访客进入网站时自动播放背景音乐（播放媒体库里的音乐）</label>' +
          '<label class="check-line"><input type="checkbox" id="st-autoplay"' + (s.autoPlay ? ' checked' : '') + '> 开启后访客一进站就自动开始播放；若浏览器拦截，会在访客第一次点击页面时自动开始</label>' +
        '</div>' +
        '<div class="form-row"><label>▶️ 自动播放优先曲目（开启自动播放时先放这首）</label>' +
          '<select id="st-autoplay-track" style="width:100%;padding:10px 12px;border-radius:10px;border:1px solid rgba(102,204,255,0.35);background:rgba(255,255,255,0.6);color:inherit;font-size:14px">' +
            '<option value="">默认（音乐列表第一首）</option>' +
            state.media.filter(function (m) { return m.type === 'audio' && !m.hidden; }).map(function (m) {
              return '<option value="' + m.id + '"' + (String(s.autoPlayId) === String(m.id) ? ' selected' : '') + '>' + esc(m.originalName) + '</option>';
            }).join('') +
          '</select>' +
        '</div>' +
        '<div class="form-row"><label>📖 未读文章呼吸提醒</label>' +
          '<label class="check-line"><input type="checkbox" id="st-unreadglow"' + (s.unreadGlow !== false ? ' checked' : '') + '> 没点开过的文章卡片带呼吸光晕，引导访客点击（像播放条的呼吸提示一样；访客点开过就熄灭，浏览记录存在访客自己的浏览器里）</label>' +
        '</div>' +
        '<div class="form-row"><label>👑 站长名字（签名板中心气泡）</label><input type="text" id="st-ownername" value="' + esc(s.ownerName || '') + '"></div>' +
        '<div class="form-row"><label>🫧 站长签名（签名板中心气泡内容，≤100字）</label><textarea id="st-ownersign" maxlength="120">' + esc(s.ownerSignature || '') + '</textarea></div>' +
        '<div class="form-row"><label>👑 站长气泡颜色</label><input type="color" id="st-ownercolor" value="' + esc(s.ownerColor || '#66ccff') + '" style="width:60px;height:36px;padding:0;border:1px solid rgba(102,204,255,0.35);border-radius:8px;cursor:pointer"></div>' +
        '<div class="form-row"><label>🧑‍🤝‍🧑 默认头像（没有自定义头像的成员都会显示它）</label>' +
          '<div class="me-avatar-row" style="margin-bottom:6px">' +
            (s.defaultAvatar
              ? '<img class="me-avatar" src="' + esc(s.defaultAvatar) + '" alt="默认头像">'
              : '<div class="me-avatar" style="background:rgba(102,204,255,0.25)">?</div>') +
            '<div>' +
              '<div style="display:flex;gap:10px;flex-wrap:wrap">' +
                '<button class="btn ghost" id="st-defav-btn">📷 ' + (s.defaultAvatar ? '更换默认头像' : '选择图片设为默认头像') + '</button>' +
                (s.defaultAvatar ? '<button class="btn ghost small" id="st-defav-clear">清除（恢复显示首字母）</button>' : '') +
              '</div>' +
              '<p class="admin-tip" style="margin-top:8px">同样走圆形裁剪，5MB 以内；设置后签名板气泡、评论、主页里没传过头像的小伙伴会统一显示这张图，成员上传自己的头像后自动覆盖。</p>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<button class="btn primary" id="st-save">保存设置</button>' +
      '</div>' +
      '<div class="admin-sec glass">' +
        '<h3>🔑 修改管理密码</h3>' +
        '<div class="form-row"><label>旧密码</label><input type="password" id="pw-old"></div>' +
        '<div class="form-row"><label>新密码（至少 6 位）</label><input type="password" id="pw-new"></div>' +
        '<button class="btn primary" id="pw-save">修改密码</button>' +
      '</div>' +
      '<div class="admin-sec glass">' +
        '<h3>📊 数据管理</h3>' +
        '<div class="form-row"><label>当前访问次数</label><span id="rv-count" style="font-weight:700;color:var(--accent,#66ccff)">' + (state.stats ? state.stats.visits : '…') + '</span></div>' +
        '<button class="btn" id="rv-reset" style="border-color:#ff6b81;color:#ff6b81">🔄 访客清零</button>' +
        '<p style="font-size:12px;opacity:.6;margin-top:8px">清零后侧栏和首页公示的访问次数将归零重新累计，此操作不可撤销。</p>' +
      '</div>';
    var bgCropWork = bindBgCrop();
    // 公告跳转下拉：拉最新文章列表填充（含定时发布的，站长视角全可见）
    (function () {
      var sel = $('#st-noticelink');
      if (!sel) return;
      api('GET', '/api/posts').then(function (posts) {
        if (!$('#st-noticelink')) return; // 页面可能已被重渲染
        (posts || []).forEach(function (p) {
          var o = document.createElement('option');
          o.value = p.id;
          o.textContent = '#' + p.id + ' · ' + (p.title || '（无标题）');
          sel.appendChild(o);
        });
        sel.value = (posts || []).some(function (p) { return String(p.id) === String(s.noticeLink); }) ? String(s.noticeLink) : '';
      }).catch(function () {});
    })();
    $('#rv-reset').addEventListener('click', function () {
      if (!confirm('确定要把访问次数清零吗？此操作不可撤销。')) return;
      api('POST', '/api/reset-visits').then(function (r) {
        state.stats = { visits: r.visits, createdAt: state.settings.createdAt };
        window._visits = 0;
        $('#rv-count').textContent = '0';
        $('#stat-visits').textContent = '0';
        var hv = $('#hero-visits');
        if (hv) hv.textContent = '0';
        toast('访问次数已清零 🔄');
      }).catch(function (e) { toast(e.message); });
    });
    $('#st-defav-btn') && $('#st-defav-btn').addEventListener('click', function () {
      openAvatarCropper({ onDone: function (blob, restore) {
        uploadAvatarBlob(blob, 'default', function () {
          var m = document.getElementById('avatar-crop-modal');
          if (m) m.parentNode.removeChild(m);
          loadSettings().then(function () {
            toast('默认头像已设置，没传头像的小伙伴都会用它 ✨');
            renderAdminSettings(document.getElementById('admin-body'));
          });
        }, function (e) {
          if (restore) restore();
          toast(e.message);
        });
      }});
    });
    $('#st-defav-clear') && $('#st-defav-clear').addEventListener('click', function () {
      api('PUT', '/api/settings', { defaultAvatar: '' }).then(function (r) {
        state.settings = r.settings;
        toast('已清除默认头像，恢复显示名字首字母');
        renderAdminSettings(document.getElementById('admin-body'));
      }).catch(function (e) { toast(e.message); });
    });
    $('#st-save').addEventListener('click', function () {
      api('PUT', '/api/settings', {
        siteTitle: $('#st-title').value,
        subtitle: $('#st-sub').value,
        notice: $('#st-notice').value,
        noticeLink: $('#st-noticelink') ? $('#st-noticelink').value : (state.settings.noticeLink || ''),
        bilibiliUrl: $('#st-bili').value.trim(),
        douyinUrl: $('#st-douyin').value.trim(),
        about: $('#st-about').value,
        thanks: $('#st-thanks').value,
        privacy: $('#st-privacy').value,
        privacyUpdatedAt: $('#st-privacy-at').value.trim(),
        privacyContactEmail: $('#st-privacy-mail').value.trim(),
        privacyEnabled: $('#st-privacy-on').checked,
        backgroundUrl: $('#st-bg').value.trim(),
        backgroundUrlDay: $('#st-bg-day').value.trim(),
        backgroundUrlNight: $('#st-bg-night').value.trim(),
        backgroundVideoDay: $('#st-bgvid-day').value.trim(),
        backgroundVideoNight: $('#st-bgvid-night').value.trim(),
        bgCrop: bgCropWork,
        createdAt: $('#st-created').value.trim(),
        unreadGlow: $('#st-unreadglow').checked,
        autoPlay: $('#st-autoplay').checked,
        autoPlayId: $('#st-autoplay-track').value,
        ownerName: $('#st-ownername').value.trim(),
        ownerSignature: $('#st-ownersign').value.slice(0, 100),
        ownerColor: $('#st-ownercolor').value
      }).then(function (r) {
        state.settings = r.settings;
        applySettings();
        toast('设置已保存 ✨');
      }).catch(function (e) { toast(e.message); });
    });
    $('#pw-save').addEventListener('click', function () {
      api('POST', '/api/change-password', { oldPassword: $('#pw-old').value, newPassword: $('#pw-new').value }).then(function () {
        toast('密码已修改，请重新登录');
        state.token = '';
        state.me = null;
        updateUserChip();
        localStorage.removeItem('d6cf_token');
        location.hash = '#/home';
      }).catch(function (e) { toast(e.message); });
    });
  }

  /* ---------------- 日间 / 夜间模式 ---------------- */
  function currentTheme() {
    return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
  }
  function applyTheme(mode, opts) {
    opts = opts || {};
    var prev = currentTheme();
    document.documentElement.setAttribute('data-theme', mode);
    if (opts.persist !== false) {
      try { localStorage.setItem('d6cf_theme', mode); } catch (e) {}
    }
    document.querySelectorAll('.theme-toggle').forEach(function (b) {
      b.textContent = mode === 'dark' ? '☀️' : '🌙';
      b.title = mode === 'dark' ? '切换到日间模式' : '切换到夜间模式';
    });
    if (mode !== prev) applyBg();   // 日/夜间壁纸（含视频）跟着主题切换
    if (opts.toast) toast(mode === 'dark' ? '已切换到夜间模式 🌙' : '已切换到日间模式 ☀️');
  }
  document.querySelectorAll('.theme-toggle').forEach(function (b) {
    b.addEventListener('click', function () {
      applyTheme(currentTheme() === 'dark' ? 'light' : 'dark', { persist: true, toast: true });
    });
  });
  /* 跟随系统（仅当用户没手动选过时） */
  if (window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var mqHandler = function (e) {
      var saved = null;
      try { saved = localStorage.getItem('d6cf_theme'); } catch (err) {}
      if (!saved) applyTheme(e.matches ? 'dark' : 'light', { persist: false });
    };
    if (mq.addEventListener) mq.addEventListener('change', mqHandler);
    else if (mq.addListener) mq.addListener(mqHandler);
  }
  applyTheme(currentTheme(), { persist: false });

  /* ---------------- 初始化 ---------------- */
  function refreshPosts() {
    return api('GET', '/api/posts').then(function (posts) { state.posts = posts; });
  }

  $('#m-menu-btn').addEventListener('click', function () {
    $('#sidebar').classList.toggle('open');
  });

  /* 全屏模式：进全屏后浏览器自带的工具栏/地址栏会隐藏（部分浏览器不支持则不显示按钮） */
  (function () {
    var btn = $('#fs-toggle-m');
    var root = document.documentElement;
    if (!btn || !root.requestFullscreen) return;
    btn.style.display = '';
    function syncIcon() {
      btn.textContent = document.fullscreenElement ? '✕' : '⛶';
      btn.title = document.fullscreenElement ? '退出全屏' : '全屏模式（隐藏浏览器工具栏）';
    }
    btn.addEventListener('click', function () {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(function () {});
      } else {
        var p = root.requestFullscreen();
        if (p && p.catch) p.catch(function () { toast('这个浏览器不允许进入全屏'); });
      }
    });
    document.addEventListener('fullscreenchange', syncIcon);
    syncIcon();
  })();

  window.addEventListener('hashchange', route);

  /* 自动播放背景音乐（站长在站点设置中开启后生效；可指定优先曲目） */
  function tryAutoPlay() {
    if (!state.settings.autoPlay || state.playIndex >= 0) return;
    // 没进过音乐页时歌单是空的，这里直接用媒体库里的音频兜底（顺序须与音乐页一致：不含隐藏素材）
    if (!state.playlist.length) {
      state.playlist = state.media.filter(function (m) { return m.type === 'audio' && !m.hidden; });
    }
    if (!state.playlist.length) return;
    var idx = 0;
    var want = state.settings.autoPlayId;
    if (want) {
      for (var i = 0; i < state.playlist.length; i++) {
        if (String(state.playlist[i].id) === String(want)) { idx = i; break; }
      }
    }
    window._playByIndex(idx);
  }

  /* ---------------- 首屏启动屏（学 moeku.org 的加载体验） ----------------
     机制：等接口数据就绪 + 首屏资源（站点背景图 / 站点头像 / 日夜间视频壁纸 / 要播的第一首音乐）
     准备好，再让启动屏至少停留 BOOT_MIN_HOLD 后淡出；无论如何都在 BOOT_TIMEOUT 兜底收起。 */
  var BOOT_MIN_HOLD = 1200; // 数据就绪后至少再停留的时长（ms），避免启动屏一闪而过
  var BOOT_FADE = 900;      // 启动屏淡出时长（ms），与 CSS 里 #boot-loader 的 transition 保持一致
  var BOOT_TIMEOUT = 11500; // 兜底：视频壁纸软等待 10s + 余量，到点无论如何收起启动屏
  var bootStart = Date.now();
  function preloadImage(url) {
    return new Promise(function (resolve) {
      if (!url) return resolve();
      var img = new Image();
      img.onload = img.onerror = function () { resolve(); };
      img.src = url;
    });
  }
  /* 自动播放优先曲目（与 tryAutoPlay 同一套选择逻辑）：启动屏期间就把它缓冲起来 */
  function autoTrackUrl() {
    if (!state.settings || !state.settings.autoPlay) return '';
    var list = state.playlist.length ? state.playlist : state.media.filter(function (m) { return m.type === 'audio' && !m.hidden; });
    if (!list.length) return '';
    var pick = list[0], want = state.settings.autoPlayId;
    if (want) {
      for (var i = 0; i < list.length; i++) {
        if (String(list[i].id) === String(want)) { pick = list[i]; break; }
      }
    }
    return pick.url || '';
  }
  function preloadAudio(url) {
    if (!url) return;
    var a = document.getElementById('audio');
    if (!a || a.getAttribute('src') === url) return;
    a.preload = 'auto';
    a.setAttribute('src', url);
    try { a.load(); } catch (e) {}
  }
  // 把站点头像 / 站点名填进启动屏（在数据到达后尽早调用）
  function applyBootInfo() {
    var icons = (state.settings && state.settings.icons) || {};
    var av = $('#bl-avatar');
    if (av && icons.avatar) av.innerHTML = '<img src="' + esc(icons.avatar) + '" alt="">';
    var sub = $('#bl-sub');
    if (sub && state.settings && state.settings.siteTitle) sub.textContent = state.settings.siteTitle;
  }
  function hideBootLoader() {
    var el = $('#boot-loader');
    if (!el || el.classList.contains('done')) return;
    document.documentElement.classList.add('boot-in'); // 揭示首屏内容（0.9s 淡入 + 轻微上移）
    el.classList.add('done');                          // 启动屏淡出
    setTimeout(function () {
      el.classList.add('hidden');
      // 淡出完成后彻底清掉启动态标记，不留残留样式
      var html = document.documentElement;
      html.removeAttribute('data-booting');
      html.classList.remove('boot-in');
    }, BOOT_FADE + 80);
  }
  var bootFallback = setTimeout(hideBootLoader, BOOT_TIMEOUT);

  initHoverFloat();
  initRiseObserver();
  initLiquidDrip();
  initFxPanel();
  applyFx(); // 按访客的动效偏好套用（含 has-hover-float / fx-off 标记）

  Promise.all([loadSettings(), refreshPosts(), loadMedia(), loadFolders(), loadMe(), loadStats()])
    .then(function () {
      countVisit();
      route();
      applyBootInfo();
      preloadAudio(autoTrackUrl());   // 启动屏期间先把要播的第一首音乐缓冲起来
      tryAutoPlay();
    })
    .catch(function (e) {
      viewEl.innerHTML = '<div class="empty-tip glass">加载失败：' + esc(e.message) + '</div>';
    })
    .then(function () {
      // 启动屏期间把首屏要用的资源一起下下来：
      //   · 日/夜间两套视频壁纸 → 挂进两块视频槽预热，切主题直接换槽不再闪静态图
      //   · 日/夜间图片壁纸 + 站点头像
      //   · 当前主题背景「定下来」的时刻：视频出画面，或超过 10s 先用静态壁纸顶上
      var s = state.settings || {};
      var icons = s.icons || {};
      bgWarmVideos();
      return Promise.all([
        preloadImage(s.backgroundUrlDay),
        preloadImage(s.backgroundUrlNight),
        preloadImage(s.backgroundUrl),
        preloadImage(icons.avatar),
        (bgSettle || Promise.resolve())
      ]);
    })
    .then(function () {
      var rest = BOOT_MIN_HOLD - (Date.now() - bootStart);
      setTimeout(function () { clearTimeout(bootFallback); hideBootLoader(); }, Math.max(0, rest));
    });
})();
