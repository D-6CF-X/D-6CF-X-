D-6CF-X的临时小站 - 宝塔面板部署指南
=====================================

一、准备环境（宝塔面板操作）
---------------------------
1. 宝塔【软件商店】安装：
   - Nginx（任意稳定版本）
   - PM2管理器（会自带 Node.js，建议 Node 14+）
2. 本目录 d6cf-site 整个文件夹上传到服务器，例如：/www/wwwroot/d6cf-site
   （可用宝塔【文件】功能直接上传压缩包后解压）

二、安装依赖并启动
------------------
方式A（推荐，宝塔 PM2 管理器）：
1. 宝塔终端里执行：
   cd /www/wwwroot/d6cf-site
   npm install --production
2. PM2管理器 → 添加项目：
   - 项目路径：/www/wwwroot/d6cf-site
   - 启动文件：server.js
   - 项目名称：d6cf-site
3. 启动后访问 http://服务器IP:3000 即可看到网站。

方式B（命令行手动）：
   cd /www/wwwroot/d6cf-site
   npm install --production
   pm2 start server.js --name d6cf-site
   pm2 save

三、绑定正式域名 luotianyi.click（备案已通过）
--------------------------------------
当前状态：站点跑在 http://47.106.178.118:3000（PM2 直连），域名尚未接入。

1. 阿里云【域名 → 解析设置】添加记录：
   - 记录类型 A，主机记录 @，记录值 47.106.178.118
   - （可选）再添一条 A 记录，主机记录 www，记录值同上
2. 宝塔【网站】→ 添加站点：
   - 域名填 luotianyi.click（要 www 就连着填 www.luotianyi.click）
   - 数据库、PHP 都选「不创建 / 纯静态」
3. 该站点【设置 → 反向代理】→ 添加反向代理：
   - 代理名称：d6cf
   - 目标 URL：http://127.0.0.1:3000
   - 发送域名：$host
4. 该站点【设置 → 配置文件】，在 server {} 内加一行（大文件上传用）：
   client_max_body_size 200m;
5. 该站点【设置 → SSL】→ Let's Encrypt → 勾选域名 → 申请 → 开启「强制 HTTPS」
   （申请前域名必须已解析生效，且 80 端口可从公网访问）
6. 开启「旧地址跳转」：让 http://47.106.178.118:3000 自动跳到新域名。
   在站点目录建配置文件（data/ 不在部署包里，更新站点不会覆盖）：
     cd /www/wwwroot/d6cf-site
     echo '{ "domain": "luotianyi.click", "redirect": true }' > data/site-domain.json
     pm2 restart d6cf-site
   关闭跳转：把 true 改成 false（或删掉该文件）后 pm2 restart d6cf-site。
   也可用环境变量：SITE_DOMAIN=luotianyi.click DOMAIN_REDIRECT=on pm2 restart d6cf-site --update-env
7. ⚠️ 提醒：域名解析生效通常几分钟到几小时；备案信息需与本服务器一致，
   否则国内访问会被拦截。3000 端口可在宝塔【安全】里关闭对外，
   关闭后域名访问不受影响（Nginx 走 127.0.0.1:3000 本机回环）。

四、首次使用
------------
1. 打开网站，左侧栏底部点「⚙️ 小站管理」
2. 默认密码：d6cfx123 （请立即在「站点设置→修改管理密码」中改掉！）
3. 在「站点设置」中填写：
   - B站主页链接（如 https://space.bilibili.com/你的ID）
   - 抖音主页链接
   - 公告、副标题、关于内容
4. 在「媒体库」上传背景图 → 点「设为背景」
5. 在「写文章」中发布第一篇文章（支持 Markdown，可直接上传图片/音频插入正文）

五、数据备份
------------
所有内容保存在两个目录，定期用宝塔备份即可：
  - /www/wwwroot/d6cf-site/data/db.json   （文章、设置）
  - /www/wwwroot/d6cf-site/uploads/       （上传的音乐和图片）

六、常见问题
------------
Q: 访问 502？
A: 检查 PM2 中项目是否在运行；端口是否为 3000。
Q: 上传大文件失败？
A: Nginx 反代时在配置中加 client_max_body_size 200m;（宝塔站点配置文件里）。
Q: 想改端口？
A: 启动命令前加环境变量，如 PORT=8080 pm2 start server.js
