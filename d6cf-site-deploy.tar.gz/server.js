/**
 * D-6CF-X的临时小站 - 后端服务
 * Express + JSON 文件存储（无需数据库），支持 Node 12+
 */
const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ---------------- 数据层 ---------------- */
function sha256(str) {
  return crypto.createHash('sha256').update(String(str), 'utf8').digest('hex');
}

const DEFAULT_DB = {
  settings: {
    siteTitle: 'D-6CF-X的临时小站',
    subtitle: '一个临时的、半透明的、属于洛天依的小角落',
    backgroundUrl: '/assets/default-bg.jpg',
    backgroundUrlDay: '',   // 日间模式专属壁纸（空 = 用 backgroundUrl 兜底）
    backgroundUrlNight: '', // 夜间模式专属壁纸（空 = 依次用日间 / backgroundUrl 兜底）
    backgroundVideoDay: '',   // 日间模式壁纸视频（设置后日间改为播放视频，图片作加载兜底）
    backgroundVideoNight: '', // 夜间模式壁纸视频
    // 壁纸裁剪/取景（fit: cover 铺满裁切 / contain 完整显示 / fill 拉伸铺满；x,y 焦点百分比 0-100；zoom 缩放 100-300）
    // 日间 / 夜间各一套，套内再分 desktop（宽屏）/ mobile（窄屏 ≤860px）：
    // 日夜壁纸不同、构图也不同；手机竖屏比例更要把取景单独调，免得只剩中间一条
    bgCrop: {
      day: {
        desktop: { fit: 'cover', x: 50, y: 50, zoom: 100 },
        mobile: { fit: 'cover', x: 50, y: 50, zoom: 100 }
      },
      night: {
        desktop: { fit: 'cover', x: 50, y: 50, zoom: 100 },
        mobile: { fit: 'cover', x: 50, y: 50, zoom: 100 }
      }
    },
    bilibiliUrl: '',
    douyinUrl: '',
    about: '这里是 D-6CF-X 的临时小站。\n\n域名：luotianyi.click（暂未备案，即将接入）',
    notice: '欢迎来到我的小站！',
    // 公告点击跳转的文章 id（空串 = 公告纯展示不可点）
    noticeLink: '',
    // 未读文章呼吸提醒：没点开过的文章卡片带呼吸光晕引导点击（访客浏览记录存浏览器本地）
    unreadGlow: true,
    // 全站文案覆盖：{ 文案键: 站长自定义的文字 }，留空/缺失的键前端自动回落默认文案
    // 键名由前端 SITE_TEXTS 定义（如 nav_home / dm_slogan / page_music_title / footer_beian…）
    texts: {},
    // 隐私政策（Markdown，站长可在【设置 → 站点设置】里修改；按本站真实的数据处理方式撰写）
    privacy: [
      '欢迎使用 D-6CF-X 的临时小站（luotianyi.click）。我们非常重视您的隐私。本隐私政策说明了当您访问、注册及使用本站功能时，我们收集、使用、存储和保护您信息的方式。',
      '',
      '## 网站性质',
      '',
      '本网站是一个由站长自主搭建与运营的动态网站，这意味着：',
      '',
      '- 为提供注册、评论、签名板、媒体库等互动功能，本站会在服务器端存储部分必要数据',
      '- 本站由站长个人运营，不接入任何第三方统计分析或广告服务',
      '- 除本政策所述内容外，我们不会主动收集您的其他个人信息',
      '',
      '## 我们收集的信息',
      '',
      '**账户信息**：注册时您提供的用户名、密码（仅以单向加密哈希形式保存，无法还原出原文）、头像、个性签名、气泡颜色，以及您选择填写的 B 站 / 抖音主页链接。',
      '',
      '**访问统计**：本站会在侧栏公示累计访问次数。该统计仅为计数，不与任何个人身份信息关联。',
      '',
      '**上传内容**：您上传的文章、图片、音乐等文件。',
      '',
      '**会话信息**：为保持您的登录状态而生成的会话令牌。',
      '',
      '## 上传内容的公开性',
      '',
      '您在本站发布或上传的文章、图片、音乐、签名等内容对所有访客公开可见。请勿在公开内容中填写您的真实姓名、住址、电话号码等敏感个人信息。',
      '',
      '## Cookie 和本地存储',
      '',
      '我们的网站使用以下技术：',
      '',
      '- **本地存储（localStorage）**：用于保存您的登录状态与偏好设置（如日间 / 夜间模式）',
      '- 本站不使用第三方跟踪 Cookie',
      '',
      '您可以通过清除浏览器数据来删除上述信息；清除后需要重新登录，并重新选择偏好设置。',
      '',
      '## 信息的使用',
      '',
      '我们收集上述信息仅用于：',
      '',
      '- 提供并维持本站的各项功能（登录、签名板、评论、媒体库等）',
      '- 生成侧栏公示的站点访问统计',
      '- 保障站点安全，防止滥用行为',
      '',
      '我们不会将您的信息出售、共享或提供给任何第三方。',
      '',
      '## 数据的存储与安全',
      '',
      '您的数据存储于站长的服务器中。我们采取以下措施保护您的数据：',
      '',
      '- 密码仅以单向加密哈希形式存储，不可逆向查看',
      '- 使用 HTTPS 加密传输',
      '- 登录会话在您退出登录后立即失效',
      '- 定期备份站点数据',
      '',
      '## 您的权利',
      '',
      '您有权：',
      '',
      '- 随时在「我的主页」查看和修改您的个人资料',
      '- 要求站长删除您发布的内容',
      '- 要求站长删除您的账户及全部相关数据',
      '- 了解您的数据被存储的范围',
      '',
      '您可以通过下方的联系方式提出上述请求，我们会在收到后及时处理。',
      '',
      '## 联系我们',
      '',
      '如果您对本隐私政策有任何疑问或关注，请通过以下方式联系我们：',
      '',
      '- 通过本站签名板或「关于」页联系站长',
      '- 发送邮件至网站管理员',
      '',
      '## 儿童隐私',
      '',
      '我们的网站不专门针对 14 岁以下的儿童。我们不会故意收集 14 岁以下儿童的个人信息。',
      '',
      '## 隐私政策更新',
      '',
      '我们可能会不时更新本隐私政策。任何更改都会在此页面上发布，重大更改会通过网站公告通知用户。',
      '',
      '## 滥用与版权举报',
      '',
      '如果您发现网站内容存在滥用、侵权或其他违法违规行为，请通过以下方式联系我们：',
      '',
      '- 邮箱：moeku@foxmail.com',
      '',
      '我们将认真对待每一个举报，并在收到举报后及时处理相关问题。',
      '',
      '## 适用法律',
      '',
      '本隐私政策受中华人民共和国法律管辖。我们努力遵守适用的数据保护法律法规。',
      '',
      '本隐私政策旨在透明地说明我们的数据处理实践。我们建议您定期查看本政策以了解任何更新。'
    ].join('\n'),
    privacyUpdatedAt: '2026年9月', // 隐私政策「最后更新」显示文案
    thanks: '', // 特别感谢名单（Markdown，站长在【设置 → 站点设置】维护，对应 #/thanks 页面）
    privacyEnabled: true, // 是否在「关于」页显示隐私政策入口
    privacyContactEmail: 'moeku@foxmail.com', // 举报/联系邮箱
    icons: {}, // 图标自定义：{ avatar, favicon, home, posts, music, gallery, about, bilibili, douyin, admin } -> 图片URL
    createdAt: '2026-09-22', // 建站时间
    ownerName: 'D-6CF-X', // 签名板中心（站长）名字
    ownerSignature: '欢迎在我的签名板留下你的印记～', // 站长签名（≤100字）
    ownerColor: '#66ccff', // 站长气泡颜色
    ownerAvatar: '', // 站长头像（/uploads/avatar/ 文件 URL）
    defaultAvatar: '', // 默认头像：没自定义头像的成员都显示它（/uploads/ 图片 URL，空=显示名字首字母）
    autoPlay: false, // 访客进入网站自动播放背景音乐
    autoPlayId: '' // 自动播放优先曲目（媒体 id，空 = 列表第一首）
  },
  passwordHash: sha256('d6cfx123'), // 默认管理密码，请登录后在【设置】中修改！
  sessions: {},
  userSessions: {},
  users: [],
  stats: { visits: 0 },
  posts: [],
  media: [],
  folders: [], // 媒体文件夹：{ id, name, type: 'image'|'audio', sort }（media.folderId 指向它，0 = 未分类）
  comments: [],
  danmaku: [], // 首页弹幕墙：{ id, userId, username, color, avatar, isOwner, content(≤70字), fontSize, style, createdAt }
  nextId: 1,
  nextUserId: 1
};

let db;
/* 壁纸取景：单套参数清洗（缺项用默认值兜底） */
function normCropOne(o) {
  const def = { fit: 'cover', x: 50, y: 50, zoom: 100 };
  o = (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
  const num = function (v, lo, hi, dft) {
    const n = Number(v);
    return isFinite(n) ? Math.max(lo, Math.min(hi, Math.round(n))) : dft;
  };
  return {
    fit: ['cover', 'contain', 'fill'].indexOf(o.fit) !== -1 ? o.fit : def.fit,
    x: num(o.x, 0, 100, def.x),
    y: num(o.y, 0, 100, def.y),
    zoom: num(o.zoom, 100, 300, def.zoom)
  };
}
/* 归一出「日/夜 × 宽/窄」四套；老数据只有 desktop/mobile 两套 → 同时套给日间和夜间（迁移不丢配置） */
function migrateBgCrop(o) {
  o = (o && typeof o === 'object' && !Array.isArray(o)) ? o : {};
  const legacy = ((o.desktop || o.mobile) && !o.day && !o.night) ? o : null;
  const pick = function (mode, view) {
    const m = o[mode];
    if (m && typeof m === 'object' && m[view]) return normCropOne(m[view]);
    if (legacy) return normCropOne(legacy[view]);
    return normCropOne(null);
  };
  return {
    day: { desktop: pick('day', 'desktop'), mobile: pick('day', 'mobile') },
    night: { desktop: pick('night', 'desktop'), mobile: pick('night', 'mobile') }
  };
}
/* 合并写入：兼容新结构（day/night 各含 desktop/mobile）与老前端提交的老结构（同时套到日夜）；
   逐项清洗，非数字 / null / 空串一律忽略保留原值，越界值夹回合法区间 */
function mergeBgCrop(cur, src) {
  const FITS = ['cover', 'contain', 'fill'];
  const out = migrateBgCrop(cur);
  src = (src && typeof src === 'object' && !Array.isArray(src)) ? src : {};
  const legacy = ((src.desktop || src.mobile) && !src.day && !src.night) ? src : null;
  ['day', 'night'].forEach(function (mode) {
    ['desktop', 'mobile'].forEach(function (view) {
      const s2 = legacy ? legacy[view] : (src[mode] && typeof src[mode] === 'object' ? src[mode][view] : null);
      if (!s2 || typeof s2 !== 'object') return;
      const one = out[mode][view];
      if (FITS.indexOf(s2.fit) !== -1) one.fit = s2.fit;
      const clamp = function (v, lo, hi) {
        if (v === null || v === undefined || v === '' || typeof v === 'boolean') return null;
        const n = Number(v);
        if (!isFinite(n)) return null;
        return Math.max(lo, Math.min(hi, Math.round(n)));
      };
      [['x', 0, 100], ['y', 0, 100], ['zoom', 100, 300]].forEach(function (spec) {
        if (s2[spec[0]] === undefined) return;
        const n = clamp(s2[spec[0]], spec[1], spec[2]);
        if (n !== null) one[spec[0]] = n;
      });
    });
  });
  return out;
}

function loadDb() {
  try {
    db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    // 补齐缺失字段
    Object.keys(DEFAULT_DB).forEach(function (k) {
      if (db[k] === undefined) db[k] = DEFAULT_DB[k];
    });
    Object.keys(DEFAULT_DB.settings).forEach(function (k) {
      if (db.settings[k] === undefined) db.settings[k] = DEFAULT_DB.settings[k];
    });
    // 壁纸取景老结构（只有 desktop/mobile）迁移成 日/夜 × 宽/窄 四套
    db.settings.bgCrop = migrateBgCrop(db.settings.bgCrop);
    // 老数据补齐媒体字段：folderId=0（未分类）、hidden=false，保证接口返回结构一致
    (db.media || []).forEach(function (m) {
      if (m.folderId === undefined || m.folderId === null) m.folderId = 0;
      if (m.hidden === undefined) m.hidden = false;
    });
  } catch (e) {
    db = JSON.parse(JSON.stringify(DEFAULT_DB));
    saveDb();
  }
}
function saveDb() {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
}
function nextId() {
  return db.nextId++;
}
loadDb();

/* ---------------- 应用 ---------------- */
const app = express();

/* ---------------- 域名跳转（备案通过后：旧地址 → 正式域名） ----------------
   域名来源（优先级从高到低）：
   ① 环境变量 SITE_DOMAIN=luotianyi.click
   ② 站点目录下 data/site-domain.json  → { "domain": "luotianyi.click", "redirect": true }
      （data/ 不在部署包里，更新站点不会覆盖；在宝塔面板点重启也不会丢）
   开启后：域名 / www 域名 / 本机地址访问正常；IP:3000 等其它 Host → 302 跳到 https://域名 + 原路径
   关闭跳转：把 redirect 设为 false，或环境变量 DOMAIN_REDIRECT=off */
let SITE_DOMAIN = '', DOMAIN_REDIRECT = true;
try {
  const cfgFile = path.join(DATA_DIR, 'site-domain.json');
  if (fs.existsSync(cfgFile)) {
    const cfg = JSON.parse(fs.readFileSync(cfgFile, 'utf8')) || {};
    if (typeof cfg.domain === 'string') SITE_DOMAIN = cfg.domain;
    if (typeof cfg.redirect === 'boolean') DOMAIN_REDIRECT = cfg.redirect;
  }
} catch (e) { console.warn('  [域名配置] data/site-domain.json 解析失败，已忽略：' + e.message); }
if (process.env.SITE_DOMAIN) SITE_DOMAIN = process.env.SITE_DOMAIN;
if (String(process.env.DOMAIN_REDIRECT || '').toLowerCase() === 'off') DOMAIN_REDIRECT = false;
if (String(process.env.DOMAIN_REDIRECT || '').toLowerCase() === 'on') DOMAIN_REDIRECT = true;
SITE_DOMAIN = String(SITE_DOMAIN || '').trim()
  .replace(/^https?:\/\//i, '').replace(/\/.*$/, '').toLowerCase();
const SITE_ORIGIN = SITE_DOMAIN ? 'https://' + SITE_DOMAIN : '';
if (SITE_DOMAIN && DOMAIN_REDIRECT) {
  app.set('trust proxy', true);
  const HOST_ALLOW = [SITE_DOMAIN, 'www.' + SITE_DOMAIN, 'localhost', '127.0.0.1', '::1', '[::1]'];
  // 「天依的一封信」过渡页：从旧地址（IP:3000 等）点进来的页面请求，先播一段开信动画再送达新站；
  // 静态资源 / 接口等非页面请求仍走原来的 302，外链图片等不受影响。
  const LETTER_TARGET = '/#/post/82';   // 动画结束后送达的文章路径，想换就改这里
  let LETTER_PAGE = '';
  try { LETTER_PAGE = fs.readFileSync(path.join(ROOT, 'public', 'legacy-letter.html'), 'utf8'); }
  catch (e) { console.warn('  [过渡页] public/legacy-letter.html 读取失败，旧地址将直接 302：' + e.message); }
  app.use(function (req, res, next) {
    const host = String(req.headers.host || '').split(':')[0].trim().toLowerCase();
    if (!host || HOST_ALLOW.indexOf(host) !== -1) return next();
    const accept = String(req.headers.accept || '');
    if (LETTER_PAGE && req.path === '/' && accept.indexOf('text/html') !== -1) {
      res.set('Cache-Control', 'no-store');
      return res.type('html').send(LETTER_PAGE.split('__TARGET__').join(SITE_ORIGIN + LETTER_TARGET));
    }
    // 302（临时跳转）：换域名/暂停跳转都不需要访客清缓存
    return res.redirect(302, SITE_ORIGIN + req.originalUrl);
  });
}

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(ROOT, 'public'), { index: false }));
// index:false → 根路径 / 不在这里返回，交给文件末尾的 SEO 路由处理：
// 那里会把「站点简介 + 最新文章标题」内联进 HTML，让不执行 JS 的爬虫也能读到正文
app.use('/uploads', express.static(UPLOAD_DIR, { maxAge: '7d' }));
app.use('/assets', express.static(path.join(ROOT, 'assets')));

/* 文件上传配置 */
const IMAGE_EXT = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'];
const AUDIO_EXT = ['.mp3', '.flac', '.wav', '.ogg', '.m4a', '.aac'];
const VIDEO_EXT = ['.mp4', '.webm', '.ogv', '.mov', '.m4v'];
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const type = isVideo(file.originalname) ? 'video' : (isAudio(file.originalname) ? 'audio' : 'image');
    const dir = path.join(UPLOAD_DIR, type);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, Date.now() + '-' + crypto.randomBytes(4).toString('hex') + ext);
  }
});
function isAudio(name) {
  return AUDIO_EXT.indexOf(path.extname(name).toLowerCase()) !== -1;
}
function isVideo(name) {
  return VIDEO_EXT.indexOf(path.extname(name).toLowerCase()) !== -1;
}
const upload = multer({
  storage: storage,
  limits: { fileSize: 100 * 1024 * 1024 } // 单文件最大 100MB
});

/* 头像上传：仅图片、最大 5MB，存 uploads/avatar（圆形裁剪由前端完成） */
const AVATAR_DIR = path.join(UPLOAD_DIR, 'avatar');
const avatarStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    if (!fs.existsSync(AVATAR_DIR)) fs.mkdirSync(AVATAR_DIR, { recursive: true });
    cb(null, AVATAR_DIR);
  },
  filename: function (req, file, cb) {
    cb(null, 'avatar-' + Date.now() + '-' + crypto.randomBytes(4).toString('hex') + '.png');
  }
});
const avatarUpload = multer({
  storage: avatarStorage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: function (req, file, cb) { cb(null, /^image\//.test(file.mimetype || '')); }
});
// 删除磁盘上的头像文件（按 URL 反查路径，限制在 uploads 目录内防路径穿越）
function removeAvatarFile(url) {
  if (!url) return;
  const u = String(url);
  if (u.indexOf('/uploads/') !== 0) return;
  let rel;
  try { rel = path.normalize(decodeURIComponent(u.replace(/^\/uploads\//, ''))); } catch (e) { return; }
  const full = path.join(UPLOAD_DIR, rel);
  if (full.indexOf(UPLOAD_DIR + path.sep) === 0 && fs.existsSync(full)) {
    try { fs.unlinkSync(full); } catch (e) {}
  }
}
// 该 URL 是否仍被任何头像位引用（站长/默认/成员/图标）
function avatarUrlInUse(url) {
  if (!url) return false;
  if (db.settings.ownerAvatar === url) return true;
  if (db.settings.defaultAvatar === url) return true;
  const icons = db.settings.icons || {};
  for (const k in icons) if (icons[k] === url) return true;
  return db.users.some(function (u) { return u.avatar === url; });
}
// 只清理头像目录里的孤儿文件（uploads/image|audio 属于媒体库，绝不动）
function removeAvatarIfOrphan(url) {
  if (!url || String(url).indexOf('/uploads/avatar/') !== 0) return;
  if (!avatarUrlInUse(url)) removeAvatarFile(url);
}

/* ---------------- 鉴权 ---------------- */
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (token && db.sessions[token]) {
    req.admin = true;
    next();
  } else {
    res.status(401).json({ error: '未登录或登录已过期' });
  }
}

// 判断请求是否带有效的站长会话（用于同一接口对站长/访客返回不同数据，如隐藏素材、定时文章）
function isAdminReq(req) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  return !!(token && db.sessions[token]);
}

// 普通用户鉴权
function userAuth(req, res, next) {
  const token = (req.headers['x-user-token'] || '').replace(/^Bearer\s+/i, '');
  const sess = token && db.userSessions[token];
  if (sess) {
    const u = db.users.filter(function (x) { return x.id === sess.userId; })[0];
    if (u) { req.user = u; req.userToken = token; return next(); }
  }
  res.status(401).json({ error: '请先登录账号' });
}

/* ---------------- API ---------------- */
// 登录防暴力破解：同一 IP 短时间内多次失败则临时封禁
const loginFails = {}; // ip -> { count, until, blocked }
function loginGuard(req, res, next) {
  const ip = req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : (req.socket && req.socket.remoteAddress) || 'unknown';
  const now = Date.now();
  const rec = loginFails[ip];
  if (rec && rec.blocked && now < rec.until) {
    const left = Math.ceil((rec.until - now) / 60000);
    return res.status(429).json({ error: '尝试次数过多，请 ' + left + ' 分钟后再试' });
  }
  if (rec && rec.blocked && now >= rec.until) delete loginFails[ip];
  req._loginIp = ip;
  next();
}
function recordLoginFail(req) {
  const ip = req._loginIp;
  if (!ip) return;
  const rec = loginFails[ip] || { count: 0 };
  rec.count++;
  // 10 分钟内失败 6 次 → 封禁 15 分钟
  if (rec.count >= 6) { rec.blocked = true; rec.until = Date.now() + 15 * 60 * 1000; rec.count = 0; }
  loginFails[ip] = rec;
}
function clearLoginFails(req) {
  if (req._loginIp) delete loginFails[req._loginIp];
}

// 登录
app.post('/api/login', loginGuard, function (req, res) {
  const pw = req.body.password || '';
  if (sha256(pw) === db.passwordHash) {
    clearLoginFails(req);
    const token = crypto.randomBytes(24).toString('hex');
    db.sessions[token] = { at: Date.now() };
    // 只保留最近 10 个会话
    const keys = Object.keys(db.sessions);
    if (keys.length > 10) keys.slice(0, keys.length - 10).forEach(function (k) { delete db.sessions[k]; });
    saveDb();
    res.json({ ok: true, token: token });
  } else {
    recordLoginFail(req);
    res.status(403).json({ error: '密码错误' });
  }
});

// 获取设置（公开）
app.get('/api/settings', function (req, res) {
  res.json(db.settings);
});

// 修改设置（管理员）
app.put('/api/settings', auth, function (req, res) {
  const s = db.settings;
  const b = req.body || {};
  ['siteTitle', 'subtitle', 'backgroundUrl', 'backgroundUrlDay', 'backgroundUrlNight', 'backgroundVideoDay', 'backgroundVideoNight', 'bilibiliUrl', 'douyinUrl', 'about', 'thanks', 'notice', 'noticeLink', 'createdAt', 'ownerName', 'ownerSignature', 'ownerColor', 'privacy', 'privacyUpdatedAt', 'privacyContactEmail'].forEach(function (k) {
    if (b[k] !== undefined) s[k] = String(b[k]).slice(0, 20000);
  });
  // 公告跳转只允许是文章 id（数字）或空串，其它一律清空
  if (s.noticeLink && !/^\d+$/.test(s.noticeLink)) s.noticeLink = '';
  // 是否显示隐私政策入口（布尔，单独处理避免被 String() 变成 "false" 字符串）
  if (b.privacyEnabled !== undefined) s.privacyEnabled = (b.privacyEnabled === true || b.privacyEnabled === 'true');
  // 默认头像（换/清时顺手清掉不再被引用的旧头像文件）
  if (b.defaultAvatar !== undefined) {
    const nv = String(b.defaultAvatar).slice(0, 500);
    const oldAv = s.defaultAvatar;
    s.defaultAvatar = nv;
    if (oldAv && oldAv !== nv) removeAvatarIfOrphan(oldAv);
  }
  if (b.autoPlay !== undefined) s.autoPlay = (b.autoPlay === true || b.autoPlay === 'true');
  if (b.unreadGlow !== undefined) s.unreadGlow = (b.unreadGlow === true || b.unreadGlow === 'true');
  // 自动播放优先曲目（媒体 id，空 = 列表第一首）
  if (b.autoPlayId !== undefined) s.autoPlayId = String(b.autoPlayId).slice(0, 50);
  // 壁纸裁剪（日/夜 × 宽/窄 四套，逐项清洗；老结构自动迁移/兼容）
  if (b.bgCrop && typeof b.bgCrop === 'object' && !Array.isArray(b.bgCrop)) {
    s.bgCrop = mergeBgCrop(s.bgCrop, b.bgCrop);
  }
  // 图标自定义（白名单键，值为图片URL或空字符串表示恢复默认）
  if (b.icons && typeof b.icons === 'object' && !Array.isArray(b.icons)) {
    var ICON_KEYS = ['avatar', 'favicon', 'home', 'posts', 'music', 'gallery', 'about', 'bilibili', 'douyin', 'admin'];
    if (!s.icons) s.icons = {};
    ICON_KEYS.forEach(function (k) {
      if (b.icons[k] !== undefined) {
        if (b.icons[k] === null || b.icons[k] === '') delete s.icons[k];
        else s.icons[k] = String(b.icons[k]).slice(0, 500);
      }
    });
  }
  // 全站文案覆盖（前端 SITE_TEXTS 定义的键 → 自定义文字；空值/非字符串键一律剔除，留空即回落默认）
  if (b.texts && typeof b.texts === 'object' && !Array.isArray(b.texts)) {
    const clean = {};
    Object.keys(b.texts).slice(0, 120).forEach(function (k) {
      if (!/^[a-z0-9_]{1,40}$/.test(k)) return;
      const v = b.texts[k];
      if (typeof v !== 'string') return;
      const t = v.trim();
      if (t) clean[k] = t.slice(0, 300);
    });
    s.texts = clean;
  }
  saveDb();
  res.json({ ok: true, settings: s });
});

// 修改密码（管理员）
app.post('/api/change-password', auth, function (req, res) {
  const oldPw = req.body.oldPassword || '';
  const newPw = req.body.newPassword || '';
  if (String(newPw).length < 6) return res.status(400).json({ error: '新密码至少 6 位' });
  if (sha256(oldPw) !== db.passwordHash) return res.status(403).json({ error: '旧密码错误' });
  db.passwordHash = sha256(newPw);
  db.sessions = {}; // 所有会话失效，需要重新登录
  saveDb();
  res.json({ ok: true });
});

/* ---------------- 访问统计 ---------------- */
// 站点公开数据：访问次数 + 建站时间
app.get('/api/stats', function (req, res) {
  res.json({ visits: db.stats.visits, createdAt: db.settings.createdAt });
});
// 记一次访问
app.post('/api/visit', function (req, res) {
  db.stats.visits++;
  saveDb();
  res.json({ visits: db.stats.visits });
});
// 访客清零（仅站长）
app.post('/api/reset-visits', auth, function (req, res) {
  db.stats.visits = 0;
  saveDb();
  res.json({ ok: true, visits: 0 });
});

/* ---------------- 用户系统（注册/登录/资料） ---------------- */
const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;
function publicUser(u) {
  return {
    id: u.id, username: u.username, color: u.color, signature: u.signature,
    avatar: u.avatar || '',
    bilibiliUrl: u.bilibiliUrl, douyinUrl: u.douyinUrl, createdAt: u.createdAt, isOwner: false
  };
}
// 站长虚拟账号：资料存在站点设置里，管理员登录即自动生效
function ownerVirtual() {
  const s = db.settings;
  let ts = Date.parse(s.createdAt);
  if (isNaN(ts)) ts = Date.now();
  return {
    id: 'owner', isOwner: true,
    username: s.ownerName || 'D-6CF-X',
    color: s.ownerColor || '#66ccff',
    signature: s.ownerSignature || '',
    avatar: s.ownerAvatar || '',
    bilibiliUrl: s.bilibiliUrl || '',
    douyinUrl: s.douyinUrl || '',
    createdAt: ts
  };
}
// 解析请求身份：普通用户 token 优先，其次管理员（视为站长）
function resolveSession(req) {
  const ut = (req.headers['x-user-token'] || '').replace(/^Bearer\s+/i, '');
  const usess = ut && db.userSessions[ut];
  if (usess) {
    const u = db.users.filter(function (x) { return x.id === usess.userId; })[0];
    if (u) return { kind: 'user', user: u };
  }
  const at = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (at && db.sessions[at]) return { kind: 'admin' };
  return null;
}

// 注册
app.post('/api/register', loginGuard, function (req, res) {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  if (username.length < 2 || username.length > 20) return res.status(400).json({ error: '用户名需要 2~20 个字符' });
  if (password.length < 6) return res.status(400).json({ error: '密码至少 6 位' });
  const exists = db.users.some(function (u) { return u.username === username; });
  if (exists) return res.status(400).json({ error: '这个用户名已经被签过啦，换一个吧' });
  const PALETTE = ['#66ccff', '#7fd8c4', '#ffb3c6', '#ffd88a', '#b39ddb', '#90caf9', '#a5d6a7', '#ffab91', '#80deea', '#e6ee9c', '#f48fb1', '#9fa8da'];
  const user = {
    id: db.nextUserId++,
    username: username,
    passwordHash: sha256(password),
    color: PALETTE[Math.floor(Math.random() * PALETTE.length)],
    signature: '我来到了 D-6CF-X 的小站！',
    bilibiliUrl: '',
    douyinUrl: '',
    createdAt: Date.now()
  };
  db.users.push(user);
  const token = crypto.randomBytes(24).toString('hex');
  db.userSessions[token] = { userId: user.id, at: Date.now() };
  saveDb();
  res.json({ ok: true, token: token, user: publicUser(user) });
});

// 用户登录
app.post('/api/user-login', loginGuard, function (req, res) {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const u = db.users.filter(function (x) { return x.username === username; })[0];
  if (!u || u.passwordHash !== sha256(password)) { recordLoginFail(req); return res.status(403).json({ error: '用户名或密码错误' }); }
  clearLoginFails(req);
  const token = crypto.randomBytes(24).toString('hex');
  db.userSessions[token] = { userId: u.id, at: Date.now() };
  saveDb();
  res.json({ ok: true, token: token, user: publicUser(u) });
});

// 当前用户信息（管理员 token 视为站长账号）
app.get('/api/me', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.status(401).json({ error: '请先登录账号' });
  res.json(r.kind === 'admin' ? ownerVirtual() : publicUser(r.user));
});

// 修改自己的资料（用户名/签名/颜色/链接/密码；站长改的是站点设置）
app.put('/api/me', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.status(401).json({ error: '请先登录账号' });
  const b = req.body || {};
  if (r.kind === 'admin') {
    const s = db.settings;
    if (b.username !== undefined) {
      const nu = String(b.username).trim();
      if (nu.length < 2 || nu.length > 20) return res.status(400).json({ error: '用户名需要 2~20 个字符' });
      s.ownerName = nu;
    }
    if (b.signature !== undefined) s.ownerSignature = String(b.signature).slice(0, 100);
    if (b.color !== undefined) {
      if (!HEX_COLOR.test(b.color)) return res.status(400).json({ error: '颜色格式不对' });
      s.ownerColor = b.color;
    }
    if (b.bilibiliUrl !== undefined) s.bilibiliUrl = String(b.bilibiliUrl).trim().slice(0, 300);
    if (b.douyinUrl !== undefined) s.douyinUrl = String(b.douyinUrl).trim().slice(0, 300);
    saveDb();
    return res.json({ ok: true, user: ownerVirtual() });
  }
  const u = r.user;
  if (b.username !== undefined) {
    const nu = String(b.username).trim();
    if (nu.length < 2 || nu.length > 20) return res.status(400).json({ error: '用户名需要 2~20 个字符' });
    if (db.users.some(function (x) { return x.id !== u.id && x.username === nu; })) return res.status(400).json({ error: '这个用户名已经被别人用啦' });
    u.username = nu;
  }
  if (b.signature !== undefined) u.signature = String(b.signature).slice(0, 100);
  if (b.color !== undefined) {
    if (!HEX_COLOR.test(b.color)) return res.status(400).json({ error: '颜色格式不对' });
    u.color = b.color;
  }
  if (b.bilibiliUrl !== undefined) u.bilibiliUrl = String(b.bilibiliUrl).trim().slice(0, 300);
  if (b.douyinUrl !== undefined) u.douyinUrl = String(b.douyinUrl).trim().slice(0, 300);
  if (b.oldPassword !== undefined && b.newPassword) {
    if (u.passwordHash !== sha256(String(b.oldPassword))) return res.status(403).json({ error: '旧密码错误' });
    if (String(b.newPassword).length < 6) return res.status(400).json({ error: '新密码至少 6 位' });
    u.passwordHash = sha256(String(b.newPassword));
  }
  saveDb();
  res.json({ ok: true, user: publicUser(u) });
});

// 头像上传（multipart：file + 可选 userId）
// 不带 userId：改自己的头像（成员登录改自己，站长登录改站长气泡）
// 带 userId：仅站长可用，可改任意成员（userId=owner 即站长自己，userId=default 即全站默认头像）
app.post('/api/avatar', function (req, res, next) {
  avatarUpload.single('file')(req, res, function (err) {
    if (err && err.code === 'LIMIT_FILE_SIZE') return res.status(400).json({ error: '图片太大了，不能超过 5MB' });
    if (err) return res.status(400).json({ error: err.message || '上传失败' });
    next();
  });
}, function (req, res) {
  if (!req.file) return res.status(400).json({ error: '请选择一张图片（仅支持图片文件）' });
  const r = resolveSession(req);
  if (!r) {
    removeAvatarFile('/uploads/avatar/' + req.file.filename); // 未登录不落盘
    return res.status(401).json({ error: '请先登录账号' });
  }
  const url = '/uploads/avatar/' + req.file.filename;
  const targetId = (req.body && req.body.userId !== undefined && req.body.userId !== null && String(req.body.userId) !== '')
    ? String(req.body.userId) : null;
  let updated;
  if (targetId) {
    if (r.kind !== 'admin') {
      removeAvatarFile(url);
      return res.status(403).json({ error: '只有站长能改别人的头像' });
    }
    if (targetId === 'owner') {
      removeAvatarFile(db.settings.ownerAvatar);
      db.settings.ownerAvatar = url;
      updated = ownerVirtual();
    } else if (targetId === 'default') {
      // 全站默认头像：没自定义头像的成员都会显示它
      const oldDef = db.settings.defaultAvatar;
      db.settings.defaultAvatar = url;
      if (oldDef && oldDef !== url) removeAvatarIfOrphan(oldDef);
      updated = null;
    } else {
      const u = db.users.filter(function (x) { return String(x.id) === targetId; })[0];
      if (!u) { removeAvatarFile(url); return res.status(404).json({ error: '用户不存在' }); }
      removeAvatarFile(u.avatar);
      u.avatar = url;
      updated = publicUser(u);
    }
  } else {
    if (r.kind === 'admin') {
      removeAvatarFile(db.settings.ownerAvatar);
      db.settings.ownerAvatar = url;
      updated = ownerVirtual();
    } else {
      removeAvatarFile(r.user.avatar);
      r.user.avatar = url;
      updated = publicUser(r.user);
    }
  }
  saveDb();
  res.json({ ok: true, avatar: url, defaultAvatar: db.settings.defaultAvatar || '', user: updated });
});

// 退出登录
app.post('/api/user-logout', userAuth, function (req, res) {
  delete db.userSessions[req.userToken];
  saveDb();
  res.json({ ok: true });
});

// 站长退出登录（作废当前会话 token）
app.post('/api/logout', auth, function (req, res) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (db.sessions[token]) { delete db.sessions[token]; saveDb(); }
  res.json({ ok: true });
});

// 用户列表（公开，签名板用）
app.get('/api/users', function (req, res) {
  res.json(db.users.map(publicUser));
});

// 用户公开主页（站长 id 为 owner）
app.get('/api/users/:id', function (req, res) {
  if (req.params.id === 'owner') return res.json(ownerVirtual());
  const u = db.users.filter(function (x) { return String(x.id) === req.params.id; })[0];
  if (!u) return res.status(404).json({ error: '用户不存在' });
  res.json(publicUser(u));
});

// 删除用户（管理员）：连带清理评论、弹幕、登录会话、头像文件，不留残留数据
app.delete('/api/users/:id', auth, function (req, res) {
  const id = String(req.params.id);
  if (id === 'owner') return res.status(400).json({ error: '站长账号不可删除' });
  const victim = db.users.filter(function (x) { return String(x.id) === id; })[0];
  if (!victim) return res.status(404).json({ error: '用户不存在' });
  db.users = db.users.filter(function (x) { return String(x.id) !== id; });
  // 0) 清掉 TA 的头像文件
  removeAvatarFile(victim.avatar);
  // 1) 清掉 TA 的全部评论
  const cBefore = db.comments.length;
  db.comments = db.comments.filter(function (c) { return String(c.userId) !== id; });
  // 1.5) 清掉 TA 的弹幕
  db.danmaku = (db.danmaku || []).filter(function (d) { return String(d.userId) !== id; });
  // 2) 注销 TA 的全部登录会话
  Object.keys(db.userSessions).forEach(function (t) {
    if (String(db.userSessions[t].userId) === id) delete db.userSessions[t];
  });
  saveDb();
  res.json({ ok: true, removedComments: cBefore - db.comments.length });
});

/* ---------------- 文章：定时发布 / 置顶 ---------------- */
// 文章是否已到发布时间（publishAt 为空或已过 = 已发布）
function isPostLive(p, now) {
  return !p.publishAt || Number(p.publishAt) <= (now || Date.now());
}
// 定时文章到点上线时，若当初勾了「替换当前置顶」，此时才真正抢占置顶位（无需定时任务，读接口顺带结算）
function settleScheduled() {
  const now = Date.now();
  let changed = false;
  db.posts.forEach(function (p) {
    if (p.replacePinPending && isPostLive(p, now)) {
      db.posts.forEach(function (o) { if (o !== p) o.pinned = false; });
      p.pinned = true;
      p.replacePinPending = false;
      changed = true;
    }
  });
  if (changed) saveDb();
}
// 写入置顶状态：立即发布时当场替换，定时文章则等上线时替换
function applyPin(post, pinned, replacePin, publishAt) {
  post.pinned = !!pinned;
  if (!post.pinned) { post.replacePinPending = false; return; }
  if (publishAt && Number(publishAt) > Date.now()) {
    post.replacePinPending = !!replacePin;
  } else if (replacePin) {
    db.posts.forEach(function (o) { if (o !== post) o.pinned = false; });
    post.replacePinPending = false;
  }
}
// 解析前端传来的发布时间：仅未来时间算定时，否则视为立即发布
function parsePublishAt(v) {
  const t = Number(v);
  return (t && t > Date.now()) ? t : 0;
}
// 定时文章未到发布时间时，对访客展示的提示文案（站长后台「✍️ 全站文案」可改，留空回落默认）
function schedPendingText() {
  const tx = db.settings.texts || {};
  const v = (typeof tx.sched_pending === 'string') ? tx.sched_pending.trim() : '';
  return v || '文章不存在';
}
// 该文章是否属于「存在但未到发布时间、且请求者不是站长」——决定 404 用哪种文案
function isSchedHidden(req, id) {
  const p = db.posts.filter(function (x) { return String(x.id) === String(id); })[0];
  return !!p && !isPostLive(p) && !isAdminReq(req);
}

// 文章列表（公开）
app.get('/api/posts', function (req, res) {
  settleScheduled();
  const isAdmin = isAdminReq(req);
  const now = Date.now();
  const list = db.posts.filter(function (p) { return isAdmin || isPostLive(p, now); }).slice().sort(function (a, b) {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return b.updatedAt - a.updatedAt;
  });
  const counts = {};
  db.comments.forEach(function (c) {
    const k = String(c.postId);
    counts[k] = (counts[k] || 0) + 1;
  });
  res.json(list.map(function (p) {
    return Object.assign({}, p, { commentCount: counts[String(p.id)] || 0 });
  }));
});

// 文章详情（公开）—— 定时文章在发布前只有站长能看到（访客看到的提示文案可配置）
app.get('/api/posts/:id', function (req, res) {
  settleScheduled();
  const post = findLivePost(req, req.params.id);
  if (!post) return res.status(404).json({ error: isSchedHidden(req, req.params.id) ? schedPendingText() : '文章不存在' });
  res.json(post);
});

// 新建文章（管理员）
app.post('/api/posts', auth, function (req, res) {
  const b = req.body || {};
  if (!b.title || !String(b.title).trim()) return res.status(400).json({ error: '标题不能为空' });
  const now = Date.now();
  const publishAt = parsePublishAt(b.publishAt);
  const post = {
    id: nextId(),
    title: String(b.title).trim().slice(0, 200),
    content: String(b.content || ''),
    pinned: false,
    publishAt: publishAt,
    replacePinPending: false,
    createdAt: now,
    updatedAt: now
  };
  applyPin(post, b.pinned, b.replacePin, publishAt);
  db.posts.push(post);
  saveDb();
  res.json({ ok: true, post: post });
});

// 修改文章（管理员）
app.put('/api/posts/:id', auth, function (req, res) {
  const post = db.posts.filter(function (p) { return String(p.id) === req.params.id; })[0];
  if (!post) return res.status(404).json({ error: '文章不存在' });
  const b = req.body || {};
  if (b.title !== undefined) post.title = String(b.title).trim().slice(0, 200) || post.title;
  if (b.content !== undefined) post.content = String(b.content);
  if (b.publishAt !== undefined) post.publishAt = parsePublishAt(b.publishAt);
  if (b.pinned !== undefined || b.replacePin !== undefined) {
    applyPin(post, b.pinned !== undefined ? b.pinned : post.pinned, b.replacePin, post.publishAt);
  }
  post.updatedAt = Date.now();
  saveDb();
  res.json({ ok: true, post: post });
});

// 删除文章（管理员）
app.delete('/api/posts/:id', auth, function (req, res) {
  const before = db.posts.length;
  db.posts = db.posts.filter(function (p) { return String(p.id) !== req.params.id; });
  if (db.posts.length === before) return res.status(404).json({ error: '文章不存在' });
  // 连带删除这篇的评论
  db.comments = db.comments.filter(function (c) { return String(c.postId) !== req.params.id; });
  saveDb();
  res.json({ ok: true });
});

/* ---------------- 文章评论 ---------------- */
// 定时文章发布前，评论同样对访客不可见/不可发
function findLivePost(req, id) {
  const post = db.posts.filter(function (p) { return String(p.id) === String(id); })[0];
  if (!post) return null;
  if (!isPostLive(post) && !isAdminReq(req)) return null;
  return post;
}
// 评论列表（公开）
app.get('/api/posts/:id/comments', function (req, res) {
  if (!findLivePost(req, req.params.id)) return res.status(404).json({ error: isSchedHidden(req, req.params.id) ? schedPendingText() : '文章不存在' });
  const list = db.comments.filter(function (c) { return String(c.postId) === req.params.id; })
    .sort(function (a, b) { return a.createdAt - b.createdAt; });
  res.json(list);
});

// 发表评论（成员账号或站长登录后可用）
app.post('/api/posts/:id/comments', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.status(401).json({ error: '登录后才能评论哦' });
  const post = findLivePost(req, req.params.id);
  if (!post) return res.status(404).json({ error: isSchedHidden(req, req.params.id) ? schedPendingText() : '文章不存在' });
  const text = String((req.body && req.body.content) || '').trim();
  if (!text) return res.status(400).json({ error: '先写点什么再发吧～' });
  if (text.length > 500) return res.status(400).json({ error: '评论最多 500 字' });
  const me = r.kind === 'admin' ? ownerVirtual() : publicUser(r.user);
  const c = {
    id: nextId(),
    postId: post.id,
    userId: me.id,
    username: me.username,
    color: me.color || '#66ccff',
    avatar: me.avatar || '',
    isOwner: !!me.isOwner,
    content: text,
    createdAt: Date.now()
  };
  db.comments.push(c);
  saveDb();
  res.json({ ok: true, comment: c });
});

// 删除评论（站长可删任意；成员只能删自己的）
app.delete('/api/comments/:id', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.status(401).json({ error: '请先登录' });
  const idx = db.comments.map(function (c) { return String(c.id); }).indexOf(String(req.params.id));
  if (idx === -1) return res.status(404).json({ error: '评论不存在' });
  const c = db.comments[idx];
  const mine = (r.kind === 'user' && String(c.userId) === String(r.user.id));
  if (r.kind !== 'admin' && !mine) return res.status(403).json({ error: '只能删除自己的评论' });
  db.comments.splice(idx, 1);
  saveDb();
  res.json({ ok: true });
});

/* ---------------- 首页弹幕墙 ---------------- */
// 字号 / 样式白名单：前端下拉只提供这些选项，接口同样只认这些值
const DM_SIZES = [14, 18, 24, 32];
const DM_STYLES = ['default', 'blue', 'teal', 'pink', 'gold', 'glow', 'outline', 'rainbow', 'neon', 'bubble'];

// 弹幕列表（公开）：按发送时间排序
app.get('/api/danmaku', function (req, res) {
  res.json((db.danmaku || []).slice().sort(function (a, b) { return a.createdAt - b.createdAt; }));
});

// 发送弹幕（成员账号或站长登录后可用）：每人保留一条，重新发送即替换自己的那条
app.post('/api/danmaku', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.status(401).json({ error: '登录后才能发弹幕哦' });
  const b = req.body || {};
  const text = String(b.content || '').trim();
  if (!text) return res.status(400).json({ error: '先写点什么再发吧～' });
  if (text.length > 70) return res.status(400).json({ error: '弹幕最多 70 字' });
  const fontSize = DM_SIZES.indexOf(Number(b.fontSize)) !== -1 ? Number(b.fontSize) : 18;
  const style = DM_STYLES.indexOf(b.style) !== -1 ? b.style : 'default';
  const me = r.kind === 'admin' ? ownerVirtual() : publicUser(r.user);
  db.danmaku = (db.danmaku || []).filter(function (d) { return String(d.userId) !== String(me.id); });
  const d = {
    id: nextId(),
    userId: me.id,
    username: me.username,
    color: me.color || '#66ccff',
    avatar: me.avatar || '',
    isOwner: !!me.isOwner,
    content: text,
    fontSize: fontSize,
    style: style,
    createdAt: Date.now()
  };
  db.danmaku.push(d);
  saveDb();
  res.json({ ok: true, danmaku: d, mine: true });
});

// 我当前的弹幕（用于回显，未登录返回 null）
app.get('/api/danmaku/mine', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.json({ danmaku: null });
  const uid = r.kind === 'admin' ? 'owner' : String(r.user.id);
  const mine = (db.danmaku || []).filter(function (d) { return String(d.userId) === uid; })
    .sort(function (a, b) { return b.createdAt - a.createdAt; })[0] || null;
  res.json({ danmaku: mine });
});

// 删除弹幕（站长可删任意；成员只能删自己的）
app.delete('/api/danmaku/:id', function (req, res) {
  const r = resolveSession(req);
  if (!r) return res.status(401).json({ error: '请先登录' });
  const idx = (db.danmaku || []).map(function (d) { return String(d.id); }).indexOf(String(req.params.id));
  if (idx === -1) return res.status(404).json({ error: '弹幕不存在' });
  const d = db.danmaku[idx];
  const mine = (r.kind === 'user' && String(d.userId) === String(r.user.id));
  if (r.kind !== 'admin' && !mine) return res.status(403).json({ error: '只能删除自己的弹幕' });
  db.danmaku.splice(idx, 1);
  saveDb();
  res.json({ ok: true });
});

/* ---------------- 用户管理（仅站长） ---------------- */
// 用户列表（站长虚拟账号置顶，标记为不可删除）
app.get('/api/admin/users', auth, function (req, res) {
  const cnt = {};
  db.comments.forEach(function (c) {
    const k = String(c.userId);
    cnt[k] = (cnt[k] || 0) + 1;
  });
  const o = ownerVirtual();
  const list = db.users.map(function (u) {
    return {
      id: u.id,
      username: u.username,
      color: u.color,
      signature: u.signature,
      avatar: u.avatar || '',
      bilibiliUrl: u.bilibiliUrl,
      douyinUrl: u.douyinUrl,
      createdAt: u.createdAt,
      commentCount: cnt[String(u.id)] || 0,
      isOwner: false
    };
  }).sort(function (a, b) { return a.createdAt - b.createdAt; });
  list.unshift({
    id: 'owner',
    username: o.username,
    color: o.color,
    signature: o.signature,
    avatar: o.avatar || '',
    bilibiliUrl: o.bilibiliUrl,
    douyinUrl: o.douyinUrl,
    createdAt: o.createdAt,
    commentCount: cnt['owner'] || 0,
    isOwner: true
  });
  res.json(list);
});

// 媒体列表（管理员）
/* ---------------- 媒体文件夹（音乐/图库分类） ---------------- */
// 文件夹列表（公开）：访客浏览音乐/图库时按文件夹分组，只需要名字和类型
app.get('/api/folders', function (req, res) {
  const list = db.folders.slice().sort(function (a, b) {
    if (a.type !== b.type) return a.type === 'image' ? -1 : 1;
    return (a.sort || 0) - (b.sort || 0);
  });
  res.json(list);
});

function findFolder(id) {
  return db.folders.filter(function (f) { return String(f.id) === String(id); })[0];
}

// 新建文件夹（管理员）
app.post('/api/folders', auth, function (req, res) {
  const b = req.body || {};
  const name = String(b.name || '').trim().slice(0, 30);
  const type = b.type === 'audio' ? 'audio' : 'image';
  if (!name) return res.status(400).json({ error: '文件夹名不能为空' });
  if (db.folders.some(function (f) { return f.type === type && f.name === name; })) {
    return res.status(400).json({ error: '已存在同名文件夹' });
  }
  const maxSort = db.folders.filter(function (f) { return f.type === type; })
    .reduce(function (mx, f) { return Math.max(mx, f.sort || 0); }, 0);
  const folder = { id: nextId(), name: name, type: type, sort: maxSort + 1 };
  db.folders.push(folder);
  saveDb();
  res.json({ ok: true, folder: folder });
});

// 重命名文件夹（管理员）
app.put('/api/folders/:id', auth, function (req, res) {
  const f = findFolder(req.params.id);
  if (!f) return res.status(404).json({ error: '文件夹不存在' });
  const b = req.body || {};
  if (b.name !== undefined) {
    const name = String(b.name).trim().slice(0, 30);
    if (!name) return res.status(400).json({ error: '文件夹名不能为空' });
    if (db.folders.some(function (x) { return x !== f && x.type === f.type && x.name === name; })) {
      return res.status(400).json({ error: '已存在同名文件夹' });
    }
    f.name = name;
  }
  saveDb();
  res.json({ ok: true, folder: f });
});

// 删除文件夹（管理员）：里面的文件自动回到「未分类」，文件本身不删
app.delete('/api/folders/:id', auth, function (req, res) {
  const f = findFolder(req.params.id);
  if (!f) return res.status(404).json({ error: '文件夹不存在' });
  let moved = 0;
  db.media.forEach(function (m) {
    if (String(m.folderId) === String(f.id)) { m.folderId = 0; moved++; }
  });
  db.folders = db.folders.filter(function (x) { return x !== f; });
  saveDb();
  res.json({ ok: true, movedToUnsorted: moved });
});

// 归类：把若干文件移进文件夹（管理员）——folderId = 0 表示移回未分类
app.post('/api/media/folder', auth, function (req, res) {
  const b = req.body || {};
  const ids = Array.isArray(b.ids) ? b.ids.map(String) : [];
  if (!ids.length) return res.status(400).json({ error: '请先选择文件' });
  const fid = Number(b.folderId) || 0;
  let folder = null;
  if (fid) {
    folder = findFolder(fid);
    if (!folder) return res.status(404).json({ error: '文件夹不存在' });
  }
  let moved = 0, skipped = 0;
  db.media.forEach(function (m) {
    if (ids.indexOf(String(m.id)) === -1) return;
    // 图片文件夹只收图片、音频文件夹只收音频，避免混入
    if (folder && folder.type !== m.type) { skipped++; return; }
    m.folderId = fid;
    moved++;
  });
  saveDb();
  res.json({ ok: true, moved: moved, skipped: skipped });
});

// 媒体列表（公开）：访客也能浏览音乐页 / 图库页（上传、删除仍需站长）
// 按 sort 字段升序返回（站长可在媒体库调整顺序）
// 隐藏素材（hidden=true）只有站长能看到：不出现在图库/音乐页/访客的媒体列表里
app.get('/api/media', function (req, res) {
  const isAdmin = isAdminReq(req);
  var list = db.media.filter(function (m) { return isAdmin || !m.hidden; }).sort(function (a, b) {
    var sa = (a.sort !== undefined && a.sort !== null) ? a.sort : (a.uploadedAt || 0);
    var sb = (b.sort !== undefined && b.sort !== null) ? b.sort : (b.uploadedAt || 0);
    return sa - sb;
  });
  res.json(list);
});

// 上传（管理员）—— 音频、图片
// multer 按 latin1 解析文件名，中文会乱码，这里转回 UTF-8
function fixFileName(name) {
  try { return Buffer.from(String(name), 'latin1').toString('utf8'); } catch (e) { return name; }
}
app.post('/api/upload', auth, upload.single('file'), function (req, res) {
  if (!req.file) return res.status(400).json({ error: '没有收到文件' });
  const origName = fixFileName(req.file.originalname);
  const ext = path.extname(origName).toLowerCase();
  const type = isVideo(origName) ? 'video' : (isAudio(origName) ? 'audio' : 'image');
  if (IMAGE_EXT.indexOf(ext) === -1 && AUDIO_EXT.indexOf(ext) === -1 && VIDEO_EXT.indexOf(ext) === -1) {
    try { fs.unlinkSync(req.file.path); } catch (e) {}
    return res.status(400).json({ error: '不支持的文件类型：' + ext });
  }
  const maxSort = db.media.reduce(function (mx, m) { return Math.max(mx, (m.sort || 0)); }, 0);
  // 隐藏素材：只在站长媒体库里可见，可用于文章配图，但访客在图库/音乐页看不到
  const hidden = ['1', 'true', 'yes', 'on'].indexOf(String((req.body || {}).hidden || '').toLowerCase()) !== -1;
  // 上传时可直接指定归类文件夹（类型不匹配则当作未分类）
  let folderId = Number((req.body || {}).folderId) || 0;
  if (folderId) {
    const f = findFolder(folderId);
    if (!f || f.type !== type) folderId = 0;
  }
  const item = {
    id: nextId(),
    type: type,
    filename: req.file.filename,
    originalName: origName,
    url: '/uploads/' + type + '/' + req.file.filename,
    size: req.file.size,
    ext: ext,
    sort: maxSort + 1,
    hidden: hidden,
    folderId: folderId,
    uploadedAt: Date.now()
  };
  db.media.push(item);
  saveDb();
  res.json({ ok: true, media: item });
});

// 设置/取消「隐藏素材」（管理员）：隐藏后不出现在图库/音乐页和访客的媒体列表，仅站长媒体库可见
app.post('/api/media/:id/hidden', auth, function (req, res) {
  const item = db.media.filter(function (m) { return String(m.id) === req.params.id; })[0];
  if (!item) return res.status(404).json({ error: '文件不存在' });
  item.hidden = !!((req.body || {}).hidden);
  saveDb();
  res.json({ ok: true, media: item });
});

// 删除媒体（管理员）
app.delete('/api/media/:id', auth, function (req, res) {
  const item = db.media.filter(function (m) { return String(m.id) === req.params.id; })[0];
  if (!item) return res.status(404).json({ error: '文件不存在' });
  try { fs.unlinkSync(path.join(UPLOAD_DIR, item.type, item.filename)); } catch (e) {}
  db.media = db.media.filter(function (m) { return String(m.id) !== req.params.id; });
  // 如果背景（默认/日间/夜间图片或视频壁纸）正好是它，重置为默认
  ['backgroundUrl', 'backgroundUrlDay', 'backgroundUrlNight', 'backgroundVideoDay', 'backgroundVideoNight'].forEach(function (k) {
    if (db.settings[k] === item.url) db.settings[k] = '';
  });
  if (!db.settings.backgroundUrl) db.settings.backgroundUrl = '/assets/default-bg.png';
  // 自动播放曲目正好是它，重置为默认
  if (db.settings.autoPlayId === String(item.id) || db.settings.autoPlayId === item.id) db.settings.autoPlayId = '';
  saveDb();
  res.json({ ok: true });
});

// 调整媒体展示顺序（管理员）：按传入 ids 的先后重排
app.post('/api/media/reorder', auth, function (req, res) {
  const b = req.body || {};
  if (!Array.isArray(b.ids) || !b.ids.length) return res.status(400).json({ error: '缺少 ids' });
  const pos = {};
  b.ids.forEach(function (id, i) { pos[String(id)] = i; });
  db.media.forEach(function (m) {
    if (pos[String(m.id)] !== undefined) m.sort = pos[String(m.id)];
  });
  saveDb();
  res.json({ ok: true });
});

/* ---------------- 搜索引擎收录（SEO） ----------------
   本站是 hash 路由的单页应用（/#/post/13）：# 之后的内容不会发给服务器，
   所以爬虫眼里整站只有一个网址。这里做三件事，让首页可被正常收录：
   ① /robots.txt     允许抓取并声明 sitemap
   ② /sitemap.xml    站点地图（域名跟随站点配置自动生成）
   ③ 首页 HTML 把「站点简介 + 最近文章标题」内联进 #view：
      百度等不执行 JS 的爬虫也能读到真实内容，不再是空壳页面 */
function seoOrigin(req) {
  if (SITE_ORIGIN) return SITE_ORIGIN;
  return 'http://' + String(req.headers.host || 'localhost').replace(/[^\w.:\-\[\]]/g, '');
}
function seoEsc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function seoBlock() {
  const s = db.settings || {};
  const now = Date.now();
  const title = s.siteTitle || 'D-6CF-X的临时小站';
  const sub = s.subtitle || '';
  const about = String(s.about || '').split('\n')[0].trim();
  const posts = (db.posts || [])
    .filter(function (p) { return p && p.title && isPostLive(p, now); })
    .sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); })
    .slice(0, 10);
  let h = '<h1>' + seoEsc(title) + '</h1>\n';
  h += '<p>' + seoEsc(sub ? sub + ' —— ' : '') +
       seoEsc(about || '个人小站：收录文章随笔、图片图库、音乐与留言签名板。') + '</p>\n';
  h += '<nav aria-label="站点导航"><a href="/#/home">首页</a> <a href="/#/posts">文章</a>' +
       ' <a href="/#/gallery">图库</a> <a href="/#/music">音乐</a>' +
       ' <a href="/#/board">签名板</a> <a href="/#/about">关于</a></nav>\n';
  if (posts.length) {
    h += '<section><h2>最新文章</h2><ul>\n';
    posts.forEach(function (p) {
      h += '<li><a href="/#/post/' + encodeURIComponent(p.id) + '">' +
           seoEsc(p.title) + '</a></li>\n';
    });
    h += '</ul></section>\n';
  }
  return h;
}
app.get('/robots.txt', function (req, res) {
  res.type('text/plain').send(
    'User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ' + seoOrigin(req) + '/sitemap.xml\n');
});
app.get('/sitemap.xml', function (req, res) {
  const last = (db.posts || []).reduce(function (m, p) {
    const t = p && (p.updatedAt || p.createdAt);
    return t && t > m ? t : m;
  }, 0);
  const lastmod = new Date(last || Date.now()).toISOString().slice(0, 10);
  res.type('application/xml').send(
    '<?xml version="1.0" encoding="UTF-8"?>\n' +
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
    '  <url>\n    <loc>' + seoOrigin(req) + '/</loc>\n' +
    '    <lastmod>' + lastmod + '</lastmod>\n' +
    '    <changefreq>weekly</changefreq>\n    <priority>1.0</priority>\n' +
    '  </url>\n</urlset>\n');
});

// 首页兜底：把 SEO 文本块内联进 HTML（<!--seo:start--> ... <!--seo:end--> 之间）
const INDEX_HTML_PATH = path.join(ROOT, 'public', 'index.html');
app.get('/', function (req, res) {
  fs.readFile(INDEX_HTML_PATH, 'utf8', function (err, html) {
    if (err) return res.sendFile(INDEX_HTML_PATH);
    const a = '<!--seo:start-->', b = '<!--seo:end-->';
    const i = html.indexOf(a), j = html.indexOf(b);
    if (i !== -1 && j > i) {
      html = html.slice(0, i + a.length) + '\n        ' + seoBlock() +
             '      ' + html.slice(j);
    }
    res.type('html').send(html);
  });
});

app.listen(PORT, function () {
  console.log('========================================');
  console.log('  D-6CF-X的临时小站 已启动');
  console.log('  地址: http://localhost:' + PORT);
  if (SITE_DOMAIN) {
    console.log('  正式域名: https://' + SITE_DOMAIN);
    console.log('  旧地址跳转: ' + (DOMAIN_REDIRECT ? '已开启（非域名访问会 302 跳转）' : '已关闭（DOMAIN_REDIRECT=off）'));
  } else {
    console.log('  域名跳转: 未启用（在 data/site-domain.json 里填域名即可开启）');
  }
  console.log('  管理入口: 页面左下角「小站管理」');
  console.log('  默认密码: d6cfx123 （登录后请立即修改！）');
  console.log('========================================');
});
